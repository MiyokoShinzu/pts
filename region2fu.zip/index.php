<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Region2 Forensic Unit</title>
</head>
 <style>
     *{
         margin: 0;
         padding: 0;
         box-sizing: border-box;
         
     }
    
    </style>
<body>
    <div style="width: 100vw; height: 100vh; display: flex; align-items: center; justify-content:space-around; flex-direction: column;">
        <img  id="logo" src="https://1000logos.net/wp-content/uploads/2019/03/PNP-Logo.png" alt="" class="mt-3" style="height: 100px; width: 200px;">
    </div>




        <script>
        setTimeout(function() {
            window.location.href = 'login.php';
        }, 3000);
    </script> 


<style>
    #logo{
        animation: animate 1s linear infinite;
    }
    @keyframes animate{
        0%{
            scale: 1;
        }
        50%{
            scale: 0.9;
        }
        100%{
            scale: 1;
        }
       
    }
    </style>  

</body>

</html>
<?php
$servername = "localhost";
$username = "u616194426_root";
$password = "EVALLO21ab.";
$dbname = "u616194426_pnpfu";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
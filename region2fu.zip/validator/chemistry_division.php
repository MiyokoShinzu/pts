<?php
include "../src/connection.php";
include "globals/head.php";
?>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $unit = $_SESSION['unit'];
    $case_number = $_POST['case_number'];
    $type_of_examination = $_POST['type_of_examination'];
    $no_of_examination = $_POST['no_of_examination'];
    $datetime_received = $_POST['datetime_received'];
    $datetime_completed = $_POST['datetime_completed'];
    $evidence = $_POST['evidence'];
    $suspect = $_POST['suspect'];
    $victim = $_POST['victim'];
    $subject = $_POST['subject'];
    $requesting_party = $_POST['requesting_party'];
    $delivered_by = $_POST['delivered_by'];
    $tdpo_no = $_POST['tdpo_no'];
    $examiner = $_POST['examiner'];
    $nature_of_case = $_POST['nature_of_case'];
    $duty_receiving_officer = $_POST['duty_receiving_officer'];
    $casts_taken_by = $_POST['casts_taken_by'];
    $witnessed_by = $_POST['witnessed_by'];
    $result_of_examination = $_POST['result_of_examination'];
    $remarks = $_POST['remarks'];
    $status = "Pending";
    // Insert data into database
    $sql = "INSERT INTO chemistry_one (case_number, type_of_examination, no_of_examination, datetime_received, datetime_completed, evidence, suspect, victim, subject, requesting_party, delivered_by, tdpo_no, examiner, nature_of_case, duty_receiving_officer, casts_taken_by, witnessed_by, result_of_examination, remarks, unit, status)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssssssssssssss", $case_number, $type_of_examination, $no_of_examination, $datetime_received, $datetime_completed, $evidence, $suspect, $victim, $subject, $requesting_party, $delivered_by, $tdpo_no, $examiner, $nature_of_case, $duty_receiving_officer, $casts_taken_by, $witnessed_by, $result_of_examination, $remarks, $unit, $status);

    if ($stmt->execute()) {
        $message = "New record created successfully";
        header("Location: chemistry_division.php");
        exit();
    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error;
    }

    $stmt->close();
}
?>

<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>

        <main class="content bg-white">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3"><strong>Chemistry</strong> Division</h1>

                <div class="row bg-white p-2 border">

                    <div class="col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">

                            <div class="table-responsive">
                                <table class="table  table-bordered table-striped table-hover" id="chem_table">
                                    <thead>
                                        <tr class="w-100">
                                            <th class=" ">Case Number</th>
                                            <th class=" ">Type of Examination</th>
                                            <th class=" ">No. of Examination</th>
                                            <th class=" ">Time and Date Received</th>
                                            <th class=" ">Time and Date Completed</th>
                                            <th class=" ">Status</th>
                                            <th class=" ">Evidence Submitted/Collected</th>
                                            <th class=" ">Suspect</th>
                                            <th class=" ">Victim</th>
                                            <th class=" ">Subject (Paraffin Only)</th>
                                            <th class=" ">Requesting Party</th>
                                            <th class=" ">Delivered By</th>
                                            <th class=" ">TDPO No.</th>
                                            <th class=" ">Examiner</th>
                                            <th class=" ">Nature of Case</th>
                                            <th class=" ">Duty Receiving Officer</th>
                                            <th class=" ">Casts Taken By (Paraffin Only)</th>
                                            <th class=" ">Witnessed by (Paraffin Only)</th>
                                            <th class=" ">Result of Examination</th>
                                            <th class=" ">Remarks</th>
                                            <th class=" ">Created At</th>
                                            <th class=" ">Actions</th>


                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sql = "SELECT * FROM chemistry_one where unit = '$unit' order by id DESC";
                                        $result = mysqli_query($conn, $sql);

                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_assoc($result)) {
                                                echo "<tr class='text-black'>";
                                                echo "<td>" . $row['case_number'] . "</td>";
                                                if ($row["status"] == "Pending") {
                                                    $el = "<span class='badge bg-warning  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Reviewed") {
                                                    $el = "<span class='badge bg-info  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "With Revisions") {
                                                    $el = "<span class='badge bg-danger  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Approved") {
                                                    $el = "<span class='badge bg-success  text-center text-white'>" . $row["status"] . "</span>";
                                                } else {
                                                    $el = "<span class='badge bg-secondary  text-center text-white'>" . "N/A" . "</span>";
                                                }
                                                echo "<td class='text-center'>" . $el . "</td>";
                                                echo "<td>" . $row['type_of_examination'] . "</td>";
                                                echo "<td>" . $row['no_of_examination'] . "</td>";
                                                echo "<td>" . $row['datetime_received'] . "</td>";
                                                echo "<td>" . $row['datetime_completed'] . "</td>";

                                                echo "<td>" . $row['evidence'] . "</td>";
                                                echo "<td>" . $row['suspect'] . "</td>";
                                                echo "<td>" . $row['victim'] . "</td>";
                                                echo "<td>" . $row['subject'] . "</td>";
                                                echo "<td>" . $row['requesting_party'] . "</td>";
                                                echo "<td>" . $row['delivered_by'] . "</td>";
                                                echo "<td>" . $row['tdpo_no'] . "</td>";
                                                echo "<td>" . $row['examiner'] . "</td>";
                                                echo "<td>" . $row['nature_of_case'] . "</td>";
                                                echo "<td>" . $row['duty_receiving_officer'] . "</td>";
                                                echo "<td>" . $row['casts_taken_by'] . "</td>";
                                                echo "<td>" . $row['witnessed_by'] . "</td>";
                                                echo "<td>" . $row['result_of_examination'] . "</td>";
                                                echo "<td>" . $row['remarks'] . "</td>";
                                                echo "<td>" . $row['created_at'] . "</td>";
                                                echo "<td>
                                                <button class='btn btn-danger'>Add revision</button>
                                                <button class='btn btn-success' id='approve_btn'  data-id='" . $row['id'] . "'>Approve</button>
                                                </td>";
                                                echo "</tr>";
                                            }
                                        }

                                        // Close the database connection
                                        mysqli_close($conn);
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>





                </div>
            </div>

            <div class="modal fade" id="add_case_chemistry3" tabindex="-1" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content bg-white">
                        <div class="modal-header">
                            <h5 class="modal-title">Add New Chemistry Case</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <div class="row p-2">
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="case_number" class="strong mb-1" style="font-weight: bold;">Case Number</label>
                                            <input type="text" class="form-control" id="case_number" required name="case_number" placeholder="C-001-24-RFU2">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="type_of_examination" class="strong mb-1" style="font-weight: bold;">Type of Examination</label>
                                            <select class="form-select" id="type_of_examination" required name="type_of_examination">
                                                <option value="GPR Paraffin Test">GPR Paraffin Test</option>
                                                <option value="GPR for Firearms">GPR for Firearms</option>
                                                <option value="Chemical Analysis">Chemical Analysis</option>
                                                <option value="Explosive">Explosive</option>
                                                <option value="Toxicology">Toxicology</option>
                                                <option value="Alcohol Analysis">Alcohol Analysis</option>
                                                <option value="Unfair Trade Competition">Unfair Trade Competition</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="num_of_examination" class="strong mb-1" style="font-weight: bold;">No. of Examination</label>
                                            <input type="number" min="0" max="1000" class="form-control" id="num_of_examination" required name="no_of_examination">
                                        </div>
                                    </div>



                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="date_received" class="strong mb-1" style="font-weight: bold;">Time and Date Received</label>
                                            <input type="datetime-local" class="form-control" id="date_received" required name="datetime_received">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="date_completed" class="strong mb-1" style="font-weight: bold;">Time and Date Completed</label>
                                            <input type="datetime-local" class="form-control" id="date_completed" required name="datetime_completed">
                                        </div>
                                    </div>

                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="suspect" class="strong mb-1" style="font-weight: bold;">Suspect</label>
                                            <input type="text" class="form-control" id="suspect" required name="suspect">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="victim" class="strong mb-1" style="font-weight: bold;">Victim</label>
                                            <input type="text" class="form-control" id="victim" required name="victim">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="requesting_party" class="strong mb-1" style="font-weight: bold;">Requesting Party</label>
                                            <input type="text" class="form-control" id="requesting_party" required name="requesting_party">
                                        </div>
                                    </div>

                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="delivered_by" class="strong mb-1" style="font-weight: bold;">Delivered By</label>
                                            <input type="text" class="form-control" id="delivered_by" required name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="tdpo_number" class="strong mb-1" style="font-weight: bold;">TDPO No.</label>
                                            <input type="text" class="form-control" id="tdpo_number" required name="tdpo_no">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="duty_officer" class="strong mb-1" style="font-weight: bold;">Duty Receiving Officer</label>
                                            <input type="text" class="form-control" id="duty_officer" required name="duty_receiving_officer">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="subject_paraffin" class="strong mb-1" style="font-weight: bold;">Subject (Paraffin Only)</label>
                                            <input type="text" class="form-control" id="subject_paraffin" required name="subject">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="casts_paraffin" class="strong mb-1" style="font-weight: bold;">Casts Taken By (Paraffin Only)</label>
                                            <input type="text" class="form-control" id="casts_paraffin" required name="casts_taken_by">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="witness_paraffin" class="strong mb-1" style="font-weight: bold;">Witnessed by (Paraffin Only)</label>
                                            <input type="text" class="form-control" id="witness_paraffin" required name="witnessed_by">
                                        </div>
                                    </div>
                                    <div class="col-lg-8 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="examiner" class="strong mb-1" style="font-weight: bold;">Examiner</label>
                                            <input type="text" class="form-control" id="examiner" required name="examiner">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" required name="nature_of_case" class="form-select">
                                                <option value="Shooting Incident">Shooting Incident</option>
                                                <option value="Found Dead Body">Found Dead Body</option>
                                                <option value="Alleged Violation of RA 9165">Alleged Violation of RA 9165</option>
                                                <option value="Alleged Violation of RA 10591">Alleged Violation of RA 10591</option>
                                                <option value="Alleged Violation of RA 10586">Alleged Violation of RA 10586</option>
                                                <option value="Alleged Violation of RA 9516">Alleged Violation of RA 9516</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="other_nature_case_input" placeholder="Enter other nature of case">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="evidence" class="strong mb-1" style="font-weight: bold;">Evidence Submitted/Collected</label>
                                            <textarea class="form-control" id="evidence" required name="evidence" rows="3"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="result_of_examination" class="strong mb-1" style="font-weight: bold;">Result of Examination</label>
                                            <textarea class="form-control" id="result_of_examination" required name="result_of_examination" rows="3"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="remarks" class="strong mb-1" style="font-weight: bold;">Remarks</label>
                                            <textarea class="form-control" id="remarks" required name="remarks" rows="3"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </main>


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#chem_table').DataTable({
        responsive: true,
        dom: "BfrQltip"
    })
</script>
<script>
    $(document).on('click', '#approve_btn', function() {
        var id = $(this).attr('data-id');
        fetch(`approve_chemistry_one.php?id=${id}`)
            .then(res => res.json())
            .then(data => {
                if (data.success == 1) {
                    alert("Case approved successfully");
                    location.reload();
                }
            })
    })
</script>
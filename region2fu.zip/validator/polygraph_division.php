<?php
include "../src/connection.php";
include "globals/head.php";
?>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $case_number = $_POST['case_number'];
    $cases_received = $_POST['cases_received'];
    $examinations = $_POST['examinations'];
    $date_received = $_POST['date_received'];
    $date_completed = $_POST['date_completed'];
    $documents_submitted = $_POST['documents_submitted'];
    $document_file = $_POST['document_file'];
    $requesting_party = $_POST['requesting_party'];
    $delivered_by = $_POST['delivered_by'];
    $subject = $_POST['subject'];
    $examiner = $_POST['examiner'];
    $occurrence_datetime = $_POST['occurrence_datetime'];
    $nature_of_case = $_POST['nature_of_case'];
    $remarks = $_POST['remarks'];
    $status = "Pending";
    $unit = $_SESSION['unit'];

    // Prepare an SQL statement to insert data into the cases table
    $sql = "INSERT INTO polygraph (case_number, cases_received, examinations, date_received, date_completed, documents_submitted, document_file, requesting_party, delivered_by, subject, examiner, occurrence_datetime, nature_of_case, remarks, status, unit) 
            VALUES ('$case_number', '$cases_received', '$examinations', '$date_received', '$date_completed', '$documents_submitted', '$document_file', '$requesting_party', '$delivered_by', '$subject', '$examiner', '$occurrence_datetime', '$nature_of_case', '$remarks', '$status', '$unit')";

    if ($conn->query($sql) === TRUE) {
        echo "Data inserted successfully.";
        header("Location: polygraph_division.php");
        exit();
    } else {
        echo "Error inserting data: " . $conn->error;
    }
}
?>
<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>
        <?php
        $sql = "SELECT * FROM polygraph where unit = '$unit'";
        $result = $conn->query($sql);
        ?>
        <main class="content bg-white">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3"><strong>Polygraph</strong> Division</h1>

                <div class="row bg-white p-2 border">

                    <div class="col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">
                            <div class="table-responsive">
                                <table class="table table-striped" id="polygraph_table">
                                    <thead>

                                        <tr>
                                            <th>Case Number</th>
                                            <th>Status</th>
                                            <th>No. of Cases Received</th>
                                            <th>No. of Examinations</th>
                                            <th>Time and Date Received</th>
                                            <th>Time and Date Completed</th>
                                            <th>Documents Submitted</th>
                                            <th>Document File</th>
                                            <th>Requesting Party</th>
                                            <th>Delivered by (station)</th>
                                            <th>Subject</th>
                                            <th>EXAMINER</th>
                                            <th>Time and Date & Place of Occurrence</th>
                                            <th>Nature of Case</th>
                                            <th>Remarks</th>
                                            <th>Actions</th>
                                        </tr>

                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row['case_number'] . "</td>";
                                                if ($row["status"] == "Pending") {
                                                    $el = "<span class='badge bg-warning  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Reviewed") {
                                                    $el = "<span class='badge bg-info  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "With Revisions") {
                                                    $el = "<span class='badge bg-danger  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Approved") {
                                                    $el = "<span class='badge bg-success  text-center text-white'>" . $row["status"] . "</span>";
                                                } else {
                                                    $el = "<span class='badge bg-secondary  text-center text-white'>" . "N/A" . "</span>";
                                                }
                                                echo "<td class='text-center'>" . $el . "</td>";




                                                echo "<td>" . $row['cases_received'] . "</td>";
                                                echo "<td>" . $row['examinations'] . "</td>";
                                                echo "<td>" . $row['date_received'] . "</td>";
                                                echo "<td>" . $row['date_completed'] . "</td>";
                                                echo "<td>" . $row['documents_submitted'] . "</td>";
                                                echo "<td>" . $row['document_file'] . "</td>";
                                                echo "<td>" . $row['requesting_party'] . "</td>";
                                                echo "<td>" . $row['delivered_by'] . "</td>";
                                                echo "<td>" . $row['subject'] . "</td>";
                                                echo "<td>" . $row['examiner'] . "</td>";
                                                echo "<td>" . $row['occurrence_datetime'] . "</td>";
                                                echo "<td>" . $row['nature_of_case'] . "</td>";
                                                echo "<td>" . $row['remarks'] . "</td>";
                                                echo "<td>
                                                <button class='btn btn-danger'>Add revision</button>
                                                <button class='btn btn-success' id='approve_btn'  data-id='" . $row['id'] . "'>Approve</button>
                                                </td>";
                                                echo "</tr>";
                                            }
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>



                    <div class="col-lg-10 mx-auto bg-white">
                        <div class="table-responsive">

                        </div>
                    </div>

                </div>
            </div>




            <div class="modal" tabindex="-1" id="add_pi_case" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6>Polygraph Division</h6>
                            <h5 class="modal-title">Add New Case</h5>
                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="case_number" class="mb-1 strong">Case Number</label>
                                            <input type="text" class="form-control" id="case_number" name="case_number">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="cases_received" class="mb-1 strong">No. of Cases Received</label>
                                            <input type="number" min="0" max="1000" class="form-control" id="cases_received" name="cases_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="examinations" class="mb-1 strong">No. of Examinations</label>
                                            <input type="number" min="0" max="1000" class="form-control" id="examinations" name="examinations">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="date_received" class="mb-1 strong">Time and Date Received</label>
                                            <input type="datetime-local" class="form-control" id="date_received" name="date_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="date_completed" class="mb-1 strong">Time and Date Completed</label>
                                            <input type="datetime-local" class="form-control" id="date_completed" name="date_completed">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="documents_submitted" class="mb-1 strong">Documents Submitted</label>
                                            <input type="text" class="form-control" id="documents_submitted" name="documents_submitted">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="document_file" class="mb-1 strong">Document File</label>
                                            <input type="file" class="form-control" id="document_file" name="document_file">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label for="requesting_party" class="mb-1 strong">Requesting Party</label>
                                            <input type="text" class="form-control" id="requesting_party" name="requesting_party">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="delivered_by" class="mb-1 strong">Delivered by (station)</label>
                                            <input type="text" class="form-control" id="delivered_by" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="subject" class="mb-1 strong">Subject</label>
                                            <input type="text" class="form-control" id="subject" name="subject">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="examiner" class="mb-1 strong">EXAMINER</label>
                                            <input type="text" class="form-control" id="examiner" name="examiner" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="occurrence_datetime" class="mb-1 strong">Time and Date & Place of Occurrence</label>
                                            <input type="text" class="form-control" id="occurrence_datetime" name="occurrence_datetime">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="nature_of_case" class="mb-1 strong">Nature of Case</label>
                                            <select name="nature_of_case" class="form-control" id="nature_of_case">
                                                <option value="ROBBERY">ROBBERY</option>
                                                <option value="THEFT">THEFT</option>
                                                <option value="MURDER">MURDER</option>
                                                <option value="HOMICIDE">HOMICIDE</option>
                                                <option value="RAPE">RAPE</option>
                                                <option value="SCREENING OF CIW">SCREENING OF CIW</option>
                                                <option value="SCREENING OF APPLICANT">SCREENING OF APPLICANT</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3 ">
                                        <div class="form-group">
                                            <label for="remarks" class="mb-1 strong">Remarks</label>
                                            <input type="text" class="form-control" id="remarks" name="remarks">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-11 mx-auto text-end mb-3">
                                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-sm btn-primary" value="submit">Submit</button>
                                    <!-- PDF file only -->
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>
        </main>


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#polygraph_table').DataTable({
        responsive: true,
        dom: "BfrQltip"
    })
</script>
<script>
    $(document).on("input", "#other_drug", function() {
        $("#other_input").removeClass('d-none');
        var drug_name = $("#other_drug").val()
        if (drug_name == "") {
            $("#other_input").addClass('d-none')
        } else {
            $('#other_input #text_label').text(`Weight in grams of ${drug_name}`)
        }
    })
</script>
<script>
    $(document).on('click', '#approve_btn', function() {
        var id = $(this).attr('data-id');
        fetch(`approve_polygraph.php?id=${id}`)
            .then(res => res.json())
            .then(data => {
                if (data.success == 1) {
                    alert("Case approved successfully");
                    location.reload();
                }
            })
    })
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var natureOfCaseSelect = document.getElementById('nature_of_case');
        var otherNatureCaseInput = document.getElementById('other_nature_case');

        natureOfCaseSelect.addEventListener('change', function() {
            var selectedOption = natureOfCaseSelect.value;

            if (selectedOption === 'Others') {
                otherNatureCaseInput.style.display = 'block';

            } else {
                otherNatureCaseInput.style.display = 'none';

            }

        });
        
    });
</script>
<?php
include "../src/connection.php";
include "globals/head.php";
?>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Extract the form data
    $status = "Pending";
    $unit = $_SESSION['unit'];
    $case_number = $_POST["case_number"];
    $case_count = $_POST["case_count"];
    $exam_count = $_POST["exam_count"];
    $date_received = $_POST["date_received"];
    $date_completed = $_POST["date_completed"];
    $evidence_submitted = $_POST["evidence_submitted"];
    $evidence_path = "Hello";
    $requesting_party = $_POST["requesting_party"];
    $delivered_by = $_POST["delivered_by"];
    $victim = $_POST["victim"];
    $suspect = $_POST["suspect"];
    $examiner = $_POST["examiner"];
    $tdpo = $_POST["tdpo"];
    $nature_of_case = $_POST["nature_of_case"];
    $remarks = $_POST["remarks"];
    $exam_type = $_POST["exam_type"];

    // Insert the data into the database
    $sql = "INSERT INTO pi (
    case_number,
    case_count,
    exam_count,
    date_received,
    date_completed,
    evidence_submitted,
    evidence_path,
    requesting_party,
    delivered_by,
    victim,
    suspect,
    examiner,
    tdpo,
    nature_of_case,
    remarks,
    exam_type,
    status,
    unit
  ) VALUES (
    '$case_number',
    '$case_count',
    '$exam_count',
    '$date_received',
    '$date_completed',
    '$evidence_submitted',
    '$evidence_path',
    '$requesting_party',
    '$delivered_by',
    '$victim',
    '$suspect',
    '$examiner',
    '$tdpo',
    '$nature_of_case',
    '$remarks',
    '$exam_type',
    '$status',
    '$unit'
  )";

    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
        header("Location: pi_division.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>
<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>

        <main class="content bg-white">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3"><strong>Physical Identification</strong> Division</h1>

                <div class="row bg-white p-2 border">
                    <div class="mb-3 col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">

                            <div class="table-responsive">
                                <table class="table table-striped" id="pi_table">
                                    <thead>
                                        <tr>
                                            <th>Case Number</th>
                                            <th>Status</th>
                                            <th>No. of Cases Received</th>
                                            <th>No. of Examination</th>
                                            <th>Time and Date Received</th>
                                            <th>Time and Date Completed</th>
                                            <th>Evidence Submitted</th>
                                            <th>Requesting Party</th>
                                            <th>Delivered by (station)</th>
                                            <th>Victim/s</th>
                                            <th>Suspect/s</th>
                                            <th>EXAMINER</th>
                                            <th>Time and Date & Place of Occurence</th>
                                            <th>Nature of Case</th>
                                            <th>Remarks</th>
                                            <th>Type of Examination</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php

                                        $sql = "SELECT * FROM pi where unit = '$unit'";
                                        $result = mysqli_query($conn, $sql);

                                        while ($row = mysqli_fetch_assoc($result)) {
                                            echo "<tr>";
                                            echo "<td>" . $row["case_number"] . "</td>";
                                            if ($row["status"] == "Pending") {
                                                $el = "<span class='badge bg-warning  text-center text-white'>" . $row["status"] . "</span>";
                                            } else if ($row["status"] == "Reviewed") {
                                                $el = "<span class='badge bg-info  text-center text-white'>" . $row["status"] . "</span>";
                                            } else if ($row["status"] == "With Revisions") {
                                                $el = "<span class='badge bg-danger  text-center text-white'>" . $row["status"] . "</span>";
                                            } else if ($row["status"] == "Approved") {
                                                $el = "<span class='badge bg-success  text-center text-white'>" . $row["status"] . "</span>";
                                            } else {
                                                $el = "<span class='badge bg-secondary  text-center text-white'>" . "N/A" . "</span>";
                                            }
                                            echo "<td class='text-center'>" . $el . "</td>";
                                            echo "<td>" . $row["case_count"] . "</td>";
                                            echo "<td>" . $row["exam_count"] . "</td>";
                                            echo "<td>" . $row["date_received"] . "</td>";
                                            echo "<td>" . $row["date_completed"] . "</td>";
                                            echo "<td>" . $row["evidence_submitted"] . "</td>";
                                            echo "<td>" . $row["requesting_party"] . "</td>";
                                            echo "<td>" . $row["delivered_by"] . "</td>";
                                            echo "<td>" . $row["victim"] . "</td>";
                                            echo "<td>" . $row["suspect"] . "</td>";
                                            echo "<td>" . $row["examiner"] . "</td>";
                                            echo "<td>" . $row["tdpo"] . "</td>";
                                            echo "<td>" . $row["nature_of_case"] . "</td>";
                                            echo "<td>" . $row["remarks"] . "</td>";
                                            echo "<td>" . $row["exam_type"] . "</td>";
                                            echo "<td>
                                                <button class='btn btn-danger'>Add revision</button>
                                                <button class='btn btn-success' id='approve_btn'  data-id='" . $row['id'] . "'>Approve</button>
                                                </td>";
                                            echo "</tr>";
                                        }



                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>





                </div>
            </div>




            <div class="modal" tabindex="-1" id="add_pi_case" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6>Physical Identification</h6>
                            <h5 class="modal-title">Add New Case</h5>

                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">Case Number</label>
                                            <input type="text" class="form-control" name="case_number">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">No.of Cases Received</label>
                                            <input type="number" min=0 max=1000 class="form-control" name="case_count">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">No.of Examination</label>
                                            <input type="number" min=0 max=1000 class="form-control" name="exam_count">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">Time and Date Received</label>
                                            <input type="datetime-local" class="form-control" name="date_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">Time and Date Completed</label>
                                            <input type="datetime-local" class="form-control" name="date_completed">
                                        </div>
                                    </div>

                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">Evidence Submitted</label>
                                            <input type="text" class="form-control" name="evidence_submitted">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">Evidence File</label>
                                            <input type="file" class="form-control" accept="application/pdf" name="evidence" required>
                                        </div>
                                    </div>


                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">Requesting Party</label>
                                            <input type="text" class="form-control" name="requesting_party">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">Delivered by (station)</label>
                                            <input type="text" class="form-control" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">Victim/s</label>
                                            <input type="text" class="form-control" name="victim">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">Suspect/s</label>
                                            <input type="text" class="form-control" name="suspect">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">EXAMINER</label>
                                            <input type="text" class="form-control" name="examiner" required>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">Time and Date & Place of Occurence</label>
                                            <input type="datetime-local" class="form-control" name="tdpo">
                                        </div>
                                    </div>

                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">Nature of Case</label>
                                            <select name="nature_of_case" class="form-control" id="">
                                                <option value="Found Dead Body">Found Dead Body</option>
                                                <option value="Shooting Incident">Shooting Incident</option>
                                                <option value="Robbery">Robbery</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">Remarks(In Custody, Court, Requesting Party)</label>
                                            <select name="remarks" id="" class="form-control">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                                <option value="Turnovered To PDEA">Turned over to Requesting Party</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6 mb-3">
                                        <div class="form-group">
                                            <label for="" class="strong mb-1">Type of Examination</label>
                                            <select name="exam_type" id="" class="form-select">
                                                <option value="MACRO ETCHING OF FIREARMS">MACRO ETCHING OF FIREARMS</option>
                                                <option value="MACRO ETCHING OF VEHICLE">MACRO ETCHING OF VEHICLE</option>
                                                <option value="MACRO ETCHING OF SEA VESSEL">MACRO ETCHING OF SEA VESSEL</option>
                                                <option value="UV">UV</option>
                                                <option value="BULLET TRAJECTORY">BULLET TRAJECTORY</option>
                                                <option value="HAIR AND FIBER ANALYSIS">HAIR AND FIBER ANALYSIS</option>
                                                <option value="CASTING AND MOLDING">CASTING AND MOLDING</option>
                                                <option value="PAINT ANALYSIS">PAINT ANALYSIS</option>
                                                <option value="TOOL MARKS EXAMINATION">TOOL MARKS EXAMINATION</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-12 text-end">

                                        <button type="button" class="btn btn-sm btn-danger" data-bs-dismiss="modal">Close</button>
                                        <button class="btn btn-sm btn-primary" type="submit" value="submit">Submit</button>
                                        <!-- PDF file only -->
                                    </div>


                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </main>


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#pi_table').DataTable({
        responsive: true,
        dom: "BfrQltip"
    })
</script>
<script>
    $(document).on("input", "#other_drug", function() {
        $("#other_input").removeClass('d-none');
        var drug_name = $("#other_drug").val()
        if (drug_name == "") {
            $("#other_input").addClass('d-none')
        } else {
            $('#other_input #text_label').text(`Weight in grams of ${drug_name}`)
        }
    })
</script>
<script>
    $(document).on('click', '#approve_btn', function() {
        var id = $(this).attr('data-id');
        fetch(`approve_pi.php?id=${id}`)
            .then(res => res.json())
            .then(data => {
                if (data.success == 1) {
                    alert("Case approved successfully");
                    location.reload();
                }
            })
    })
</script>
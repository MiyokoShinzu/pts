<?php
include "../src/connection.php";
include "globals/head.php";
?>



<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include your database connection file


    // Retrieve form data
    $case_number = $_POST['case_number'];
    $examinations = $_POST['examinations'];
    $date_received = $_POST['date_received'];
    $date_completed = $_POST['date_completed'];
    $evidence_submitted = $_POST['evidence_submitted'];; // Combine checkbox values into a comma-separated string
    $requesting_party = $_POST['requesting_party'];
    $delivered_by = $_POST['delivered_by'];
    $subject = $_POST['victims']; // Assuming this corresponds to the subject in your database
    $examiner = $_POST['examiner'];
    $occurrence_datetime = $_POST['occurrence_details']; // Assuming this corresponds to the occurrence_datetime in your database
    $nature_of_case = $_POST['nature_of_case'];
    $remarks = $_POST['remarks'];
    $status = "Pending";
    $unit = $_SESSION['unit'];

    // Construct SQL INSERT statement
    $sql = "INSERT INTO fingerprint (case_number, examinations, date_received, date_completed, evidence_submitted, requesting_party, delivered_by, subject, examiner, occurrence_datetime, nature_of_case, remarks, status, unit) 
            VALUES ('$case_number', '$examinations', '$date_received', '$date_completed', '$evidence_submitted', '$requesting_party', '$delivered_by', '$subject', '$examiner', '$occurrence_datetime', '$nature_of_case', '$remarks', '$status', '$unit')";

    // Execute the INSERT statement
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
        header("Location: fingerprint_division.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>
        <?php
        $sql = "SELECT * FROM fingerprint where unit = '$unit'";
        $result = $conn->query($sql);
        ?>
        <main class="content bg-white">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3"><strong>Fingerprint</strong> Division</h1>

                <div class="row bg-white p-2 border">

                    <div class="mb-3 col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">

                            <div class="table-responsive">
                                <table id="fingerprint_table" class="table table-bordered table-hover" style="width:100%">
                                    <thead>
                                        <tr>

                                            <th>Case Number</th>
                                            <th>Status </th>
                                            <th>Examinations</th>
                                            <th>Date Received</th>
                                            <th>Date Completed</th>
                                            <th>Evidence Submitted</th>
                                            <th>Requesting Party</th>
                                            <th>Delivered By</th>
                                            <th>Subject</th>
                                            <th>Examiner</th>
                                            <th>Occurrence DateTime</th>
                                            <th>Nature of Case</th>
                                            <th>Remarks</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        while ($row = $result->fetch_assoc()) {
                                            echo '<tr>';
                                            echo '<td>' . $row['case_number'] . '</td>';
                                            if ($row["status"] == "Pending") {
                                                $el = "<span class='badge bg-warning  text-center text-white'>" . $row["status"] . "</span>";
                                            } else if ($row["status"] == "Reviewed") {
                                                $el = "<span class='badge bg-info  text-center text-white'>" . $row["status"] . "</span>";
                                            } else if ($row["status"] == "With Revisions") {
                                                $el = "<span class='badge bg-danger  text-center text-white'>" . $row["status"] . "</span>";
                                            } else if ($row["status"] == "Approved") {
                                                $el = "<span class='badge bg-success  text-center text-white'>" . $row["status"] . "</span>";
                                            } else {
                                                $el = "<span class='badge bg-secondary  text-center text-white'>" . "N/A" . "</span>";
                                            }
                                            echo "<td class='text-center'>" . $el . "</td>";
                                            echo '<td>' . $row['examinations'] . '</td>';
                                            echo '<td>' . $row['date_received'] . '</td>';
                                            echo '<td>' . $row['date_completed'] . '</td>';
                                            echo '<td>' . $row['evidence_submitted'] . '</td>';
                                            echo '<td>' . $row['requesting_party'] . '</td>';
                                            echo '<td>' . $row['delivered_by'] . '</td>';
                                            echo '<td>' . $row['subject'] . '</td>';
                                            echo '<td>' . $row['examiner'] . '</td>';
                                            echo '<td>' . $row['occurrence_datetime'] . '</td>';
                                            echo '<td>' . $row['nature_of_case'] . '</td>';
                                            echo '<td>' . $row['remarks'] . '</td>';
                                            echo "<td>
                                                <button class='btn btn-danger'>Add revision</button>
                                                <button class='btn btn-success' id='approve_btn'  data-id='" . $row['id'] . "'>Approve</button>
                                                </td>";
                                            echo "</tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>





                </div>
            </div>




            <div class="modal" tabindex="-1" id="add_dna_case" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6>Fingerprint</h6>
                            <h5 class="modal-title">Add New Case</h5>
                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <div class="row">
                                    <div class="mb-3 col-md-3">
                                        <div class="form-group">
                                            <label for="case_number" class="strong mb-1">Case Number</label>
                                            <input type="text" class="form-control" id="case_number" name="case_number">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-3">
                                        <div class="form-group">
                                            <label for="examinations" class="strong mb-1">No. of Examination</label>
                                            <input type="number" min="0" max="1000" class="form-control" id="examinations" name="examinations">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-3">
                                        <div class="form-group">
                                            <label for="date_received" class="strong mb-1">Time and Date Received</label>
                                            <input type="datetime-local" class="form-control" id="date_received" name="date_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-3">
                                        <div class="form-group">
                                            <label for="date_completed" class="strong mb-1">Time and Date Completed</label>
                                            <input type="datetime-local" class="form-control" id="date_completed" name="date_completed">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="evidence_submitted">Evidence Submitted</label><br>
                                            <input type="text" readonly class="form-control" id="evidence_submitted" name="evidence_submitted" placeholder="Check the values below to update data">
                                        </div>
                                    </div>
                                    <!-- Checkbox options for evidence submitted -->
                                    <div class="mb-3 col-3">
                                        <input type="checkbox" class="form-checkbox" id="chemistry" name="exam_type[]" value="Post Mortem" onchange="updateExamType()">
                                        <label class="strong mb-1" for="chemistry">Post Mortem</label><br>
                                    </div>
                                    <div class="mb-3 col-3">
                                        <input type="checkbox" class="form-checkbox" id="polygraph" name="exam_type[]" value="Latent Print" onchange="updateExamType()">
                                        <label class="strong mb-1" for="polygraph">Latent Print</label><br>
                                    </div>
                                    <div class="mb-3 col-6">
                                        <input type="checkbox" class="form-checkbox" id="dna_analysis" name="exam_type[]" value="Standard Fingerprint Chart" onchange="updateExamType()">
                                        <label class="strong mb-1" for="dna_analysis">Standard Fingerprint Chart</label><br>
                                    </div>
                                    <!-- End of Checkbox options -->
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="evidence_file" class="strong mb-1">Evidence File</label>
                                            <input type="file" class="form-control" id="evidence_file" name="evidence_file">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-8">
                                        <div class="form-group">
                                            <label for="requesting_party" class="strong mb-1">Requesting Party</label>
                                            <input type="text" class="form-control" id="requesting_party" name="requesting_party">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="delivered_by" class="strong mb-1">Delivered by (station)</label>
                                            <input type="text" class="form-control" id="delivered_by" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="victims" class="strong mb-1">Victim/s</label>
                                            <input type="text" class="form-control" id="victims" name="victims">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="suspects" class="strong mb-1">Suspect/s</label>
                                            <input type="text" class="form-control" id="suspects" name="suspects">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="examiner" class="strong mb-1">Examiner</label>
                                            <input type="text" class="form-control" id="examiner" name="examiner" required>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="occurrence_details" class="strong mb-1">Time, Date & Place of Occurrence</label>
                                            <input type="text" class="form-control" id="occurrence_details" name="occurrence_details">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="nature_of_case" class="strong mb-1">Nature of Case</label>
                                            <select name="nature_of_case" id="nature_of_case" class="form-control">
                                                <option value="Found Dead Body">Found Dead Body</option>
                                                <option value="Shooting Incident">Shooting Incident</option>
                                                <option value="Robbery">Robbery</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="remarks" class="strong mb-1">Remarks (In Custody, Court, Requesting Party)</label>
                                            <select name="remarks" id="remarks" class="form-control">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                                <option value="Turned Over To Requesting Party">Turned over to Requesting Party</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-end">
                                        <button type="button" class="btn btn-sm btn-danger" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" value="submit" class="btn btn-sm btn-primary">Submit</button>
                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>
        </main>


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#fingerprint_table').DataTable({
        responsive: true,
        dom: "BfrQltip"
    })
</script>
<script>
    $(document).on("input", "#other_drug", function() {
        $("#other_input").removeClass('d-none');
        var drug_name = $("#other_drug").val()
        if (drug_name == "") {
            $("#other_input").addClass('d-none')
        } else {
            $('#other_input #text_label').text(`Weight in grams of ${drug_name}`)
        }
    })
</script>
<script>
    function updateExamType() {
        const checkboxes = document.querySelectorAll('input[name="exam_type[]"]');
        const checkedValues = [];
        checkboxes.forEach(checkbox => {
            console.log(checkbox.value)
            if (checkbox.checked) {
                checkedValues.push(checkbox.value);

            }
        });
        const valuesString = checkedValues.join(',');
        document.getElementById('evidence_submitted').value = valuesString;
        console.log(valuesString)
        console.log('Updated hidden input:', valuesString);
    }
</script>
<script>
    $(document).on('click', '#approve_btn', function() {
        var id = $(this).attr('data-id');
        fetch(`approve_fingerprint.php?id=${id}`)
            .then(res => res.json())
            .then(data => {
                if (data.success == 1) {
                    alert("Case approved successfully");
                    location.reload();
                }
            })
    })
</script>
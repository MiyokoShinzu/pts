<?php
include "../src/connection.php";
include "globals/head.php";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $case_number = $_POST['case_number'];
    $exam_count = $_POST['exam_count'];
    $date_received = $_POST['date_received'];
    $date_completed = $_POST['date_completed'];
    $evidence_submitted = $_POST['evidence_submitted'];
    $evidence_file = "";  // Adjust this if you handle file uploads
    $requesting_party = $_POST['requesting_party'];
    $delivered_by = $_POST['delivered_by'];
    $examiner = $_POST['examiner'];
    $nature_of_case = $_POST['nature_of_case'];
    $remarks = $_POST['remarks'];
    $exam_type = $_POST['exam_type'];
    $unit = $_SESSION['unit'];
    $status = "Pending";

    $sql = "INSERT INTO chemistry_three (
        case_number, 
        exam_count, 
        date_received, 
        date_completed, 
        evidence_submitted, 
        evidence_file, 
        requesting_party, 
        delivered_by, 
        examiner, 
        nature_of_case, 
        remarks, 
        exam_type,
        unit,
        status
    ) VALUES (
        '$case_number', 
        '$exam_count', 
        '$date_received', 
        '$date_completed', 
        '$evidence_submitted', 
        '$evidence_file', 
        '$requesting_party', 
        '$delivered_by', 
        '$examiner', 
        '$nature_of_case', 
        '$remarks', 
        '$exam_type',
        '$unit',
        '$status'
    )";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
$unit = $_SESSION['unit'];
$query = "SELECT * FROM chemistry_three  where unit = '$unit'";
$result = $conn->query($query);
?>

<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>

        <main class="content bg-white">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3"><strong>Drug Test Case Chemistry</strong> Division</h1>

                <div class="row bg-white p-2 border">
                    <div class="mb-3 col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">
                            <div class="table-responsive">
                                <table class="table table-striped" id="drug_test_table">
                                    <thead>
                                        <tr>
                                            <th>Case Number</th>
                                            <th>Status</th>
                                            <th>Exam Count</th>
                                            <th>Date Received</th>
                                            <th>Date Completed</th>
                                            <th>Evidence Submitted</th>
                                            <th>Requesting Party</th>
                                            <th>Delivered By</th>
                                            <th>Examiner</th>
                                            <th>Nature of Case</th>
                                            <th>Remarks</th>
                                            <th>Exam Type</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row['case_number'] . "</td>";
                                                if ($row["status"] == "Pending") {
                                                    $el = "<span class='badge bg-warning  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Reviewed") {
                                                    $el = "<span class='badge bg-info  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "With Revisions") {
                                                    $el = "<span class='badge bg-danger  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Approved") {
                                                    $el = "<span class='badge bg-success  text-center text-white'>" . $row["status"] . "</span>";
                                                } else {
                                                    $el = "<span class='badge bg-secondary  text-center text-white'>" . "N/A" . "</span>";
                                                }
                                                echo "<td class='text-center'>" . $el . "</td>";
                                                echo "<td>" . $row['exam_count'] . "</td>";
                                                echo "<td>" . $row['date_received'] . "</td>";
                                                echo "<td>" . $row['date_completed'] . "</td>";
                                                echo "<td>" . $row['evidence_submitted'] . "</td>";
                                                echo "<td>" . $row['requesting_party'] . "</td>";
                                                echo "<td>" . $row['delivered_by'] . "</td>";
                                                echo "<td>" . $row['examiner'] . "</td>";
                                                echo "<td>" . $row['nature_of_case'] . "</td>";
                                                echo "<td>" . $row['remarks'] . "</td>";
                                                echo "<td>" . $row['exam_type'] . "</td>";
                                                echo "<td>
                                                <button class='btn btn-danger mb-3 btn-sm'>Add revision</button>
                                                <button class='btn btn-success ' id='approve_btn'  data-id='" . $row['id'] . "'>Approve</button>
                                                </td>";
                                                echo "</tr>";
                                            }
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>

            <!-- Modal for adding new case -->
            <div class="modal" tabindex="-1" id="add_pi_case" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6>Physical Identification</h6>
                            <h5 class="modal-title">Add New Case</h5>
                        </div>
                        <div class="modal-body">
                            <form method="post">
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="case_number">Case Number:</label>
                                            <input type="text" class="form-control" id="case_number" name="case_number" required title="Format: DT-001-24-RFU2">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="exam_type">Type of Drug Test:</label>
                                            <select class="form-control" id="exam_type" name="exam_type" required>
                                                <option value="">Select</option>
                                                <option value="CRIMINAL DT">CRIMINAL DT</option>
                                                <option value="RANDOM DT">RANDOM DT</option>
                                                <option value="FADT DT (LTOPF)">FADT DT (LTOPF)</option>
                                                <option value="PNP DT (SCHOOLING, PROMOTION, REASSIGNMENT AND OTHERS)">PNP DT (SCHOOLING, PROMOTION, REASSIGNMENT AND OTHERS)</option>
                                                <option value="CIV DT">CIV DT</option>
                                                <option value="PLEA BARGAIN DT">PLEA BARGAIN DT</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="exam_count">No. of Examination:</label>
                                            <input type="number" class="form-control" id="exam_count" name="exam_count" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="date_received">Time and Date Received:</label>
                                            <input type="datetime-local" class="form-control" id="date_received" name="date_received" required>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="date_completed">Time and Date Completed:</label>
                                            <input type="datetime-local" class="form-control" id="date_completed" name="date_completed" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label for="evidence_submitted">Evidence Submitted/Collected:</label>
                                            <textarea class="form-control" id="evidence_submitted" name="evidence_submitted" required></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="examiner">Examiner:</label>
                                            <input type="text" class="form-control" id="examiner" name="examiner" required>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="nature_of_case">Nature of Case:</label>
                                            <select class="form-control" id="nature_of_case" name="nature_of_case" required>
                                                <option value="">Select</option>
                                                <option value="Alleged Violation of RA 9165">Alleged Violation of RA 9165</option>
                                                <option value="Others">Others (please specify)</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="requesting_party">Requesting Party:</label>
                                            <input type="text" class="form-control" id="requesting_party" name="requesting_party" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="delivered_by">Delivered By:</label>
                                            <input type="text" class="form-control" id="delivered_by" name="delivered_by" required>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="duty_receiving_officer">Duty Receiving Officer:</label>
                                            <input type="text" class="form-control" id="duty_receiving_officer" name="duty_receiving_officer" required>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="result_of_examination">Result of Examination:</label>
                                            <input type="text" class="form-control" id="result_of_examination" name="result_of_examination" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label for="remarks">Remarks:</label>
                                            <textarea class="form-control" id="remarks" name="remarks"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-end">
                                        <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        $('#drug_test_table').DataTable({
            responsive: true,
            dom: "BfrQltip"
        });
    });
</script>

<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $(document).on("input", "#other_drug", function() {
        $("#other_input").removeClass('d-none');
        var drug_name = $("#other_drug").val()
        if (drug_name == "") {
            $("#other_input").addClass('d-none')
        } else {
            $('#other_input #text_label').text(`Weight in grams of ${drug_name}`)
        }
    });
</script>
<script>
    $(document).on('click', '#approve_btn', function() {
        var id = $(this).attr('data-id');
        fetch(`approve_chemistry_three.php?id=${id}`)
            .then(res => res.json())
            .then(data => {
                if (data.success == 1) {
                    alert("Case approved successfully");
                    location.reload();
                }
            })
    })
</script>
<?php
include "../src/connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $level = mysqli_real_escape_string($conn, $_POST['level']);
    $unit = mysqli_real_escape_string($conn, $_POST['unit']);

    $sql = "INSERT INTO users (username, email, password, level, unit) 
            VALUES ('$username', '$email', '$password', '$level', '$unit')";

    
    if (mysqli_query($conn, $sql)) {
        header("Location: accounts.php");
        exit();
    } else {
        
        echo "Error: " . mysqli_error($conn);
    }
}

mysqli_close($conn);

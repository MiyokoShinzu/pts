<?php
include "../src/connection.php";
include "globals/head.php";
?>


<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>

        <main class="content bg-white">
            <div class="container-fluid p-0">
      

                <div class="row bg-white p-2 border">
                    <div class="mb-3 col-lg-12 text-end">
                        <button class="btn btn-primary text-white" data-bs-toggle="modal" data-bs-target="#add_user">Add user</button>
                    </div>
                    <div class="mb-3 col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">
                            <div class="card-header">
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered table-striped table-hover" id="user_table">
                                    <thead>
                                        <tr cla class="bg-primary w-100">
                                            <th class="text-white ">Username</th>
                                            <th class="text-white ">Email</th>
                                            <th class="text-white ">Level</th>
                                            <th class="text-white ">Unit</th>
                                            <th class="text-white ">Action</th>



                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sql = "SELECT * FROM users";
                                        $result = mysqli_query($conn, $sql);

                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_assoc($result)) {
                                                echo "<tr class='text-black'>";
                                                echo "<td>" . $row['username'] . "</td>";
                                                echo "<td>" . $row['email'] . "</td>";

                                                if ($row['level'] == '1') {
                                                    $level = "Admin";
                                                    echo "<td>" . $level . "</td>";
                                                } else    if ($row['level'] == '2') {
                                                    $level = "Validator";
                                                    echo "<td>" . $level . "</td>";
                                                } else if ($row['level'] == '3') {
                                                    $level = "Encoder";
                                                    echo "<td>" . $level . "</td>";
                                                }
                                                else{
                                                    echo "<td>" . "n/a" . "</td>";
                                                }

                                                
                                                echo "<td>" . $row['unit'] . "</td>";
                                                echo "<td class='text-center'><button class='btn btn-danger btn-sm'  id='delete_btn' data-id='" . $row['id'] . "'>Delete</button></td>";
                                                echo "</tr>";
                                            }
                                        } 

                                        // Close the database connection
                                        mysqli_close($conn);
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>



                    <div class="mb-3 col-lg-10 mx-auto bg-white">
                        <div class="table-responsive">

                        </div>
                    </div>

                </div>
            </div>

        


            <div class="modal" tabindex="-1" id="add_user" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-xl centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">

                            <h6 class="modal-title">Add New User</h6>
                        </div>
                        <div class="modal-body">
                            <form method="post" action="insert_account.php">
                                <div class="row">
                                    <div class="mb-3 col-lg-4">
                                        <div class="form-floating">
                                            <input placeholder="" type="text" name="username" class="form-control" required>
                                            <label for="" class="mb-1" style="font-weight: bold;">Username</label>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-4">
                                        <div class="form-floating">
                                            <input placeholder="" type="email" name="email" class="form-control" required>
                                            <label for="" class="mb-1" style="font-weight: bold;">Email</label>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-4">
                                        <div class="form-floating">
                                            <input placeholder="" type="password" name="password" class="form-control" required>
                                            <label for="" class="mb-1" style="font-weight: bold;">Password</label>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-floating">
                                            <select id="" class="form-select" name="level">
                                                <option value="2">Validator</option>
                                                <option value="3">Encoder</option>
                                            </select>
                                            <label for="" class="mb-1" style="font-weight: bold;">Level</label>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-floating">
                                            <select id="" class="form-select" name="unit">
                                                <option value="RFU2 HQS">RFU2 HQS</option>
                                                <option value="CPFU">CPFU</option>
                                                <option value="IPFU">IPFU</option>
                                                <option value="CCFU">CCFU</option>
                                                <option value="SCFU">SCFU</option>
                                                <option value="QPFU">QPFU</option>
                                                <option value="NVPFU">NVPFU</option>
                                                <option value="TCSFO">TCSFO</option>
                                                <option value="RMPSFO">RMPSFO</option>
                                            </select>
                                            <label for="" class="mb-1" style="font-weight: bold;">Unit</label>
                                        </div>
                                    </div>
                                    <div class="col-md-12 text-end">
                                        <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button class="btn btn-info" value="submit" type="submit">Submit</button>
                                    </div>
                                </div>
                            </form>



                        </div>

                    </div>
                </div>
            </div>

        </main>


    </div>
</div>




<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#chem_table').DataTable({
        responsive: true,
        dom: "BfrQltip"
    })
</script>
<script>
    $(document).on('click', "#delete_btn", function() {
        var id = $(this).attr("data-id");
        fetch(`delete_account.php?id=${id}`)
            .then(res => res.json())
            .then(data => {
                if (data.success == 1) {
                    alert("Deleted Successfully");
                    location.reload();
                } else {
                    console.error();
                }
            })
    })
</script>
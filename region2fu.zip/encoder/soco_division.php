<?php
include "../src/connection.php";
include "globals/head.php";
?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $case_number = $_POST["case_number"];
    $nature_of_case = $_POST["nature_of_case"];
    $exam_type = $_POST["exam_type_input"]; // Convert array to comma-separated string
    $soco_classification = $_POST["soco_classification"];
    $victims = $_POST["victims"];
    $suspects = $_POST["suspects"];
    $occurrence_info = $_POST["occurrence_info"];
    $investigator = $_POST["investigator"];
    $ioc_contact = $_POST["ioc_contact"];
    $soco_leader = $_POST["soco_leader"];
    $exam_type_secondary = $_POST["exam_type_secondary"];
    $duty_receiving_pnco = $_POST["duty_receiving_pnco"];
    $caller_name = $_POST["caller_name"];
    $call_datetime = $_POST["call_datetime"];
    $requesting_party = $_POST["requesting_party"];
    $remarks = $_POST["remarks"];
    $unit = $_SESSION['unit'];
    $status = "Pending";
    // Prepare SQL statement
    $sql = "INSERT INTO soco (case_number, nature_of_case, exam_type, soco_classification, victims, suspects, occurrence_info, investigator, ioc_contact, soco_leader, exam_type_secondary, duty_receiving_pnco, caller_name, call_datetime, requesting_party, remarks, status, unit) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssssssssssss", $case_number, $nature_of_case, $exam_type, $soco_classification, $victims, $suspects, $occurrence_info, $investigator, $ioc_contact, $soco_leader, $exam_type_secondary, $duty_receiving_pnco, $caller_name, $call_datetime, $requesting_party, $remarks, $status, $unit);

    // Get form data


    // Execute the statement
    if ($stmt->execute()) {
        echo "New record created successfully";
        header("Location: soco_division.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close statement and connection
    $stmt->close();
}
?>
<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>

        <main class="content bg-white">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">SOCO Division</h1>

                <div class="row bg-white p-2 border">
                    <div class="col-lg-12 mx-auto bg-white">
                        <div class="table-responsive p-3">
                            <table class="table w-100 table-bordered p-2 bg-white mx-auto" id="soco_table">
                                <thead class="border border-primary bg-info">
                                    <tr>
                                        <th class="text-white">Actions</th>
                                        <th class="text-white">Status</th>
                                        <th class="text-white">Case Number</th>
                                        <th class="text-white">Nature of Case</th>
                                        <th class="text-white">Type of Examination</th>
                                        <th class="text-white">SOCO Classification</th>
                                        <th class="text-white">Victims</th>
                                        <th class="text-white">Suspects</th>
                                        <th class="text-white">Occurrence Info</th>
                                        <th class="text-white">Investigator</th>
                                        <th class="text-white">IOC Contact</th>
                                        <th class="text-white">SOCO Team Leader</th>
                                        <th class="text-white">Duty Receiving PNCO</th>
                                        <th class="text-white">Caller Name</th>
                                        <th class="text-white">Call Datetime</th>
                                        <th class="text-white">Requesting Party</th>
                                        <th class="text-white">Remarks</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql = "SELECT * FROM soco where unit = '$unit'";
                                    $result = $conn->query($sql);
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        include 'globals/action_buttons.php';

                                        if ($row["status"] == "Pending") {
                                            $el = "<span class='badge bg-warning  text-center text-white'>" . $row["status"] . "</span>";
                                        } else if ($row["status"] == "Reviewed") {
                                            $el = "<span class='badge bg-info  text-center text-white'>" . $row["status"] . "</span>";
                                        } else if ($row["status"] == "With Revisions") {
                                            $el = "<span class='badge bg-danger  text-center text-white'>" . $row["status"] . "</span>";
                                        } else if ($row["status"] == "Approved") {
                                            $el = "<span class='badge bg-success  text-center text-white'>" . $row["status"] . "</span>";
                                        } else {
                                            $el = "<span class='badge bg-secondary  text-center text-white'>" . "N/A" . "</span>";
                                        }
                                        echo "<td class='text-center'>" . $el . "</td>";


                                        echo "

                                        <td>{$row['case_number']}</td>
                                        <td>{$row['nature_of_case']}</td>
                                        <td>{$row['exam_type']}</td>
                                        <td>{$row['soco_classification']}</td>
                                        <td>{$row['victims']}</td>
                                        <td>{$row['suspects']}</td>
                                        <td>{$row['occurrence_info']}</td>
                                        <td>{$row['investigator']}</td>
                                        <td>{$row['ioc_contact']}</td>
                                        <td>{$row['soco_leader']}</td>
                                        <td>{$row['duty_receiving_pnco']}</td>
                                        <td>{$row['caller_name']}</td>
                                        <td>{$row['call_datetime']}</td>
                                        <td>{$row['requesting_party']}</td>
                                        <td>{$row['remarks']}</td>
                                    </tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>




            <div class="modal" tabindex="-1" id="add_soco_case" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-info">
                            <h4 class="text-white">Scene of Crime Operations</h4>

                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <div class="row p-1">
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="case_number">Case Number</label>
                                            <input type="text" class="form-control" id="case_number" name="case_number">
                                        </div>
                                    </div>

                                    <div class="mb-3 col-md-6">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" required name="nature_of_case" class="form-select">
                                                <option value="ALLEGED SHOOTING INCIDENT">ALLEGED SHOOTING INCIDENT</option>
                                                <option value="SHOOTING INCIDENT">SHOOTING INCIDENT</option>
                                                <option value="FOUND DEAD BODY">FOUND DEAD BODY</option>
                                                <option value="FIRE INCIDENT">FIRE INCIDENT</option>
                                                <option value="VEHICULAR ACCIDENT">VEHICULAR ACCIDENT</option>
                                                <option value="ROBBERY INCIDENT">ROBBERY INCIDENT</option>
                                                <option value="ALLEGED ROBBERY INCIDENT">ALLEGED ROBBERY INCIDENT</option>
                                                <option value="THEFT">THEFT</option>
                                                <option value="ALLEGED THEFT">ALLEGED THEFT</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="dissolve" placeholder="Enter other nature of case">
                                            </div>
                                        </div>

                                    </div>
                                    <hr>
                                    <div class="mb-3 col-lg-12">
                                        <div class="row">
                                            <div class="col-12 mb-1">
                                                <label class="strong mb-1" for="exam_types">Type of Examination</label><br>
                                                <input type="text" readonly class="form-control" id="exam_type_input" name="exam_type_input" placeholder="Check the values below to update data">
                                            </div>
                                            <div class="col-3">
                                                <input type="checkbox" class="form-checkbox" id="chemistry" name="exam_type" value="Chemistry" onchange="updateExamType()">
                                                <label class="strong mb-1" for="chemistry">Chemistry</label><br>
                                                <input type="checkbox" class="form-checkbox" id="forensic_photography" name="exam_type" value="Forensic Photography" onchange="updateExamType()">
                                                <label class="strong mb-1" for="forensic_photography">Forensic Photography</label><br>
                                            </div>
                                            <div class="col-3">
                                                <input type="checkbox" class="form-checkbox" id="polygraph" name="exam_type" value="Polygraph" onchange="updateExamType()">
                                                <label class="strong mb-1" for="polygraph">Polygraph</label><br>
                                                <input type="checkbox" class="form-checkbox" id="fingerprint" name="exam_type" value="Fingerprint" onchange="updateExamType()">
                                                <label class="strong mb-1" for="fingerprint">Fingerprint</label><br>
                                            </div>
                                            <div class="col-3">
                                                <input type="checkbox" class="form-checkbox" id="dna_analysis" name="exam_type" value="DNA Analysis" onchange="updateExamType()">
                                                <label class="strong mb-1" for="dna_analysis">DNA Analysis</label><br>
                                                <input type="checkbox" class="form-checkbox" id="physical_identification" name="exam_type" value="Physical Identification" onchange="updateExamType()">
                                                <label class="strong mb-1" for="physical_identification">Physical Identification</label><br>
                                            </div>
                                            <div class="col-3">
                                                <input type="checkbox" class="form-checkbox" id="autopsy" name="exam_type" value="Autopsy" onchange="updateExamType()">
                                                <label class="strong mb-1" for="autopsy">Autopsy</label><br>
                                                <input type="checkbox" class="form-checkbox" id="ballistic" name="exam_type" value="Ballistic / Firearms" onchange="updateExamType()">
                                                <label class="strong mb-1" for="ballistic">Ballistic / Firearms</label><br>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="soco_classification">S.O.C.O Classification</label>
                                            <select name="soco_classification" class="form-select" id="soc_classification">
                                                <option value="Sensational">Sensational</option>
                                                <option value="Non-sensational">Non-sensational</option>
                                                <option value="Field Laboratory Work">Field Laboratory Work</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="victims">Victim/s</label>
                                            <input type="text" class="form-control" id="victims" name="victims">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="suspects">Suspect/s</label>
                                            <input type="text" class="form-control" id="suspects" name="suspects">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="occurrence_info">Time and Date & Place of Occurrence</label>
                                            <input type="text" class="form-control" id="occurrence_info" name="occurrence_info">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="investigator">Investigator on Case</label>
                                            <input type="text" class="form-control" id="investigator" name="investigator">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="ioc_contact">IOC Contact Number</label>
                                            <input type="text" class="form-control" id="ioc_contact" name="ioc_contact">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="soco_leader">SOCO Team Leader</label>
                                            <input type="text" class="form-control" id="soco_leader" name="soco_leader">
                                        </div>
                                    </div>

                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="duty_receiving_pnco">Duty Receiving PNCO</label>
                                            <input type="text" class="form-control" id="duty_receiving_pnco" name="duty_receiving_pnco">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="caller_name">Name of Caller</label>
                                            <input type="text" class="form-control" id="caller_name" name="caller_name">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="call_datetime">Time and Date of Call</label>
                                            <input type="datetime-local" class="form-control" id="call_datetime" name="call_datetime">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="requesting_party">Requesting Party</label>
                                            <input type="text" class="form-control" id="requesting_party" name="requesting_party">
                                        </div>
                                    </div>

                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="remarks">Remarks</label>
                                            <input type="text" class="form-control" id="remarks" name="remarks">
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-end">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary" value="submit">Submit</button>
                                        <!-- PDF file only -->
                                    </div>

                                </div>
                            </form>



                        </div>

                    </div>
                </div>
            </div>

            <?php
            $div = "SOCO";
            include "globals/file_modal.php";
            ?>

            <div class="modal" tabindex="-1" id="edit_case_modal" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-info">
                            <h4 class="text-white">Scene of Crime Operations</h4>

                        </div>
                        <div class="modal-body">
                            <form action="" method="post" id="edit_form">
                                <div class="row p-1">
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="case_number">Case Number</label>
                                            <input type="text" class="form-control" id="case_number" name="case_number">
                                        </div>
                                    </div>

                                    <div class="mb-3 col-md-6">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" required name="nature_of_case" class="form-select">
                                                <option value="ALLEGED SHOOTING INCIDENT">ALLEGED SHOOTING INCIDENT</option>
                                                <option value="SHOOTING INCIDENT">SHOOTING INCIDENT</option>
                                                <option value="FOUND DEAD BODY">FOUND DEAD BODY</option>
                                                <option value="FIRE INCIDENT">FIRE INCIDENT</option>
                                                <option value="VEHICULAR ACCIDENT">VEHICULAR ACCIDENT</option>
                                                <option value="ROBBERY INCIDENT">ROBBERY INCIDENT</option>
                                                <option value="ALLEGED ROBBERY INCIDENT">ALLEGED ROBBERY INCIDENT</option>
                                                <option value="THEFT">THEFT</option>
                                                <option value="ALLEGED THEFT">ALLEGED THEFT</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="dissolve" placeholder="Enter other nature of case">
                                            </div>
                                        </div>

                                    </div>
                                    <hr>
                                    <div class="mb-3 col-lg-12">
                                        <div class="row">
                                            <div class="col-12 mb-1">
                                                <label class="strong mb-1" for="exam_types">Type of Examination</label><br>
                                                <input type="text" readonly class="form-control" id="exam_type_input2" name="exam_type_input2" placeholder="Check the values below to update data">
                                            </div>
                                            <div class="col-3">
                                                <input type="checkbox" class="form-checkbox" id="chemistry" name="exam_type" value="Chemistry" onchange="updateExamType2()">
                                                <label class="strong mb-1" for="chemistry">Chemistry</label><br>
                                                <input type="checkbox" class="form-checkbox" id="forensic_photography" name="exam_type" value="Forensic Photography" onchange="updateExamType2()">
                                                <label class="strong mb-1" for="forensic_photography">Forensic Photography</label><br>
                                            </div>
                                            <div class="col-3">
                                                <input type="checkbox" class="form-checkbox" id="polygraph" name="exam_type" value="Polygraph" onchange="updateExamType2()">
                                                <label class="strong mb-1" for="polygraph">Polygraph</label><br>
                                                <input type="checkbox" class="form-checkbox" id="fingerprint" name="exam_type" value="Fingerprint" onchange="updateExamType2()">
                                                <label class="strong mb-1" for="fingerprint">Fingerprint</label><br>
                                            </div>
                                            <div class="col-3">
                                                <input type="checkbox" class="form-checkbox" id="dna_analysis" name="exam_type" value="DNA Analysis" onchange="updateExamType2()">
                                                <label class="strong mb-1" for="dna_analysis">DNA Analysis</label><br>
                                                <input type="checkbox" class="form-checkbox" id="physical_identification" name="exam_type" value="Physical Identification" onchange="updateExamType2()">
                                                <label class="strong mb-1" for="physical_identification">Physical Identification</label><br>
                                            </div>
                                            <div class="col-3">
                                                <input type="checkbox" class="form-checkbox" id="autopsy" name="exam_type" value="Autopsy" onchange="updateExamType2()">
                                                <label class="strong mb-1" for="autopsy">Autopsy</label><br>
                                                <input type="checkbox" class="form-checkbox" id="ballistic" name="exam_type" value="Ballistic / Firearms" onchange="updateExamType2()">
                                                <label class="strong mb-1" for="ballistic">Ballistic / Firearms</label><br>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="soco_classification">S.O.C.O Classification</label>
                                            <select name="soco_classification" class="form-select" id="soc_classification">
                                                <option value="Sensational">Sensational</option>
                                                <option value="Non-sensational">Non-sensational</option>
                                                <option value="Field Laboratory Work">Field Laboratory Work</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="victims">Victim/s</label>
                                            <input type="text" class="form-control" id="victims" name="victims">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="suspects">Suspect/s</label>
                                            <input type="text" class="form-control" id="suspects" name="suspects">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="occurrence_info">Time and Date & Place of Occurrence</label>
                                            <input type="text" class="form-control" id="occurrence_info" name="occurrence_info">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="investigator">Investigator on Case</label>
                                            <input type="text" class="form-control" id="investigator" name="investigator">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="ioc_contact">IOC Contact Number</label>
                                            <input type="text" class="form-control" id="ioc_contact" name="ioc_contact">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="soco_leader">SOCO Team Leader</label>
                                            <input type="text" class="form-control" id="soco_leader" name="soco_leader">
                                        </div>
                                    </div>

                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="duty_receiving_pnco">Duty Receiving PNCO</label>
                                            <input type="text" class="form-control" id="duty_receiving_pnco" name="duty_receiving_pnco">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="caller_name">Name of Caller</label>
                                            <input type="text" class="form-control" id="caller_name" name="caller_name">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="call_datetime">Time and Date of Call</label>
                                            <input type="datetime-local" class="form-control" id="call_datetime" name="call_datetime">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="requesting_party">Requesting Party</label>
                                            <input type="text" class="form-control" id="requesting_party" name="requesting_party">
                                        </div>
                                    </div>

                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="remarks">Remarks</label>
                                            <input type="text" class="form-control" id="remarks" name="remarks">
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-end">
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-info" value="submit" id="update_btn">Submit</button>
                                        <!-- PDF file only -->
                                    </div>

                                </div>
                            </form>



                        </div>

                    </div>
                </div>
            </div>

        </main>


    </div>
</div>

<script src=" https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#soco_table').DataTable({
          dom: 'fQrBtip',
                    responsive: true,
                    buttons: [
                         {
                text: 'Add Case', // Button text
                className: 'add_case', // Optional: Custom class for styling
                attr: {
                    'data-bs-toggle': 'modal', // Custom attribute and its value
                    'data-bs-target': '#add_soco_case', // Another example of a custom attribute
                    'title': 'Click to add case' // Tooltip title
                },

            },

                        {
                            extend: 'excel',
                            text: 'Excel',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'pdf',
                            text: 'PDF',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'print',
                            text: 'Print',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'colvis',
                            text: 'Show/Hide Columns',
                        }
                    ],
                    fixedHeader: true,
                    paging: true,
                    searching: true,
                    ordering: true,
                    scrollY: '300px',
                    colReorder: true,
                    scrollCollapse: true,
                    language: {
                        search: "Search:"

                    },
                });
</script>
<script>
    $(document).on("input", "#other_drug", function() {
        $("#other_input").removeClass('d-none');
        var drug_name = $("#other_drug").val()
        if (drug_name == "") {
            $("#other_input").addClass('d-none')
        } else {
            $('#other_input #text_label').text(`Weight in grams of ${drug_name}`)
        }
    })
</script>
<script>
    function updateExamType() {
        const checkboxes = document.querySelectorAll('input[name="exam_type"]');
        const checkedValues = [];
        checkboxes.forEach(checkbox => {
            console.log(checkbox.value)
            if (checkbox.checked) {
                checkedValues.push(checkbox.value);

            }
        });
        const valuesString = checkedValues.join(',');
        document.getElementById('exam_type_input').value = valuesString;

    }
</script>
<script>
    function updateExamType2() {
        const checkboxes = document.querySelectorAll('#edit_form input[name="exam_type"]');
        const checkedValues = [];
        checkboxes.forEach(checkbox => {
            console.log(checkbox.value)
            if (checkbox.checked) {
                checkedValues.push(checkbox.value);

            }
        });
        const valuesString = checkedValues.join(',');
        document.getElementById('exam_type_input2').value = valuesString;

    }
</script>
<?php include "globals/dt_style.php"; ?>

<?php
include "globals/modal_scripts.php";
?>


<script>
    $(document).on('click', '#edit_case', function() {
        var case_id = $(this).attr('data-case_id');
        $('#update_btn').attr('data-case_id', case_id);

        // Fetch the data from the server
        fetch(`./edit_handlers/soco_division.php?case_id=${case_id}`)
            .then(response => response.json()) // Parse the JSON response
            .then(data => {
                console.log(data[0]);

                // Assign values to each input field
                $("#edit_form input[name='case_number']").val(data[0].case_number);
                $("#edit_form input[name='exam_type_input']").val(data[0].exam_type);
                $("#edit_form select[name='soco_classification']").val(data[0].soco_classification);
                $("#edit_form input[name='victims']").val(data[0].victims);
                $("#edit_form input[name='suspects']").val(data[0].suspects);
                $("#edit_form input[name='occurrence_info']").val(data[0].occurrence_info);
                $("#edit_form input[name='investigator']").val(data[0].investigator);
                $("#edit_form input[name='ioc_contact']").val(data[0].ioc_contact);
                $("#edit_form input[name='soco_leader']").val(data[0].soco_leader);
                $("#edit_form input[name='exam_type_input2']").val(data[0].exam_type);
                $("#edit_form input[name='duty_receiving_pnco']").val(data[0].duty_receiving_pnco);
                $("#edit_form input[name='caller_name']").val(data[0].caller_name);
                $("#edit_form input[name='call_datetime']").val(data[0].call_datetime);
                $("#edit_form input[name='requesting_party']").val(data[0].requesting_party);
                $("#edit_form input[name='remarks']").val(data[0].remarks);
                $("#edit_form select[name='nature_of_case']").append(`<option value='${data[0].nature_of_case}'>${data[0].nature_of_case}</option>`);
                $("#edit_form select[name='nature_of_case']").val(`${data[0].nature_of_case}`);
                // Display the modal or form after data is populated
                $('#edit_case_modal').modal('show');
            })
            .catch(err => {
                console.error(err);
            });
    });
</script>



<script>
    $(document).on('click', '#update_btn', function(e) {
        e.preventDefault();

        var case_id = $(this).attr('data-case_id'); // Assuming you get the case_id from somewhere
        var formData = $("#edit_form").serialize();

        // Append case_id to formData
        formData += '&case_id=' + encodeURIComponent(case_id);
        console.log(formData)
        fetch(`./update_handlers/soco_division.php?${formData}`)
            .then(response => response.json())
            .then(data => {
                if (data.success == true) {
                    alert("Updated successfully");
                    window.location.reload()
                }
                // Handle success: maybe redirect or update UI
            })
            .catch((error) => {
                console.error('Error:', error);
            });


    })
</script>
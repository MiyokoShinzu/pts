  <?php
    include "../src/connection.php";

    include "globals/head.php";
    ?>

  <body>
      <div class="wrapper">
          <?php
            include "globals/sidebar.php";
            ?>

          <div class="main">
              <?php include "globals/topbar.php"; ?>
              <div class="row bg-white">
                  <div class="col-lg-11 mx-auto mt-2" style="background: #222e3c;">
                      <h2 class="text-white text-center p-2"><?php echo "$unit Sections"; ?></h2>
                  </div>
                  <div class="col-lg-11 mx-auto mt-2">
                      <div class="row">
                          <div class="col-lg-3">
                              <div class="card bg-info">
                                  <div class="card-body">
                                      <h4 class="card-title text-white">Question Document</h4>

                                      <p class="card-text text-white">
                                          <?php
                                            include '../src/connection.php';

                                            $sql = "Select count(*) as c from qd where unit = '$unit'";
                                            $result = $conn->query($sql);
                                            $data = array();
                                            $row = $result->fetch_assoc();
                                            echo "<h3 class='text-white'>" . $row['c'] . " Case/s</h3>";


                                            ?>

                                      </p>
                                      <div class="icons w-100 text-end">
                                          <i class="bi bi-briefcase-fill text-white"></i>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="col-lg-3">
                              <div class="card bg-primary">
                                  <div class="card-body">
                                      <h4 class="card-title text-white">SOCO</h4>

                                      <p class="card-text text-white">
                                          <?php
                                            include '../src/connection.php';

                                            $sql = "Select count(*) as c from soco where unit = '$unit'";
                                            $result = $conn->query($sql);
                                            $data = array();
                                            $row = $result->fetch_assoc();
                                            echo "<h3 class='text-white'>" . $row['c'] . " Case/s</h3>";


                                            ?>

                                      </p>
                                      <div class="icons w-100 text-end">
                                          <i class="bi bi-briefcase-fill text-white"></i>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="col-lg-3">
                              <div class="card bg-warning">
                                  <div class="card-body">
                                      <h4 class="card-title text-white">Chemistry</h4>

                                      <p class="card-text text-white">
                                          <?php
                                            include '../src/connection.php';

                                            $sql = "Select count(*) as c from chemistry_one where unit = '$unit'";
                                            $result = $conn->query($sql);
                                            $data = array();
                                            $row = $result->fetch_assoc();
                                            echo "<h3 class='text-white'>" . $row['c'] . " Case/s</h3>";


                                            ?>

                                      </p>
                                      <div class="icons w-100 text-end">
                                          <i class="bi bi-briefcase-fill text-white"></i>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="col-lg-3">
                              <div class="card bg-danger">
                                  <div class="card-body">
                                      <h4 class="card-title text-white">Chemistry (Drug)</h4>

                                      <p class="card-text text-white">
                                          <?php
                                            include '../src/connection.php';

                                            $sql = "Select count(*) as c from chemistry_two where unit = '$unit'";
                                            $result = $conn->query($sql);
                                            $data = array();
                                            $row = $result->fetch_assoc();
                                            echo "<h3 class='text-white'>" . $row['c'] . " Case/s</h3>";


                                            ?>

                                      </p>
                                      <div class="icons w-100 text-end">
                                          <i class="bi bi-briefcase-fill text-white"></i>
                                      </div>
                                  </div>
                              </div>
                          </div>

                          <div class="col-lg-3">
                              <div class="card bg-success">
                                  <div class="card-body">
                                      <h4 class="card-title text-white">Chemistry (Drug Test)</h4>

                                      <p class="card-text text-white">
                                          <?php
                                            include '../src/connection.php';

                                            $sql = "Select count(*) as c from chemistry_three where unit = '$unit'";
                                            $result = $conn->query($sql);
                                            $data = array();
                                            $row = $result->fetch_assoc();
                                            echo "<h3 class='text-white'>" . $row['c'] . " Case/s</h3>";


                                            ?>

                                      </p>
                                      <div class="icons w-100 text-end">
                                          <i class="bi bi-briefcase-fill text-white"></i>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="col-lg-3">
                              <div class="card" style="background: var(--bs-orange);">
                                  <div class="card-body">
                                      <h4 class="card-title text-white">DNA</h4>

                                      <p class="card-text text-white">
                                          <?php
                                            include '../src/connection.php';

                                            $sql = "Select count(*) as c from dna where unit = '$unit'";
                                            $result = $conn->query($sql);
                                            $data = array();
                                            $row = $result->fetch_assoc();
                                            echo "<h3 class='text-white'>" . $row['c'] . " Case/s</h3>";


                                            ?>

                                      </p>
                                      <div class="icons w-100 text-end">
                                          <i class="bi bi-briefcase-fill text-white"></i>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="col-lg-3">
                              <div class="card " style="background: var(--bs-purple);">
                                  <div class="card-body">
                                      <h4 class="card-title text-white">Fingerprint Identification</h4>

                                      <p class="card-text text-white">
                                          <?php
                                            include '../src/connection.php';

                                            $sql = "Select count(*) as c from fi where unit = '$unit'";
                                            $result = $conn->query($sql);
                                            $data = array();
                                            $row = $result->fetch_assoc();
                                            echo "<h3 class='text-white'>" . $row['c'] . " Case/s</h3>";


                                            ?>

                                      </p>
                                      <div class="icons w-100 text-end">
                                          <i class="bi bi-briefcase-fill text-white"></i>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="col-lg-3">
                              <div class="card" style="background: var(--bs-warning-text-emphasis);">
                                  <div class="card-body">
                                      <h4 class="card-title text-white">Forensic Photography</h4>

                                      <p class="card-text text-white">
                                          <?php
                                            include '../src/connection.php';

                                            $sql = "Select count(*) as c from fp where unit = '$unit'";
                                            $result = $conn->query($sql);
                                            $data = array();
                                            $row = $result->fetch_assoc();
                                            echo "<h3 class='text-white'>" . $row['c'] . " Case/s</h3>";


                                            ?>

                                      </p>
                                      <div class="icons w-100 text-end">
                                          <i class="bi bi-briefcase-fill text-white"></i>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="col-lg-3">
                              <div class="card " style="background: var(--bs-pink)">
                                  <div class="card-body">
                                      <h4 class="card-title text-white">Medico Legal</h4>

                                      <p class="card-text text-white">
                                          <?php
                                            include '../src/connection.php';

                                            $sql = "Select count(*) as c from ml where unit = '$unit'";
                                            $result = $conn->query($sql);
                                            $data = array();
                                            $row = $result->fetch_assoc();
                                            echo "<h3 class='text-white'>" . $row['c'] . " Case/s</h3>";


                                            ?>

                                      </p>
                                      <div class="icons w-100 text-end">
                                          <i class="bi bi-briefcase-fill text-white"></i>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="col-lg-3">
                              <div class="card " style="background: var(--bs-secondary)">
                                  <div class="card-body">
                                      <h4 class="card-title text-white">Physical Identification</h4>

                                      <p class="card-text text-white">
                                          <?php
                                            include '../src/connection.php';

                                            $sql = "Select count(*) as c from pi where unit = '$unit'";
                                            $result = $conn->query($sql);
                                            $data = array();
                                            $row = $result->fetch_assoc();
                                            echo "<h3 class='text-white'>" . $row['c'] . " Case/s</h3>";


                                            ?>

                                      </p>
                                      <div class="icons w-100 text-end">
                                          <i class="bi bi-briefcase-fill text-white"></i>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="col-lg-3">
                              <div class="card" style="background: var(--bs-red)">
                                  <div class="card-body">
                                      <h4 class="card-title text-white">Firearms Identification</h4>

                                      <p class="card-text text-white">
                                          <?php
                                            include '../src/connection.php';

                                            $sql = "Select count(*) as c from fi where unit = '$unit'";
                                            $result = $conn->query($sql);
                                            $data = array();
                                            $row = $result->fetch_assoc();
                                            echo "<h3 class='text-white'>" . $row['c'] . " Case/s</h3>";


                                            ?>

                                      </p>
                                      <div class="icons w-100 text-end">
                                          <i class="bi bi-briefcase-fill text-white"></i>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="col-lg-3">
                              <div class="card" style="background: var(--bs-orange)">
                                  <div class="card-body">
                                      <h4 class="card-title text-white">Polygraph</h4>

                                      <p class="card-text text-white">
                                          <?php
                                            include '../src/connection.php';

                                            $sql = "Select count(*) as c from polygraph where unit = '$unit'";
                                            $result = $conn->query($sql);
                                            $data = array();
                                            $row = $result->fetch_assoc();
                                            echo "<h3 class='text-white'>" . $row['c'] . " Case/s</h3>";


                                            ?>

                                      </p>
                                      <div class="icons w-100 text-end">
                                          <i class="bi bi-briefcase-fill text-white"></i>
                                      </div>
                                  </div>
                              </div>
                          </div>


                      </div>

                  </div>
                  



              </div>
          </div>
      </div>
      <?php
        include "globals/footer.php";
        ?>
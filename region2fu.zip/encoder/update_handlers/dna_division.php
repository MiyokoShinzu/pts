<?php
// Include your database connection file
include '../../src/connection.php';

// Check if the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Retrieve all GET parameters
    $case_number = $_GET['case_number'];
    $cases_received = $_GET['cases_received'];
    $examinations = $_GET['examinations'];
    $time_date_received = $_GET['time_date_received'];
    $time_date_completed = $_GET['time_date_completed'];
    $specimen_submitted = $_GET['specimen_submitted'];
    $requesting_party = $_GET['requesting_party'];
    $delivered_by = $_GET['delivered_by'];
    $victims = $_GET['victims'];
    $suspects = $_GET['suspects'];
    $examiner = $_GET['examiner'];
    $time_date_place = $_GET['time_date_place'];
    $nature_of_case = $_GET['nature_of_case'];
    $remarks = $_GET['remarks'];
    $case_id = $_GET['case_id']; // Assuming case_id is passed in the GET request

    // Prepare SQL statement for update
    $sql = "UPDATE dna 
            SET 
                case_number = ?, 
                cases_received = ?, 
                examinations = ?, 
                time_date_received = ?, 
                time_date_completed = ?, 
                specimen_submitted = ?, 
                requesting_party = ?, 
                delivered_by = ?, 
                victims = ?, 
                suspects = ?, 
                examiner = ?, 
                time_date_place = ?, 
                nature_of_case = ?, 
                remarks = ?
            WHERE 
                id = ?";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "siisssssssssssi",
        $case_number,
        $cases_received,
        $examinations,
        $time_date_received,
        $time_date_completed,
        $specimen_submitted,
        $requesting_party,
        $delivered_by,
        $victims,
        $suspects,
        $examiner,
        $time_date_place,
        $nature_of_case,
        $remarks,
        $case_id
    );

    // Execute the statement
    if ($stmt->execute()) {
        // If update is successful, prepare JSON response
        $response = [
            'success' => true,
            'message' => 'Record updated successfully.'
        ];
    } else {
        // If there's an error, prepare JSON response
        $response = [
            'success' => false,
            'message' => 'Error updating record: ' . $stmt->error
        ];
    }

    // Close statement
    $stmt->close();

    // Output JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
}

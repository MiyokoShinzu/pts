<?php
include '../../src/connection.php';

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $case_id = $_GET['case_id'];
    $case_number = $_GET['case_number'];
    $case_count = $_GET['case_count'];
    $exam_count = $_GET['exam_count'];
    $exam_type = $_GET['exam_type'];
    $datetime_received = $_GET['datetime_received'];
    $datetime_completed = $_GET['datetime_completed'];
    $requesting_party = $_GET['requesting_party'];
    $delivered_by = $_GET['delivered_by'];
    $victim = $_GET['victim'];
    $suspect = $_GET['suspect'];
    $examiner = $_GET['examiner'];
    $tdpo = $_GET['tdpo'];
    $case_nature = $_GET['nature_of_case'];
    $remarks = $_GET['remarks'];
   

    // Prepare the SQL update statement
    $sql = "UPDATE qd 
            SET 
                case_number = ?, 
                case_count = ?, 
                exam_count = ?, 
                exam_type = ?, 
                datetime_received = ?, 
                datetime_completed = ?, 
                requesting_party = ?, 
                delivered_by = ?, 
                victim = ?, 
                suspect = ?, 
                examiner = ?, 
                tdpo = ?, 
                case_nature = ?, 
                remarks = ?
               
            WHERE 
                id = ?";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bind_param(
        "sssssssssssssss",
        $case_number,
        $case_count,
        $exam_count,
        $exam_type,
        $datetime_received,
        $datetime_completed,
        $requesting_party,
        $delivered_by,
        $victim,
        $suspect,
        $examiner,
        $tdpo,
        $case_nature,
        $remarks,
        
        $case_id
    );

    // Execute the statement
    if ($stmt->execute()) {
        // Success response
        $response = ['success' => true, 'message' => 'Data updated successfully.'];
    } else {
        // Error response
        $response = ['success' => false, 'message' => 'Error updating data: ' . $stmt->error];
    }

    // Close statement
    $stmt->close();

    // Output response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
} 
    
<?php
// Include your database connection file
include '../../src/connection.php';

// Check if the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Retrieve all GET parameters
    $case_number = $_GET['case_number'];
    $cases_received = $_GET['cases_received'];
    $examinations = $_GET['examinations'];
    $date_received = $_GET['date_received'];
    $date_completed = $_GET['date_completed'];
    $documents_submitted = $_GET['documents_submitted'];
    $requesting_party = $_GET['requesting_party'];
    $delivered_by = $_GET['delivered_by'];
    $subject = $_GET['subject'];
    $examiner = $_GET['examiner'];
    $occurrence_datetime = $_GET['occurrence_datetime'];
    $nature_of_case = $_GET['nature_of_case'];
    $remarks = $_GET['remarks'];
   

    // Case ID to be updated
    $case_id = $_GET['case_id'];

    // Prepare SQL statement for update
    $sql = "UPDATE polygraph 
            SET 
                case_number = ?, 
                cases_received = ?, 
                examinations = ?, 
                date_received = ?, 
                date_completed = ?, 
                documents_submitted = ?, 
                requesting_party = ?, 
                delivered_by = ?, 
                subject = ?, 
                examiner = ?, 
                occurrence_datetime = ?, 
                nature_of_case = ?, 
                remarks = ?
              
            WHERE 
                id = ?";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sssssssssssssi",
        $case_number,
        $cases_received,
        $examinations,
        $date_received,
        $date_completed,
        $documents_submitted,
        $requesting_party,
        $delivered_by,
        $subject,
        $examiner,
        $occurrence_datetime,
        $nature_of_case,
        $remarks,
        
        $case_id
    );

    // Execute the statement
    if ($stmt->execute()) {
        // If update is successful, prepare JSON response
        $response = [
            'success' => true,
            'message' => 'Record updated successfully.'
        ];
    } else {
        // If there's an error, prepare JSON response
        $response = [
            'success' => false,
            'message' => 'Error updating record: ' . $stmt->error
        ];
    }

    // Close statement
    $stmt->close();

    // Output JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
}

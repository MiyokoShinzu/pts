<?php
include '../../src/connection.php';
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['case_id'])) {
    // Sanitize the case_id parameter to prevent SQL injection
    $case_id = mysqli_real_escape_string($conn, $_GET['case_id']);

    // Retrieve other POST data if needed (assuming it's passed via GET for update)
    $case_number = mysqli_real_escape_string($conn, $_GET['case_number']);
    $exam_count = mysqli_real_escape_string($conn, $_GET['exam_count']);
    $date_received = mysqli_real_escape_string($conn, $_GET['date_received']);
    $date_completed = mysqli_real_escape_string($conn, $_GET['date_completed']);
    $evidence_submitted = mysqli_real_escape_string($conn, $_GET['evidence_submitted']);
    $requesting_party = mysqli_real_escape_string($conn, $_GET['requesting_party']);
    $delivered_by = mysqli_real_escape_string($conn, $_GET['delivered_by']);
    $examiner = mysqli_real_escape_string($conn, $_GET['examiner']);
    $nature_of_case = mysqli_real_escape_string($conn, $_GET['nature_of_case']);
    $remarks = mysqli_real_escape_string($conn, $_GET['remarks']);
    $exam_type = mysqli_real_escape_string($conn, $_GET['exam_type']);
    $duty_receiving_officer = mysqli_real_escape_string($conn, $_GET['duty_receiving_officer']);
    $result_of_examination = mysqli_real_escape_string($conn, $_GET['result_of_examination']);
    // Update record in the database
    $sql_update = "UPDATE chemistry_three SET 
                    case_number = '$case_number', 
                    exam_count = '$exam_count', 
                    date_received = '$date_received', 
                    date_completed = '$date_completed', 
                    evidence_submitted = '$evidence_submitted', 
                    requesting_party = '$requesting_party', 
                    delivered_by = '$delivered_by', 
                    examiner = '$examiner', 
                    nature_of_case = '$nature_of_case', 
                    remarks = '$remarks', 
                    exam_type = '$exam_type',
                    duty_receiving_officer = '$duty_receiving_officer',
                    result_of_examination = '$result_of_examination'
                   
                  WHERE id = '$case_id'";

    if ($conn->query($sql_update) === TRUE) {
        // Construct JSON response
        $response = [
            'success' => true,
            'message' => 'Record updated successfully'
        ];

        // Send JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
        exit();
    } else {
        // Construct JSON response for error
        $response = [
            'success' => false,
            'message' => 'Error updating record: ' . $conn->error
        ];

        // Send JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
        exit();
    }
}

?>
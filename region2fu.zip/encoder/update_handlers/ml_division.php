<?php
// Include your database connection file
include '../../src/connection.php';

// Check if the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Retrieve and sanitize form data (if needed)
    $case_id = $_GET["case_id"]; // Assuming you get case_id from the request
    $case_number = $_GET["case_number"];
    $cases_received = $_GET["cases_received"];
    $examinations = $_GET["examinations"];
    $date_received = $_GET["date_received"];
    $date_completed = $_GET["date_completed"];
    $evidence_submitted = $_GET["evidence_submitted"];
    $requesting_party = $_GET["requesting_party"];
    $delivered_by = $_GET["delivered_by"];
    $victims = $_GET["victims"];
    $suspects = $_GET["suspects"];
    $examiner = $_GET["examiner"];
    $occurrence_details = $_GET["occurrence_details"];
    $nature_of_case = $_GET["nature_of_case"];
    $type_of_examination = $_GET["type_of_examination"];
    $remarks = $_GET["remarks"];

    // Prepare an SQL update statement
    $stmt = $conn->prepare("UPDATE ml SET 
                            case_number = ?, 
                            cases_received = ?, 
                            examinations = ?, 
                            date_received = ?, 
                            date_completed = ?, 
                            evidence_submitted = ?, 
                            requesting_party = ?, 
                            delivered_by = ?, 
                            victims = ?, 
                            suspects = ?, 
                            examiner = ?, 
                            occurrence_details = ?, 
                            nature_of_case = ?, 
                            type_of_examination = ?, 
                            remarks = ?
                            WHERE id = ?");

    // Bind parameters to the prepared statement
    $stmt->bind_param(
        "sssssssssssssssi",
        $case_number,
        $cases_received,
        $examinations,
        $date_received,
        $date_completed,
        $evidence_submitted,
        $requesting_party,
        $delivered_by,
        $victims,
        $suspects,
        $examiner,
        $occurrence_details,
        $nature_of_case,
        $type_of_examination,
        $remarks,
        $case_id
    );

    // Execute the statement
    if ($stmt->execute()) {
        // Update successful
        $response = array("success" => true, "message" => "Record updated successfully.");
    } else {
        // Error updating record
        $response = array("success" => false, "message" => "Error updating record: " . $stmt->error);
    }

    // Close the statement
    $stmt->close();
} else {
    // Method not supported
    $response = array("success" => false, "message" => "Method not supported.");
}

// Set headers to return JSON content type
header('Content-Type: application/json');

// Output the JSON response
echo json_encode($response);

// Close the database connection
mysqli_close($conn);

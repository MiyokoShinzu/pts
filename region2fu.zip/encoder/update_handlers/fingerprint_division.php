<?php
// Include your database connection file
include '../../src/connection.php';

// Check if the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Retrieve GET parameters
    $case_id = $_GET['case_id']; // Assuming case_id is passed via GET

    // Retrieve other parameters needed for update
    $case_number = $_GET['case_number'];
    $examinations = $_GET['examinations'];
    $date_received = $_GET['date_received'];
    $date_completed = $_GET['date_completed'];
    $evidence_submitted = $_GET['evidence_submitted']; // Assuming this is an array and needs to be converted to a comma-separated string
    $requesting_party = $_GET['requesting_party'];
    $delivered_by = $_GET['delivered_by'];
    $subject = $_GET['suspects']; // Assuming this corresponds to the subject in your database
    $examiner = $_GET['examiner'];
    $occurrence_datetime = $_GET['occurrence_datetime']; // Assuming this corresponds to the occurrence_datetime in your database
    $nature_of_case = $_GET['nature_of_case'];
    $remarks = $_GET['remarks'];
    $victims = $_GET['victims'];

    

    // Prepare SQL UPDATE statement using prepared statements
    $sql = "UPDATE fingerprint 
            SET 
                case_number = ?, 
                examinations = ?, 
                date_received = ?, 
                date_completed = ?, 
                evidence_submitted = ?, 
                requesting_party = ?, 
                delivered_by = ?, 
                subject = ?, 
                examiner = ?, 
                occurrence_datetime = ?, 
                nature_of_case = ?, 
                remarks = ?,
                victims = ?
            WHERE 
                id = ?";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sssssssssssssi",
        $case_number,
        $examinations,
        $date_received,
        $date_completed,
        $evidence_submitted,
        $requesting_party,
        $delivered_by,
        $subject,
        $examiner,
        $occurrence_datetime,
        $nature_of_case,
        $remarks,
        $victims,
        $case_id
    );

    // Execute the statement
    if ($stmt->execute()) {
        // If update is successful, prepare JSON response
        $response = ['success' => true, 'message' => 'Data updated successfully.'];
    } else {
        // If there's an error, prepare JSON response with error message
        $response = ['success' => false, 'message' => 'Error updating data: ' . $stmt->error];
    }

    // Close statement
    $stmt->close();

    // Output response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
}

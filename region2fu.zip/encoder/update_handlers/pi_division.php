<?php
include '../../src/connection.php';
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["case_id"])) {
    // Initialize response array
    $response = array();

    // Extract the parameters from GET
    $case_id = $_GET["case_id"];
    $case_number = $_GET["case_number"];
    $case_count = $_GET["case_count"];
    $exam_count = $_GET["exam_count"];
    $date_received = $_GET["date_received"];
    $date_completed = $_GET["date_completed"];
    $evidence_submitted = $_GET["evidence_submitted"];
    $requesting_party = $_GET["requesting_party"];
    $delivered_by = $_GET["delivered_by"];
    $victim = $_GET["victim"];
    $suspect = $_GET["suspect"];
    $examiner = $_GET["examiner"];
    $tdpo = $_GET["tdpo"];
    $nature_of_case = $_GET["nature_of_case"];
    $remarks = $_GET["remarks"];
    $exam_type = $_GET["exam_type"];

    // Update the data in the database
    $sql = "UPDATE pi SET
            case_number = '$case_number',
            case_count = '$case_count',
            exam_count = '$exam_count',
            date_received = '$date_received',
            date_completed = '$date_completed',
            evidence_submitted = '$evidence_submitted',
            requesting_party = '$requesting_party',
            delivered_by = '$delivered_by',
            victim = '$victim',
            suspect = '$suspect',
            examiner = '$examiner',
            tdpo = '$tdpo',
            nature_of_case = '$nature_of_case',
            remarks = '$remarks',
            exam_type = '$exam_type'
            WHERE id = '$case_id'";

    if (mysqli_query($conn, $sql)) {
        // Record updated successfully
        $response['success'] = true;
        $response['message'] = 'Record updated successfully';
    } else {
        // Error updating record
        $response['success'] = false;
        $response['message'] = 'Error updating record: ' . mysqli_error($conn);
    }

    // Convert response array to JSON and echo it
    echo json_encode($response);
}


?>
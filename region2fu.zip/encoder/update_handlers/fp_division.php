<?php
// Include your database connection file
include '../../src/connection.php';

// Check if the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Retrieve and sanitize form data (if needed)
    $case_id = $_GET["case_id"];
    $case_number = $_GET["case_number"];
    $cases_received = $_GET["cases_received"];
    $examinations = $_GET["examinations"];
    $date_received = $_GET["date_received"];
    $date_completed = $_GET["date_completed"];
    $evidence_submitted = $_GET["evidence_submitted"];
    $requesting_party = $_GET["requesting_party"];
    $delivered_by = $_GET["delivered_by"];
    $victims = $_GET["victims"];
    $suspects = $_GET["suspects"];
    $examiner = $_GET["examiner"];
    $occurrence_details = $_GET["occurrence_details"];
    $nature_of_case = $_GET["nature_of_case"];
    $type_of_examination = $_GET["type_of_examination"];
    $remarks = $_GET["remarks"];

    // Prepare SQL statement with placeholders
    $sql = "UPDATE fp SET 
            case_number = ?, 
            cases_received = ?, 
            examinations = ?, 
            date_received = ?, 
            date_completed = ?, 
            evidence_submitted = ?, 
            requesting_party = ?, 
            delivered_by = ?, 
            victims = ?, 
            suspects = ?, 
            examiner = ?, 
            occurrence_details = ?, 
            nature_of_case = ?, 
            type_of_examination = ?, 
            remarks = ? 
            WHERE id = ?";

    // Prepare the statement
    $stmt = mysqli_prepare($conn, $sql);

    // Bind parameters
    mysqli_stmt_bind_param(
        $stmt,
        "sssssssssssssssi",
        $case_number,
        $cases_received,
        $examinations,
        $date_received,
        $date_completed,
        $evidence_submitted,
        $requesting_party,
        $delivered_by,
        $victims,
        $suspects,
        $examiner,
        $occurrence_details,
        $nature_of_case,
        $type_of_examination,
        $remarks,
        $case_id
    );

    // Execute the statement
    if (mysqli_stmt_execute($stmt)) {
        // Data updated successfully
        $response = array("success" => true, "message" => "Data updated successfully.");
    } else {
        // Error updating record
        $response = array("success" => false, "message" => "Error updating record: " . mysqli_stmt_error($stmt));
    }

    // Close the statement
    mysqli_stmt_close($stmt);

    // Close the database connection
    mysqli_close($conn);

    // Set headers to return JSON content type
    header('Content-Type: application/json');

    // Output the JSON response
    echo json_encode($response);
}

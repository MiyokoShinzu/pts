<?php
include '../../src/connection.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Get the case_id from the query parameters
    $case_id = $_GET['case_id'];

    // Retrieve data from GET request
    $case_number = $_GET['case_number'];
    $examinations = $_GET['examinations'];
    $date_received = $_GET['date_received'];
    $date_completed = $_GET['date_completed'];
    $submission_date = $_GET['submission_date'];
    $meth = $_GET['meth'];
    $meth_specimen = $_GET['meth_specimen'];
    $mj = $_GET['mj'];
    $mj_specimen = $_GET['mj_specimen'];
    $other = $_GET['other'];
    $other_specimen = $_GET['other_specimen'];
    $other_weight = $_GET['other_weight'];
    $paraphernalia = $_GET['paraphernalia'];
    $requesting_party = $_GET['requesting_party'];
    $delivered_by = $_GET['delivered_by'];
    $suspects = $_GET['suspects'];
    $examiner = $_GET['examiner'];
    $date_to_custodian = $_GET['date_to_custodian'];
    $custodian_name = $_GET['custodian_name'];
    $receiving_pnco = $_GET['receiving_pnco'];
    $operation_type = $_GET['operation_type'];
    $investigator = $_GET['investigator'];
    $remarks = $_GET['remarks'];
    $result = $_GET['result'];
    $court_branch = $_GET['court_branch'];

    // Prepare SQL update query
    $sql = "UPDATE chemistry_two SET 
        case_number = ?, 
        examinations = ?, 
        date_received = ?, 
        date_completed = ?, 
        submission_date = ?, 
        meth = ?, 
        meth_specimen = ?, 
        mj = ?, 
        mj_specimen = ?, 
        other = ?, 
        other_specimen = ?, 
        other_weight = ?, 
        paraphernalia = ?, 
        requesting_party = ?, 
        delivered_by = ?, 
        suspects = ?, 
        examiner = ?, 
        date_to_custodian = ?, 
        custodian_name = ?, 
        receiving_pnco = ?, 
        operation_type = ?, 
        investigator = ?, 
        remarks = ?, 
        result = ?, 
        court_branch = ?
        WHERE id = ?";

    // Prepare statement
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bind_param(
        "ssssssssssssssssssssssssss",
        $case_number,
        $examinations,
        $date_received,
        $date_completed,
        $submission_date,
        $meth,
        $meth_specimen,
        $mj,
        $mj_specimen,
        $other,
        $other_specimen,
        $other_weight,
        $paraphernalia,
        $requesting_party,
        $delivered_by,
        $suspects,
        $examiner,
        $date_to_custodian,
        $custodian_name,
        $receiving_pnco,
        $operation_type,
        $investigator,
        $remarks,
        $result,
        $court_branch,
        $case_id
    );

    // Execute query and respond with JSON
    if ($stmt->execute()) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "error" => $conn->error]);
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}

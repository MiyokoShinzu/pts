<?php
// Include your database connection file
include '../../src/connection.php';

// Check if the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Retrieve all GET parameters
    $case_number = $_GET["case_number"];
    $nature_of_case = $_GET["nature_of_case"];
    $exam_type = $_GET["exam_type_input2"]; // Assuming exam_type_input is a comma-separated string
    $soco_classification = $_GET["soco_classification"];
    $victims = $_GET["victims"];
    $suspects = $_GET["suspects"];
    $occurrence_info = $_GET["occurrence_info"];
    $investigator = $_GET["investigator"];
    $ioc_contact = $_GET["ioc_contact"];
    $soco_leader = $_GET["soco_leader"];
    
    $duty_receiving_pnco = $_GET["duty_receiving_pnco"];
    $caller_name = $_GET["caller_name"];
    $call_datetime = $_GET["call_datetime"];
    $requesting_party = $_GET["requesting_party"];
    $remarks = $_GET["remarks"];
    
   

    // Case ID to be updated
    $case_id = $_GET["case_id"];

    // Prepare SQL statement for update
    $sql = "UPDATE soco 
            SET 
                case_number = ?, 
                nature_of_case = ?, 
                exam_type = ?, 
                soco_classification = ?, 
                victims = ?, 
                suspects = ?, 
                occurrence_info = ?, 
                investigator = ?, 
                ioc_contact = ?, 
                soco_leader = ?, 
               
                duty_receiving_pnco = ?, 
                caller_name = ?, 
                call_datetime = ?, 
                requesting_party = ?, 
                remarks = ?
               
                
            WHERE 
                id = ?";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sssssssssssssssi",
        $case_number,
        $nature_of_case,
        $exam_type,
        $soco_classification,
        $victims,
        $suspects,
        $occurrence_info,
        $investigator,
        $ioc_contact,
        $soco_leader,
       
        $duty_receiving_pnco,
        $caller_name,
        $call_datetime,
        $requesting_party,
        $remarks,
      
       
        $case_id
    );

    // Execute the statement
    if ($stmt->execute()) {
        // If update is successful, prepare success response
        $response = ['success' => true, 'message' => 'Record updated successfully.'];
    } else {
        // If there's an error, prepare error response
        $response = ['success' => false, 'message' => 'Error updating record: ' . $stmt->error];
    }

    // Close statement
    $stmt->close();

    // Output response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

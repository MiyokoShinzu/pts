<?php
// Include your database connection file
include '../../src/connection.php';

// Check if the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Retrieve all GET parameters
    $case_number = $_GET['case_number'];
    $type_of_examination = $_GET['type_of_examination'];
    $no_of_examination = $_GET['no_of_examination'];
    $datetime_received = $_GET['datetime_received'];
    $datetime_completed = $_GET['datetime_completed'];
    $evidence = $_GET['evidence'];
    $suspect = $_GET['suspect'];
    $victim = $_GET['victim'];
    $subject = $_GET['subject'];
    $requesting_party = $_GET['requesting_party'];
    $delivered_by = $_GET['delivered_by'];
    $tdpo_no = $_GET['tdpo_no'];
    $examiner = $_GET['examiner'];
    $nature_of_case = $_GET['nature_of_case'];
    $duty_receiving_officer = $_GET['duty_receiving_officer'];
    $casts_taken_by = $_GET['casts_taken_by'];
    $witnessed_by = $_GET['witnessed_by'];
    $result_of_examination = $_GET['result_of_examination'];
    $remarks = $_GET['remarks'];
    $case_id = $_GET['case_id']; // Assuming case_id is passed in the GET request

    // Prepare SQL statement for update
    $sql = "UPDATE chemistry_one 
            SET 
                case_number = ?, 
                type_of_examination = ?, 
                no_of_examination = ?, 
                datetime_received = ?, 
                datetime_completed = ?, 
                evidence = ?, 
                suspect = ?, 
                victim = ?, 
                subject = ?, 
                requesting_party = ?, 
                delivered_by = ?, 
                tdpo_no = ?, 
                examiner = ?, 
                nature_of_case = ?, 
                duty_receiving_officer = ?, 
                casts_taken_by = ?, 
                witnessed_by = ?, 
                result_of_examination = ?, 
                remarks = ?
            WHERE 
                id = ?";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sssssssssssssssssssi",
        $case_number,
        $type_of_examination,
        $no_of_examination,
        $datetime_received,
        $datetime_completed,
        $evidence,
        $suspect,
        $victim,
        $subject,
        $requesting_party,
        $delivered_by,
        $tdpo_no,
        $examiner,
        $nature_of_case,
        $duty_receiving_officer,
        $casts_taken_by,
        $witnessed_by,
        $result_of_examination,
        $remarks,
        $case_id
    );

    // Execute the statement
    if ($stmt->execute()) {
        // If update is successful, prepare JSON response
        $response = [
            'success' => true,
            'message' => 'Record updated successfully.'
        ];
    } else {
        // If there's an error, prepare JSON response
        $response = [
            'success' => false,
            'message' => 'Error updating record: ' . $stmt->error
        ];
    }

    // Close statement
    $stmt->close();

    // Output JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
}

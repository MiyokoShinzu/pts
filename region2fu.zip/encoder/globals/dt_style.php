<style>
    .dropdown {
        position: relative;
        display: inline-block;
        z-index: 100;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        left: 100%;
        background-color: #fff;
        border: 1px solid var(--bs-info);
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
        padding: 12px 16px;
        z-index: 100;
    }
    .dropdown-content::before{
        content: "";
        position: absolute;
        top: 40%;
        z-index: -10;
        left: -5%;
        transform: translate(-50%, -50%);
        height: 15px;
        width: 15px;
        background: var(--bs-info);
        transform: rotate(45deg);
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

    .dropdown-item:hover {
        color: var(--bs-info);
    }
</style>
<style>
    .dt-search {
        display: flex;
        align-items: center;
        justify-content: flex-end;

    }

    div.dt-container .dt-search input {

        outline: none;

    }

    div.dt-container .dt-search input:focus {

        border: 1px solid var(--bs-info);
    }

    div.dtsb-searchBuilder button.dtsb-button {
        background: cadetblue;
        color: #fff;
    }

    div.dtsb-searchBuilder div.dtsb-group div.dtsb-logicContainer button.dtsb-logic {
        color: #000;
    }

    div.dt-length {
        display: flex;
        align-items: center;
        justify-content: flex-end;
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control::before,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control::before {
        margin-right: .5em;
        display: inline-block;
        box-sizing: border-box;
        content: "~";
        border-top: 0px solid transparent;
        border-left: 0px solid rgba(0, 0, 0, 0.5);
        border-bottom: 0px solid transparent;
        border-right: 0px solid transparent;
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr.dtr-expanded>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr.dtr-expanded>th.dtr-control:before {
        border-top: 0px solid rgba(0, 0, 0, 0.5);
        border-left: 5px solid transparent;
        border-bottom: 0px solid transparent;
        border-right: 5px solid transparent;
    }

    td {
        font-size: 12px;
        /* font-style: italic; */
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
        background-color: var(--bs-info);
        border: .15em solid #fff;
        border-radius: 1em;
        box-shadow: 0 0 .2em #444;
        box-sizing: content-box;
        color: #fff;
        content: "~";
        display: block;
        font-family: Courier New, Courier, monospace;
        height: 1em;
        left: 5px;
        line-height: 1em;
        margin-top: -9px;
        position: absolute;
        text-align: center;
        text-indent: 0 !important;
        top: 50%;
        width: 1em;
    }
</style>
<script>
    $('div.dtsb-searchBuilder div.dtsb-titleRow').text("Advance Search")
    $('.add_case').css({
        "background": "#3b7ddd",
        "color": "white",

    })
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var natureOfCaseSelect = document.getElementById('nature_of_case');
        var otherNatureCaseInput = document.getElementById('other_nature_case_input');
        var otherNatureCaseInputField = document.getElementById('other_nature_case');

        natureOfCaseSelect.addEventListener('change', function() {
            var selectedOption = natureOfCaseSelect.value;

            if (selectedOption === 'Others') {
                otherNatureCaseInputField.style.display = 'block';
                natureOfCaseSelect.setAttribute('name', 'dissolve');
                otherNatureCaseInput.setAttribute('name', 'nature_of_case');
                console.log(natureOfCaseSelect.name)
                console.log(otherNatureCaseInput.name)

            } else {
                otherNatureCaseInputField.style.display = 'none';
                otherNatureCaseInput.setAttribute('name', 'dissolve');
                natureOfCaseSelect.setAttribute('name', 'nature_of_case');
                console.log(natureOfCaseSelect.name)
                console.log(otherNatureCaseInput.name)

            }

        });

    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var natureOfCaseSelect = document.querySelector('#edit_form #nature_of_case');
        var otherNatureCaseInput = document.querySelector('#edit_form #other_nature_case_input');
        var otherNatureCaseInputField = document.querySelector('#edit_form #other_nature_case');

        natureOfCaseSelect.addEventListener('change', function() {
            var selectedOption = natureOfCaseSelect.value;

            if (selectedOption === 'Others') {
                otherNatureCaseInputField.style.display = 'block';
                natureOfCaseSelect.setAttribute('name', 'dissolve');
                otherNatureCaseInput.setAttribute('name', 'nature_of_case');
                console.log(natureOfCaseSelect.name)
                console.log(otherNatureCaseInput.name)

            } else {
                otherNatureCaseInputField.style.display = 'none';
                otherNatureCaseInput.setAttribute('name', 'dissolve');
                natureOfCaseSelect.setAttribute('name', 'nature_of_case');
                console.log(natureOfCaseSelect.name)
                console.log(otherNatureCaseInput.name)

            }

        });

    });
</script>
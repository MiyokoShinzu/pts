<?php
echo '<td class="">'
    . '<div class="dropdown d-flex align-items-center justify-content-center">
         <button class="btn btn-info text-white" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             <i class="align-self-center " data-feather="file-text"></i>
             Manage
         </button>
         <div class="dropdown-content" class="border shadow border-dark border-2" aria-labelledby="dropdownMenuButton">
             <h5 class="dropdown-item border p-2" id="edit_case" data-bs-toggle="modal" data-bs-target="#edit_case_modal" data-case_id="' . $row['id'] . '">Edit Case</h5>
             <h5 class="dropdown-item border p-2" data-bs-toggle="modal" data-bs-target="#files_modal" data-case_id="' . $row['id'] . '" id="view_files_btn">View Files</h5>
         </div>
     </div>
     ' .
    '</td>';

?>
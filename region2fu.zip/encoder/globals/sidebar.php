<?php $email = $_SESSION['email'];
$unit = $_SESSION['unit'];
$username = $_SESSION['username'];

?>
<nav id="sidebar" class="sidebar js-sidebar">
    <div class="sidebar-content js-simplebar">
        <a class="sidebar-brand text-center" href="index.php">
            <span class="align-middle">Encoder</span>
            <br>
            <span class="text-sm"><?php

                                    echo $unit;
                                    ?></span>
            
            <span class="text-sm"><?php

                                    echo $email;
                                    ?></span>
                                    <hr>
        </a>

        <ul class="sidebar-nav">


            <li class="sidebar-item active">
                <a class="sidebar-link" href="index.php">
                    <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
                </a>
            </li>
            <li class="sidebar-item active">
                <a class="sidebar-link" href="logout.php">
                    <i class="align-middle" data-feather="log-out"></i> <span class="align-middle">Logout</span>
                </a>
            </li>

            <li class="sidebar-header">
                Sections
            </li>

            <li class="sidebar-item">
                <a class="sidebar-link" href="qd_division.php">
                    <i class="align-middle" data-feather="link"></i> <span class="align-middle">Question Document</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="soco_division.php">
                    <i class="align-middle" data-feather="link"></i> <span class="align-middle">SOCO</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="polygraph_division.php">
                    <i class="align-middle" data-feather="link"></i> <span class="align-middle">Polygraph</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="chemistry_division.php">
                    <i class="align-middle" data-feather="link"></i> <span class="align-middle">Chemistry</span>
                </a>
                <a class="sidebar-link" href="chemistry_drug_division.php">
                    <i class="align-middle" data-feather="git-commit"></i> <span class="align-middle">Drug (Chemistry)</span>
                </a>
                <a class="sidebar-link" href="chemistry_drug_test_division.php">
                    <i class="align-middle" data-feather="git-commit"></i> <span class="align-middle">Drug Test (Chemistry)</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="dna_division.php">
                    <i class="align-middle" data-feather="link"></i> <span class="align-middle">DNA</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="fingerprint_division.php">
                    <i class="align-middle" data-feather="link"></i> <span class="align-middle">Fingerprint</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="fi_division.php">
                    <i class="align-middle" data-feather="link"></i> <span class="align-middle">Firearms Identitifcation</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="fp_division.php">
                    <i class="align-middle" data-feather="link"></i> <span class="align-middle">Forensic Photography</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="ml_division.php">
                    <i class="align-middle" data-feather="link"></i> <span class="align-middle">Medico Legal</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="pi_division.php">
                    <i class="align-middle" data-feather="link"></i> <span class="align-middle">Physical Identification</span>
                </a>
            </li>


        </ul>


    </div>
</nav>
<nav class="navbar navbar-expand navbar-light navbar-bg border border w-100 mx-auto">
    <a class="sidebar-toggle js-sidebar-toggle">
        <i class="hamburger align-self-center"></i>
    </a>
    <div class="container h-100 d-flex align-items-center justify-content-center flex-column">

        
    </div>

</nav>

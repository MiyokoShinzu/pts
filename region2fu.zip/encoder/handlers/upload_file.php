<?php
session_start();
include '../../src/connection.php';



$unit = $_SESSION['unit'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $case_id = $_POST['case_id'];
    $division = $_POST['division'];
    $upload_dir = 'uploads/';
    $file_path = '';
    $upload_success = false;

    if (isset($_FILES['file']) && $_FILES['file']['error'] == UPLOAD_ERR_OK) {
        $file_name = basename($_FILES['file']['name']);

        // Append timestamp to the file name
        $timestamp = time(); // Current Unix timestamp
        $file_name_with_timestamp = $timestamp . '_' . $file_name;

        $target_file = $upload_dir . $file_name_with_timestamp;

        if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {
            $file_path = $target_file;
            $upload_success = true;
        }
    }

    if ($upload_success) {
        $sql = "INSERT INTO files (url, case_id, unit, division) VALUES ('$file_path', '$case_id', '$unit', '$division')";
        $result = $conn->query($sql);
        if ($result) {
            echo json_encode(['success' => '1']);
        } else {
            echo json_encode(['success' => '0', 'error' => 'Database insert failed']);
        }
    } else {
        echo json_encode(['success' => '0', 'error' => 'File upload failed']);
    }
}

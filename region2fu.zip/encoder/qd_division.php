<?php
include "../src/connection.php";
include "globals/head.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $case_number = $_POST['case_number'];
    $case_count = $_POST['case_count'];
    $exam_count = $_POST['exam_count'];
    $exam_type = $_POST['exam_type'];
    $datetime_received = $_POST['datetime_received'];
    $datetime_completed = $_POST['datetime_completed'];
    $requesting_party = $_POST['requesting_party'];
    $delivered_by = $_POST['delivered_by'];
    $victim = $_POST['victim'];
    $suspect = $_POST['suspect'];
    $examiner = $_POST['examiner'];
    $tdpo = $_POST['tdpo'];
    $case_nature = $_POST['nature_of_case'];
    $remarks = $_POST['remarks'];
    $status = "Pending";
    $unit = $_SESSION['unit'];
    $sql = "INSERT INTO qd (case_number, case_count, exam_count, exam_type, datetime_received, datetime_completed, requesting_party, delivered_by, victim, suspect, examiner, tdpo, case_nature, remarks, status, unit) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssssssssss", $case_number, $case_count, $exam_count, $exam_type, $datetime_received, $datetime_completed, $requesting_party, $delivered_by, $victim, $suspect, $examiner, $tdpo, $case_nature, $remarks, $status, $unit);

    if ($stmt->execute()) {
        echo "Data inserted into the database successfully.";
        header("Location: qd_division.php");
        exit();
    } else {
        echo "Error inserting data into the database: " . $stmt->error;
    }
    $stmt->close();
}
?>



<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>

        <main class="content bg-light">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Question Document Division</h1>

                <div class="row">





                    <div class="mb-3 col-lg-12 mx-auto bg-white border">

                        <div class="table-responsive p-3">
                            <table class="table w-100 table-bordered p-2 bg-white mx-auto" id="qd_table">
                                <thead class="border border-primary bg-info">
                                    <tr>
                                        <th class="text-center text-white">Actions</th>
                                        <th class="text-center text-white">Status</th>
                                        <th class="text-center text-white">Case Number</th>
                                        <th class="text-center text-white">No. of Cases Received</th>
                                        <th class="text-center text-white">No. of Examination</th>
                                        <th class="text-center text-white">Type of Examination</th>
                                        <th class="text-center text-white">Time and Date Received</th>
                                        <th class="text-center text-white">Time and Date Completed</th>
                                        <th class="text-center text-white">Requesting Party</th>
                                        <th class="text-center text-white">Delivered by</th>
                                        <th class="text-center text-white">Victim/s</th>
                                        <th class="text-center text-white">Suspect/s</th>
                                        <th class="text-center text-white">Examiner</th>
                                        <th class="text-center text-white">TDPO</th>
                                        <th class="text-center text-white">Nature of Case</th>
                                        <th class="text-center text-white">Remarks</th>

                                    </tr>

                                </thead>

                                <tbody>
                                    <?php

                                    $sql = "SELECT * FROM qd where unit = '$unit'";
                                    $result = mysqli_query($conn, $sql);

                                    while ($row = $result->fetch_assoc()) {
                                        echo '<tr>';
                                        include 'globals/action_buttons.php';
                                        if ($row["status"] == "Pending") {
                                            $el = "<span class='badge bg-warning  text-center text-white'>" . $row["status"] . "</span>";
                                        } else if ($row["status"] == "Reviewed") {
                                            $el = "<span class='badge bg-info  text-center text-white'>" . $row["status"] . "</span>";
                                        } else if ($row["status"] == "With Revisions") {
                                            $el = "<span class='badge bg-danger  text-center text-white'>" . $row["status"] . "</span>";
                                        } else if ($row["status"] == "Approved") {
                                            $el = "<span class='badge bg-success  text-center text-white'>" . $row["status"] . "</span>";
                                        } else {
                                            $el = "<span class='badge bg-secondary  text-center text-white'>" . "N/A" . "</span>";
                                        }
                                        echo "<td class='text-center'>" . $el . "</td>";
                                        echo '<td>' . $row["case_number"] . '</td>';
                                        echo '<td>' . $row["case_count"] . '</td>';
                                        echo '<td>' . $row["exam_count"] . '</td>';
                                        echo '<td>' . $row["exam_type"] . '</td>';
                                        echo '<td>' . $row["datetime_received"] . '</td>';
                                        echo '<td>' . $row["datetime_completed"] . '</td>';
                                        echo '<td>' . $row["requesting_party"] . '</td>';
                                        echo '<td>' . $row["delivered_by"] . '</td>';
                                        echo '<td>' . $row["victim"] . '</td>';
                                        echo '<td>' . $row["suspect"] . '</td>';
                                        echo '<td>' . $row["examiner"] . '</td>';
                                        echo '<td>' . $row["tdpo"] . '</td>';
                                        echo '<td>' . $row["case_nature"] . '</td>';
                                        echo '<td>' . $row["remarks"] . '</td>';
                                        echo '</tr>';
                                    }


                                    ?>
                                </tbody>

                            </table>
                        </div>
                    </div>

                </div>
            </div>



            <div class="modal fade" tabindex="-1" aria-hidden="true" style="display: none;" id="add_case_qd">
                <div class="modal-dialog modal-xl" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-info">
                            <h2 class="text-white">Question Document</h2>
                        </div>
                        <div class="modal-body">
                            <form method="post">
                                <div class="row">
                                    <hr>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-floating ">
                                            <input type="text" class="form-control" name="case_number" placeholder="">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Case Number</label>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">No. of Specimen</label>
                                            <input type="number" min="0" max="1000" class="form-control" name="case_count">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">No. of Examination</label>
                                            <input type="number" min="0" max="1000" class="form-control" name="exam_count">
                                        </div>
                                    </div>

                                    <hr class="text-center">

                                    <div class="mb-3 col-md-4">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Type of Examination</label>
                                            <input type="text" class="form-control" name="exam_type">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Time and Date Received</label>
                                            <input type="datetime-local" class="form-control" name="datetime_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Time and Date Completed</label>
                                            <input type="datetime-local" class="form-control" name="datetime_completed">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Requesting Party</label>
                                            <input type="text" class="form-control" name="requesting_party">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Delivered by (station)</label>
                                            <input type="text" class="form-control" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Victim/s</label>
                                            <input type="text" class="form-control" name="victim">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Suspect/s</label>
                                            <input type="text" class="form-control" name="suspect">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">EXAMINER</label>
                                            <input type="text" class="form-control" name="examiner">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">TDPO</label>
                                            <input type="text" class="form-control" name="tdpo">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group  bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" required name="nature_of_case" class="form-select">
                                                <option value="Signature Identification">Signature Identification</option>
                                                <option value="Handwriting Identification">Handwriting Identification</option>
                                                <option value="Alteration">Alteration</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="dissolve" placeholder="Enter other nature of case">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Remarks</label>
                                            <select name="remarks" class="form-control">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                        </div>
                        <div class="modal-footer text-end">
                            <button type="button" class="btn btn-sm btn-danger" data-bs-dismiss="modal">Close</button>
                            <button class="btn btn-info " id="submit_btn" type="submit" value="submit">Submit</button>
                        </div>
                        </form>

                    </div>
                </div>
            </div>

            <?php
            $div = "Question Document";
            include "globals/file_modal.php";
            ?>



            <div class="modal fade" tabindex="-1" aria-hidden="true" style="display: none;" id="edit_case_modal">
                <div class="modal-dialog modal-xl" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-info">
                            <h2 class="text-white">Question Document</h2>
                        </div>
                        <div class="modal-body">
                            <form method="post" id="edit_form">
                                <div class="row">
                                    <hr>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Case Number</label>
                                            <input type="text" class="form-control" name="case_number" placeholder="QD-001-24">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">No. of Examination</label>
                                            <input type="number" min="0" max="1000" class="form-control" name="exam_count">
                                        </div>
                                    </div>

                                    <hr class="text-center">

                                    <div class="mb-3 col-md-4">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Type of Examination</label>
                                            <input type="text" class="form-control" name="exam_type">
                                        </div>
                                    </div>
                                    <div class="mb-3 c
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">No. of Specimen</label>
                                            <input type="number" min="0" max="1000" class="form-control" name="case_count">
                                        </div>
                                    </div>ol-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Time and Date Received</label>
                                            <input type="datetime-local" class="form-control" name="datetime_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Time and Date Completed</label>
                                            <input type="datetime-local" class="form-control" name="datetime_completed">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Requesting Party</label>
                                            <input type="text" class="form-control" name="requesting_party">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Delivered by (station)</label>
                                            <input type="text" class="form-control" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Victim/s</label>
                                            <input type="text" class="form-control" name="victim">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Suspect/s</label>
                                            <input type="text" class="form-control" name="suspect">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">EXAMINER</label>
                                            <input type="text" class="form-control" name="examiner">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">TDPO</label>
                                            <input type="text" class="form-control" name="tdpo">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group  bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" required name="nature_of_case" class="form-select">
                                                <option value="Signature Identification">Signature Identification</option>
                                                <option value="Handwriting Identification">Handwriting Identification</option>
                                                <option value="Alteration">Alteration</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="dissolve" placeholder="Enter other nature of case">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group ">
                                            <label for="" style="font-weight: bolder" class="mb-1 strong">Remarks</label>
                                            <select name="remarks" class="form-control">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                        </div>
                        <div class="modal-footer text-end">
                            <button type="button" class="btn  btn-danger" data-bs-dismiss="modal">Close</button>
                            <button class="btn btn-info " id="update_btn" type="submit">Submit</button>
                        </div>
                        </form>

                    </div>
                </div>
            </div>

        </main>


    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.2/umd/popper.min.js" integrity="sha512-2rNj2KJ+D8s1ceNasTIex6z4HWyOnEYLVC3FigGOmyQCZc2eBXKgOxQmo3oKLHyfcj53uz4QMsRCWNbLd32Q1g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#qd_table').DataTable({
 dom: 'fQrBtip',
                    responsive: true,
                    buttons: [
                         {
                text: 'Add Case', // Button text
                className: 'add_case', // Optional: Custom class for styling
                attr: {
                    'data-bs-toggle': 'modal', // Custom attribute and its value
                    'data-bs-target': '#add_case_qd', // Another example of a custom attribute
                    'title': 'Click to add case' // Tooltip title
                },

            },

                        {
                            extend: 'excel',
                            text: 'Excel',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'pdf',
                            text: 'PDF',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'print',
                            text: 'Print',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'colvis',
                            text: 'Show/Hide Columns',
                        }
                    ],
                    fixedHeader: true,
                    paging: true,
                    searching: true,
                    ordering: true,
                    scrollY: '300px',
                    colReorder: true,
                    scrollCollapse: true,
                    language: {
                        search: "Search:"

                    },
                });
</script>
<?php include "globals/dt_style.php"; ?>
<script>
    $(document).on("input", "#other_drug", function() {
        $("#other_input").removeClass('d-none');
        var drug_name = $("#other_drug").val()
        if (drug_name == "") {
            $("#other_input").addClass('d-none')
        } else {
            $('#other_input #text_label').text(`Weight in grams of ${drug_name}`)
        }
    })
</script>

<?php
include "globals/modal_scripts.php";
?>



<script>
    $(document).on('click', '#edit_case', function() {
        var case_id = $(this).attr('data-case_id');
        $('#update_btn').attr('data-case_id', case_id)

        // Fetch the data from the server
        fetch(`./edit_handlers/qd_division.php?case_id=${case_id}`)
            .then(response => response.json()) // Parse the JSON response
            .then(data => {
                console.log(data);

                // Assign values to each input field
                $("#edit_form input[name='case_number']").val(data[0].case_number);
                $("#edit_form input[name='case_count']").val(data[0].case_count);
                $("#edit_form input[name='exam_count']").val(data[0].exam_count);
                $("#edit_form input[name='exam_type']").val(data[0].exam_type);
                $("#edit_form input[name='datetime_received']").val(data[0].datetime_received);
                $("#edit_form input[name='datetime_completed']").val(data[0].datetime_completed);
                $("#edit_form input[name='requesting_party']").val(data[0].requesting_party);
                $("#edit_form input[name='delivered_by']").val(data[0].delivered_by);
                $("#edit_form input[name='victim']").val(data[0].victim);
                $("#edit_form input[name='suspect']").val(data[0].suspect);
                $("#edit_form input[name='examiner']").val(data[0].examiner);
                $("#edit_form input[name='tdpo']").val(data[0].tdpo);
                $("#edit_form select[name='nature_of_case']").append(`<option value='${data[0].case_nature}'>${data[0].case_nature}</option>`);
                $("#edit_form select[name='nature_of_case']").val(`${data[0].case_nature}`);







                // Set remarks select value
                $("#edit_form select[name='remarks']").val(data[0].remarks);

                // Handle remarks select field
                $("select[name='remarks']").val(data[0].remarks);

            })
            .catch(err => {
                console.error(err);
            });
    });
</script>
<script>
    $(document).on('click', '#update_btn', function(e) {
        e.preventDefault();
        
        var case_id = $(this).attr('data-case_id'); // Assuming you get the case_id from somewhere
        var formData = $("#edit_form").serialize();

        // Append case_id to formData
        formData += '&case_id=' + encodeURIComponent(case_id);

        fetch(`./update_handlers/qd_division.php?${formData}`)
            .then(response => response.json())
            .then(data => {
                if(data.success == true){
                    alert("Updated successfully");
                    window.location.reload()
                }
                // Handle success: maybe redirect or update UI
            })
            .catch((error) => {
                console.error('Error:', error);
            });


    })
</script>
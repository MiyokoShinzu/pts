<?php
include "../src/connection.php";
include "globals/head.php";
?>



<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include your database connection file


    // Retrieve form data
    $case_number = $_POST['case_number'];
    $examinations = $_POST['examinations'];
    $date_received = $_POST['date_received'];
    $date_completed = $_POST['date_completed'];
    $evidence_submitted = $_POST['evidence_submitted'];; // Combine checkbox values into a comma-separated string
    $requesting_party = $_POST['requesting_party'];
    $delivered_by = $_POST['delivered_by'];
    $subject = $_POST['suspects']; // Assuming this corresponds to the subject in your database
    $examiner = $_POST['examiner'];
    $occurrence_datetime = $_POST['occurrence_datetime']; // Assuming this corresponds to the occurrence_datetime in your database
    $nature_of_case = $_POST['nature_of_case'];
    $remarks = $_POST['remarks'];
    $victims = $_POST['victims'];
    $status = "Pending";
    $unit = $_SESSION['unit'];

    // Construct SQL INSERT statement
    $sql = "INSERT INTO fingerprint (case_number, examinations, date_received, date_completed, evidence_submitted, requesting_party, delivered_by, subject, examiner, occurrence_datetime, nature_of_case, remarks, status, unit, victims) 
            VALUES ('$case_number', '$examinations', '$date_received', '$date_completed', '$evidence_submitted', '$requesting_party', '$delivered_by', '$subject', '$examiner', '$occurrence_datetime', '$nature_of_case', '$remarks', '$status', '$unit', '$victims')";

    // Execute the INSERT statement
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
        header("Location: fingerprint_division.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>
        <?php
        $sql = "SELECT * FROM fingerprint where unit = '$unit'";
        $result = $conn->query($sql);
        ?>
        <main class="content bg-white">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Fingerprint Division</h1>

                <div class="row bg-white p-2 border">

                    <div class="mb-3 col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">

                            <div class="table-responsive p-3">
                                <table id="fingerprint_table" class="table w-100 table-bordered p-2 bg-white mx-auto">
                                    <thead class="border border-primary bg-info">
                                        <tr>

                                            <th class="text-center text-white">Actions</th>
                                            <th class="text-center text-white">Status </th>
                                            <th class="text-center text-white">Case Number</th>
                                            <th class="text-center text-white">Examinations</th>
                                            <th class="text-center text-white">Date Received</th>
                                            <th class="text-center text-white">Date Completed</th>
                                            <th class="text-center text-white">Evidence Submitted</th>
                                            <th class="text-center text-white">Requesting Party</th>
                                            <th class="text-center text-white">Delivered By</th>
                                            <th class="text-center text-white">Subject</th>
                                            <th class="text-center text-white">Examiner</th>
                                            <th class="text-center text-white">Occurrence DateTime</th>
                                            <th class="text-center text-white">Nature of Case</th>
                                            <th class="text-center text-white">Remarks</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        while ($row = $result->fetch_assoc()) {
                                            echo '<tr>';
                                            include 'globals/action_buttons.php';
                                            if ($row["status"] == "Pending") {
                                                $el = "<span class='badge bg-warning  text-center text-white'>" . $row["status"] . "</span>";
                                            } else if ($row["status"] == "Reviewed") {
                                                $el = "<span class='badge bg-info  text-center text-white'>" . $row["status"] . "</span>";
                                            } else if ($row["status"] == "With Revisions") {
                                                $el = "<span class='badge bg-danger  text-center text-white'>" . $row["status"] . "</span>";
                                            } else if ($row["status"] == "Approved") {
                                                $el = "<span class='badge bg-success  text-center text-white'>" . $row["status"] . "</span>";
                                            } else {
                                                $el = "<span class='badge bg-secondary  text-center text-white'>" . "N/A" . "</span>";
                                            }
                                            echo "<td class='text-center'>" . $el . "</td>";
                                            echo '<td>' . $row['case_number'] . '</td>';
                                            echo '<td>' . $row['examinations'] . '</td>';
                                            echo '<td>' . $row['date_received'] . '</td>';
                                            echo '<td>' . $row['date_completed'] . '</td>';
                                            echo '<td>' . $row['evidence_submitted'] . '</td>';
                                            echo '<td>' . $row['requesting_party'] . '</td>';
                                            echo '<td>' . $row['delivered_by'] . '</td>';
                                            echo '<td>' . $row['subject'] . '</td>';
                                            echo '<td>' . $row['examiner'] . '</td>';
                                            echo '<td>' . $row['occurrence_datetime'] . '</td>';
                                            echo '<td>' . $row['nature_of_case'] . '</td>';
                                            echo '<td>' . $row['remarks'] . '</td>';
                                            echo '</tr>';
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>





                </div>
            </div>




            <div class="modal" tabindex="-1" id="add_fingerprint_case" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-primary">
                            <h6 class="text-white">Fingerprint</h6>

                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <div class="row">
                                    <div class="mb-3 col-md-3">
                                        <div class="form-group">
                                            <label for="case_number" class="strong mb-1">Case Number</label>
                                            <input type="text" class="form-control" id="case_number" name="case_number">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-3">
                                        <div class="form-group">
                                            <label for="examinations" class="strong mb-1">No. of Examination</label>
                                            <input type="number" min="0" max="1000" class="form-control" id="examinations" name="examinations">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-3">
                                        <div class="form-group">
                                            <label for="date_received" class="strong mb-1">Time and Date Received</label>
                                            <input type="datetime-local" class="form-control" id="date_received" name="date_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-3">
                                        <div class="form-group">
                                            <label for="date_completed" class="strong mb-1">Time and Date Completed</label>
                                            <input type="datetime-local" class="form-control" id="date_completed" name="date_completed">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="evidence_submitted">Evidence Submitted</label><br>
                                            <input type="text" readonly class="form-control" id="evidence_submitted" name="evidence_submitted" placeholder="Check the values below to update data">
                                        </div>
                                    </div>
                                    <!-- Checkbox options for evidence submitted -->
                                    <div class="mb-3 col-3">
                                        <input type="checkbox" class="form-checkbox" id="chemistry" name="exam_type[]" value="Post Mortem" onchange="updateExamType()">
                                        <label class="strong mb-1" for="chemistry">Post Mortem</label><br>
                                    </div>
                                    <div class="mb-3 col-3">
                                        <input type="checkbox" class="form-checkbox" id="polygraph" name="exam_type[]" value="Latent Print" onchange="updateExamType()">
                                        <label class="strong mb-1" for="polygraph">Latent Print</label><br>
                                    </div>
                                    <div class="mb-3 col-6">
                                        <input type="checkbox" class="form-checkbox" id="dna_analysis" name="exam_type[]" value="Standard Fingerprint Chart" onchange="updateExamType()">
                                        <label class="strong mb-1" for="dna_analysis">Standard Fingerprint Chart</label><br>
                                    </div>
                                    <!-- End of Checkbox options -->

                                    <div class="mb-3 col-md-8">
                                        <div class="form-group">
                                            <label for="requesting_party" class="strong mb-1">Requesting Party</label>
                                            <input type="text" class="form-control" id="requesting_party" name="requesting_party">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="delivered_by" class="strong mb-1">Delivered by (station)</label>
                                            <input type="text" class="form-control" id="delivered_by" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="victims" class="strong mb-1">Victim/s</label>
                                            <input type="text" class="form-control" id="victims" name="victims">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="suspects" class="strong mb-1">Suspect/s</label>
                                            <input type="text" class="form-control" id="suspects" name="suspects">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="examiner" class="strong mb-1">Examiner</label>
                                            <input type="text" class="form-control" id="examiner" name="examiner" required>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="occurrence_details" class="strong mb-1">Time, Date & Place of Occurrence</label>
                                            <input type="text" class="form-control" id="occurrence_details" name="occurrence_datetime">
                                        </div>
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group  bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" required name="nature_of_case" class="form-select">
                                                <option value="Found Dead Body">Found Dead Body</option>
                                                <option value="Shooting Incident">Shooting Incident</option>
                                                <option value="Robbery">Robbery</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="dissolve" placeholder="Enter other nature of case">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="remarks" class="strong mb-1">Remarks (In Custody, Court, Requesting Party)</label>
                                            <select name="remarks" id="remarks" class="form-control">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                                <option value="Turned Over To Requesting Party">Turned over to Requesting Party</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-end">
                                        <button type="button" class="btn btn-sm btn-danger" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" value="submit" class="btn btn-sm btn-primary">Submit</button>
                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>




            <div class="modal" tabindex="-1" id="edit_case_modal" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-primary">
                            <h6 class="text-white">Fingerprint</h6>

                        </div>
                        <div class="modal-body">
                            <form action="" method="post" id="edit_form">
                                <div class="row">
                                    <div class="mb-3 col-md-3">
                                        <div class="form-group">
                                            <label for="case_number" class="strong mb-1">Case Number</label>
                                            <input type="text" class="form-control" id="case_number" name="case_number">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-3">
                                        <div class="form-group">
                                            <label for="examinations" class="strong mb-1">No. of Examination</label>
                                            <input type="number" min="0" max="1000" class="form-control" id="examinations" name="examinations">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-3">
                                        <div class="form-group">
                                            <label for="date_received" class="strong mb-1">Time and Date Received</label>
                                            <input type="datetime-local" class="form-control" id="date_received" name="date_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-3">
                                        <div class="form-group">
                                            <label for="date_completed" class="strong mb-1">Time and Date Completed</label>
                                            <input type="datetime-local" class="form-control" id="date_completed" name="date_completed">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label class="strong mb-1" for="evidence_submitted">Evidence Submitted</label><br>
                                            <input type="text" readonly class="form-control" id="evidence_submitted2" name="evidence_submitted" placeholder="Check the values below to update data">
                                        </div>
                                    </div>
                                    <!-- Checkbox options for evidence submitted -->
                                    <div class="mb-3 col-3">
                                        <input type="checkbox" class="form-checkbox" id="chemistry" name="exam_type[]" value="Post Mortem" onchange="updateExamType2()">
                                        <label class="strong mb-1" for="chemistry">Post Mortem</label><br>
                                    </div>
                                    <div class="mb-3 col-3">
                                        <input type="checkbox" class="form-checkbox" id="polygraph" name="exam_type[]" value="Latent Print" onchange="updateExamType2()">
                                        <label class="strong mb-1" for="polygraph">Latent Print</label><br>
                                    </div>
                                    <div class="mb-3 col-6">
                                        <input type="checkbox" class="form-checkbox" id="dna_analysis" name="exam_type[]" value="Standard Fingerprint Chart" onchange="updateExamType2()">
                                        <label class="strong mb-1" for="dna_analysis">Standard Fingerprint Chart</label><br>
                                    </div>
                                    <!-- End of Checkbox options -->

                                    <div class="mb-3 col-md-8">
                                        <div class="form-group">
                                            <label for="requesting_party" class="strong mb-1">Requesting Party</label>
                                            <input type="text" class="form-control" id="requesting_party" name="requesting_party">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="delivered_by" class="strong mb-1">Delivered by (station)</label>
                                            <input type="text" class="form-control" id="delivered_by" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="victims" class="strong mb-1">Victim/s</label>
                                            <input type="text" class="form-control" id="victims" name="victims">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="suspects" class="strong mb-1">Suspect/s</label>
                                            <input type="text" class="form-control" id="suspects" name="suspects">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="examiner" class="strong mb-1">Examiner</label>
                                            <input type="text" class="form-control" id="examiner" name="examiner" required>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="occurrence_details" class="strong mb-1">Time, Date & Place of Occurrence</label>
                                            <input type="text" class="form-control" id="occurrence_details" name="occurrence_datetime">
                                        </div>
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group  bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" required name="nature_of_case" class="form-select">
                                                <option value="Found Dead Body">Found Dead Body</option>
                                                <option value="Shooting Incident">Shooting Incident</option>
                                                <option value="Robbery">Robbery</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="dissolve" placeholder="Enter other nature of case">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="remarks" class="strong mb-1">Remarks (In Custody, Court, Requesting Party)</label>
                                            <select name="remarks" id="remarks" class="form-control">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                                <option value="Turned Over To Requesting Party">Turned over to Requesting Party</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-end">
                                        <button type="button" class="btn btn-sm btn-danger" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" value="submit" class="btn btn-sm btn-primary" id="update_btn">Submit</button>
                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>

            <?php
            $div = "Fingerprint";
            include "globals/file_modal.php";
            ?>
        </main>


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

                        

                        
<script>
    $('#fingerprint_table').DataTable({
         dom: 'fQrBtip',
                    responsive: true,
                    buttons: [
                         {
                text: 'Add Case', // Button text
                className: 'add_case', // Optional: Custom class for styling
                attr: {
                    'data-bs-toggle': 'modal', // Custom attribute and its value
                    'data-bs-target': '#add_fingerprint_case', // Another example of a custom attribute
                    'title': 'Click to add case' // Tooltip title
                },

            },

                        {
                            extend: 'excel',
                            text: 'Excel',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'pdf',
                            text: 'PDF',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'print',
                            text: 'Print',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'colvis',
                            text: 'Show/Hide Columns',
                        }
                    ],
                    fixedHeader: true,
                    paging: true,
                    searching: true,
                    ordering: true,
                    scrollY: '300px',
                    colReorder: true,
                    scrollCollapse: true,
                    language: {
                        search: "Search:"

                    },
                });
</script>
<script>
    $(document).on("input", "#other_drug", function() {
        $("#other_input").removeClass('d-none');
        var drug_name = $("#other_drug").val()
        if (drug_name == "") {
            $("#other_input").addClass('d-none')
        } else {
            $('#other_input #text_label').text(`Weight in grams of ${drug_name}`)
        }
    })
</script>
<script>
    function updateExamType() {
        const checkboxes = document.querySelectorAll('input[name="exam_type[]"]');
        const checkedValues = [];
        checkboxes.forEach(checkbox => {
            console.log(checkbox.value)
            if (checkbox.checked) {
                checkedValues.push(checkbox.value);

            }
        });
        const valuesString = checkedValues.join(',');
        document.getElementById('evidence_submitted').value = valuesString;

    }
</script>
<script>
    function updateExamType2() {
        const checkboxes = document.querySelectorAll('#edit_form input[name="exam_type[]"]');
        const checkedValues = [];
        checkboxes.forEach(checkbox => {
            console.log(checkbox.value)
            if (checkbox.checked) {
                checkedValues.push(checkbox.value);

            }
        });
        const valuesString = checkedValues.join(',');
        document.getElementById('evidence_submitted2').value = valuesString;

    }
</script>

<?php include "globals/dt_style.php"; ?>

<?php
include "globals/modal_scripts.php";
?>


<script>
    $(document).on('click', '#edit_case', function() {
        var case_id = $(this).attr('data-case_id');
        $('#update_btn').attr('data-case_id', case_id)

        // Fetch the data from the server
        fetch(`./edit_handlers/fingerprint_division.php?case_id=${case_id}`)
            .then(response => response.json()) // Parse the JSON response
            .then(data => {
                console.log(data);
                $('#edit_form input[name="case_number"]').val(data[0].case_number);
                $('#edit_form input[name="date_completed"]').val(data[0].date_completed);
                $('#edit_form input[name="date_received"]').val(data[0].date_received);
                $('#edit_form input[name="delivered_by"]').val(data[0].delivered_by);
                $('#edit_form input[name="examinations"]').val(data[0].examinations);
                $('#edit_form input[name="examiner"]').val(data[0].examiner);
                $('#edit_form #evidence_submitted2').val(data[0].evidence_submitted);

                $('#edit_form input[name="occurrence_datetime"]').val(data[0].occurrence_datetime); // Assuming 'occurrence_details' corresponds to 'occurrence_datetime'
                $('#edit_form select[name="remarks"]').val(data[0].remarks);
                $('#edit_form input[name="requesting_party"]').val(data[0].requesting_party);
                $('#edit_form input[name="status"]').val(data[0].status);
                $('#edit_form input[name="suspects"]').val(data[0].subject);
                $('#edit_form input[name="victims"]').val(data[0].victims);


                $("#edit_form select[name='nature_of_case']").append(`<option value='${data[0].nature_of_case}'>${data[0].nature_of_case}</option>`);
                $("#edit_form select[name='nature_of_case']").val(`${data[0].nature_of_case}`);







                // Set remarks select value
                $("#edit_form select[name='remarks']").val(data[0].remarks);

                // Handle remarks select field
                $("select[name='remarks']").val(data[0].remarks);

            })
            .catch(err => {
                console.error(err);
            });
    });
</script>


<script>
    $(document).on('click', '#update_btn', function(e) {
        e.preventDefault();

        var case_id = $(this).attr('data-case_id'); // Assuming you get the case_id from somewhere
        var formData = $("#edit_form").serialize();

        // Append case_id to formData
        formData += '&case_id=' + encodeURIComponent(case_id);
        console.log(formData)
        fetch(`./update_handlers/fingerprint_division.php?${formData}`)
            .then(response => response.json())
            .then(data => {
                if (data.success == true) {
                    alert("Updated successfully");
                    window.location.reload()
                }
                // Handle success: maybe redirect or update UI
            })
            .catch((error) => {
                console.error('Error:', error);
            });


    })
</script>
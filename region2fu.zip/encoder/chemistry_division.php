<?php
include "../src/connection.php";
include "globals/head.php";
?>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $unit = $_SESSION['unit'];
    $case_number = $_POST['case_number'];
    $type_of_examination = $_POST['type_of_examination'];
    $no_of_examination = $_POST['no_of_examination'];
    $datetime_received = $_POST['datetime_received'];
    $datetime_completed = $_POST['datetime_completed'];
    $evidence = $_POST['evidence'];
    $suspect = $_POST['suspect'];
    $victim = $_POST['victim'];
    $subject = $_POST['subject'];
    $requesting_party = $_POST['requesting_party'];
    $delivered_by = $_POST['delivered_by'];
    $tdpo_no = $_POST['tdpo_no'];
    $examiner = $_POST['examiner'];
    $nature_of_case = $_POST['nature_of_case'];
    $duty_receiving_officer = $_POST['duty_receiving_officer'];
    $casts_taken_by = $_POST['casts_taken_by'];
    $witnessed_by = $_POST['witnessed_by'];
    $result_of_examination = $_POST['result_of_examination'];
    $remarks = $_POST['remarks'];
    $status = "Pending";
    // Insert data into database
    $sql = "INSERT INTO chemistry_one (case_number, type_of_examination, no_of_examination, datetime_received, datetime_completed, evidence, suspect, victim, subject, requesting_party, delivered_by, tdpo_no, examiner, nature_of_case, duty_receiving_officer, casts_taken_by, witnessed_by, result_of_examination, remarks, unit, status)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssssssssssssss", $case_number, $type_of_examination, $no_of_examination, $datetime_received, $datetime_completed, $evidence, $suspect, $victim, $subject, $requesting_party, $delivered_by, $tdpo_no, $examiner, $nature_of_case, $duty_receiving_officer, $casts_taken_by, $witnessed_by, $result_of_examination, $remarks, $unit, $status);

    if ($stmt->execute()) {
        $message = "New record created successfully";
        header("Location: chemistry_division.php");
        exit();
    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error;
    }

    $stmt->close();
}
?>

<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>

        <main class="content bg-white">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Chemistry Division</h1>

                <div class="row bg-white p-2 border">

                    <div class="col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">

                            <div class="table-responsive p-3">
                                <table class="table w-100 table-bordered p-2 bg-white mx-auto" id="chem_table">
                                    <thead class="border border-primary bg-info">
                                        <tr>
                                            <th class="text-center text-white">Actions</th>
                                            <th class="text-center text-white">Status</th>
                                            <th class="text-center text-white">Case Number</th>
                                            <th class="text-center text-white">Type of Examination</th>
                                            <th class="text-center text-white">No. of Examination</th>
                                            <th class="text-center text-white">Time and Date Received</th>
                                            <th class="text-center text-white">Time and Date Completed</th>
                                            <th class="text-center text-white">Evidence Submitted/Collected</th>
                                            <th class="text-center text-white">Suspect</th>
                                            <th class="text-center text-white">Victim</th>
                                            <th class="text-center text-white">Subject (Paraffin Only)</th>
                                            <th class="text-center text-white">Requesting Party</th>
                                            <th class="text-center text-white">Delivered By</th>
                                            <th class="text-center text-white">TDPO No.</th>
                                            <th class="text-center text-white">Examiner</th>
                                            <th class="text-center text-white">Nature of Case</th>
                                            <th class="text-center text-white">Duty Receiving Officer</th>
                                            <th class="text-center text-white">Casts Taken By (Paraffin Only)</th>
                                            <th class="text-center text-white">Witnessed by (Paraffin Only)</th>
                                            <th class="text-center text-white">Result of Examination</th>
                                            <th class=" ">Remarks</th>


                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sql = "SELECT * FROM chemistry_one where unit = '$unit'";
                                        $result = mysqli_query($conn, $sql);

                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_assoc($result)) {
                                                echo "<tr class='text-black'>";
                                                include 'globals/action_buttons.php';
                                                if ($row["status"] == "Pending") {
                                                    $el = "<span class='badge bg-warning  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Reviewed") {
                                                    $el = "<span class='badge bg-info  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "With Revisions") {
                                                    $el = "<span class='badge bg-danger  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Approved") {
                                                    $el = "<span class='badge bg-success  text-center text-white'>" . $row["status"] . "</span>";
                                                } else {
                                                    $el = "<span class='badge bg-secondary  text-center text-white'>" . "N/A" . "</span>";
                                                }
                                                echo "<td class='text-center'>" . $el . "</td>";
                                                echo "<td>" . $row['case_number'] . "</td>";
                                                echo "<td>" . $row['type_of_examination'] . "</td>";
                                                echo "<td>" . $row['no_of_examination'] . "</td>";
                                                echo "<td>" . $row['datetime_received'] . "</td>";
                                                echo "<td>" . $row['datetime_completed'] . "</td>";
                                                echo "<td>" . $row['evidence'] . "</td>";
                                                echo "<td>" . $row['suspect'] . "</td>";
                                                echo "<td>" . $row['victim'] . "</td>";
                                                echo "<td>" . $row['subject'] . "</td>";
                                                echo "<td>" . $row['requesting_party'] . "</td>";
                                                echo "<td>" . $row['delivered_by'] . "</td>";
                                                echo "<td>" . $row['tdpo_no'] . "</td>";
                                                echo "<td>" . $row['examiner'] . "</td>";
                                                echo "<td>" . $row['nature_of_case'] . "</td>";
                                                echo "<td>" . $row['duty_receiving_officer'] . "</td>";
                                                echo "<td>" . $row['casts_taken_by'] . "</td>";
                                                echo "<td>" . $row['witnessed_by'] . "</td>";
                                                echo "<td>" . $row['result_of_examination'] . "</td>";
                                                echo "<td>" . $row['remarks'] . "</td>";

                                                echo "</tr>";
                                            }
                                        }

                                        // Close the database connection
                                        mysqli_close($conn);
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>



                    <div class="col-lg-10 mx-auto bg-white">
                        <div class="table-responsive">

                        </div>
                    </div>

                </div>
            </div>

            <div class="modal fade" id="add_case_chemistry" tabindex="-1" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header bg-info">
                            <h5 class="modal-title text-white">Add New Chemistry Case</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <div class="row p-2">
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="case_number" class="strong mb-1" style="font-weight: bold;">Case Number</label>
                                            <input type="text" class="form-control" id="case_number" name="case_number" placeholder="C-001-24-RFU2">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="type_of_examination" class="strong mb-1" style="font-weight: bold;">Type of Examination</label>
                                            <select class="form-select" id="type_of_examination" name="type_of_examination">
                                                <option value="GPR Paraffin Test">GPR Paraffin Test</option>
                                                <option value="GPR for Firearms">GPR for Firearms</option>
                                                <option value="Chemical Analysis">Chemical Analysis</option>
                                                <option value="Explosive">Explosive</option>
                                                <option value="Toxicology">Toxicology</option>
                                                <option value="Alcohol Analysis">Alcohol Analysis</option>
                                                <option value="Unfair Trade Competition">Unfair Trade Competition</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="num_of_examination" class="strong mb-1" style="font-weight: bold;">No. of Examination</label>
                                            <input type="number" min="0" max="1000" class="form-control" id="num_of_examination" name="no_of_examination">
                                        </div>
                                    </div>



                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="date_received" class="strong mb-1" style="font-weight: bold;">Time and Date Received</label>
                                            <input type="datetime-local" class="form-control" id="date_received" name="datetime_received">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="date_completed" class="strong mb-1" style="font-weight: bold;">Time and Date Completed</label>
                                            <input type="datetime-local" class="form-control" id="date_completed" name="datetime_completed">
                                        </div>
                                    </div>

                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="suspect" class="strong mb-1" style="font-weight: bold;">Suspect</label>
                                            <input type="text" class="form-control" id="suspect" name="suspect">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="victim" class="strong mb-1" style="font-weight: bold;">Victim</label>
                                            <input type="text" class="form-control" id="victim" name="victim">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="requesting_party" class="strong mb-1" style="font-weight: bold;">Requesting Party</label>
                                            <input type="text" class="form-control" id="requesting_party" name="requesting_party">
                                        </div>
                                    </div>

                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="delivered_by" class="strong mb-1" style="font-weight: bold;">Delivered By</label>
                                            <input type="text" class="form-control" id="delivered_by" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="tdpo_number" class="strong mb-1" style="font-weight: bold;">TDPO</label>
                                            <input type="text" class="form-control" id="tdpo_number" name="tdpo_no">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="duty_officer" class="strong mb-1" style="font-weight: bold;">Duty Receiving Officer</label>
                                            <input type="text" class="form-control" id="duty_officer" name="duty_receiving_officer">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="subject" class="strong mb-1" style="font-weight: bold;">Subject (Paraffin Only)</label>
                                            <input type="text" class="form-control" id="subject" name="subject">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="casts_paraffin" class="strong mb-1" style="font-weight: bold;">Casts Taken By (Paraffin Only)</label>
                                            <input type="text" class="form-control" id="casts_paraffin" name="casts_taken_by">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="witness_paraffin" class="strong mb-1" style="font-weight: bold;">Witnessed by (Paraffin Only)</label>
                                            <input type="text" class="form-control" id="witness_paraffin" name="witnessed_by">
                                        </div>
                                    </div>
                                    <div class="col-lg-8 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="examiner" class="strong mb-1" style="font-weight: bold;">Examiner</label>
                                            <input type="text" class="form-control" id="examiner" name="examiner">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" name="nature_of_case" class="form-select">
                                                <option value="Shooting Incident">Shooting Incident</option>
                                                <option value="Found Dead Body">Found Dead Body</option>
                                                <option value="Alleged Violation of RA 9165">Alleged Violation of RA 9165</option>
                                                <option value="Alleged Violation of RA 10591">Alleged Violation of RA 10591</option>
                                                <option value="Alleged Violation of RA 10586">Alleged Violation of RA 10586</option>
                                                <option value="Alleged Violation of RA 9516">Alleged Violation of RA 9516</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="other_nature_case_input" placeholder="Enter other nature of case">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="evidence" class="strong mb-1" style="font-weight: bold;">Evidence Submitted/Collected</label>
                                            <textarea class="form-control" id="evidence" name="evidence" rows="3"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="result_of_examination" class="strong mb-1" style="font-weight: bold;">Result of Examination</label>
                                            <textarea class="form-control" id="result_of_examination" name="result_of_examination" rows="3"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="remarks" class="strong mb-1" style="font-weight: bold;">Remarks</label>
                                            <textarea class="form-control" id="remarks" name="remarks" rows="3"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>



            <?php
            $div = "Chemistry";
            include "globals/file_modal.php";
            ?>



            <div class="modal fade" id="edit_case_modal" tabindex="-1" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header bg-info">
                            <h5 class="modal-title text-white">Chemistry Division</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="" method="post" id="edit_form">
                                <div class="row p-2">
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="case_number" class="strong mb-1" style="font-weight: bold;">Case Number</label>
                                            <input type="text" class="form-control" id="case_number" name="case_number" placeholder="C-001-24-RFU2">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="type_of_examination" class="strong mb-1" style="font-weight: bold;">Type of Examination</label>
                                            <select class="form-select" id="type_of_examination" name="type_of_examination">
                                                <option value="GPR Paraffin Test">GPR Paraffin Test</option>
                                                <option value="GPR for Firearms">GPR for Firearms</option>
                                                <option value="Chemical Analysis">Chemical Analysis</option>
                                                <option value="Explosive">Explosive</option>
                                                <option value="Toxicology">Toxicology</option>
                                                <option value="Alcohol Analysis">Alcohol Analysis</option>
                                                <option value="Unfair Trade Competition">Unfair Trade Competition</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="num_of_examination" class="strong mb-1" style="font-weight: bold;">No. of Examination</label>
                                            <input type="number" min="0" max="1000" class="form-control" id="num_of_examination" name="no_of_examination">
                                        </div>
                                    </div>



                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="date_received" class="strong mb-1" style="font-weight: bold;">Time and Date Received</label>
                                            <input type="datetime-local" class="form-control" id="date_received" name="datetime_received">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="date_completed" class="strong mb-1" style="font-weight: bold;">Time and Date Completed</label>
                                            <input type="datetime-local" class="form-control" id="date_completed" name="datetime_completed">
                                        </div>
                                    </div>

                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="suspect" class="strong mb-1" style="font-weight: bold;">Suspect</label>
                                            <input type="text" class="form-control" id="suspect" name="suspect">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="victim" class="strong mb-1" style="font-weight: bold;">Victim</label>
                                            <input type="text" class="form-control" id="victim" name="victim">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="requesting_party" class="strong mb-1" style="font-weight: bold;">Requesting Party</label>
                                            <input type="text" class="form-control" id="requesting_party" name="requesting_party">
                                        </div>
                                    </div>

                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="delivered_by" class="strong mb-1" style="font-weight: bold;">Delivered By</label>
                                            <input type="text" class="form-control" id="delivered_by" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="tdpo_number" class="strong mb-1" style="font-weight: bold;">TDPO</label>
                                            <input type="text" class="form-control" id="tdpo_number" name="tdpo_no">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="duty_officer" class="strong mb-1" style="font-weight: bold;">Duty Receiving Officer</label>
                                            <input type="text" class="form-control" id="duty_officer" name="duty_receiving_officer">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="subject" class="strong mb-1" style="font-weight: bold;">Subject (Paraffin Only)</label>
                                            <input type="text" class="form-control" id="subject" name="subject">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="casts_paraffin" class="strong mb-1" style="font-weight: bold;">Casts Taken By (Paraffin Only)</label>
                                            <input type="text" class="form-control" id="casts_paraffin" name="casts_taken_by">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="witness_paraffin" class="strong mb-1" style="font-weight: bold;">Witnessed by (Paraffin Only)</label>
                                            <input type="text" class="form-control" id="witness_paraffin" name="witnessed_by">
                                        </div>
                                    </div>
                                    <div class="col-lg-8 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="examiner" class="strong mb-1" style="font-weight: bold;">Examiner</label>
                                            <input type="text" class="form-control" id="examiner" name="examiner">
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" name="nature_of_case" class="form-select">
                                                <option value="Shooting Incident">Shooting Incident</option>
                                                <option value="Found Dead Body">Found Dead Body</option>
                                                <option value="Alleged Violation of RA 9165">Alleged Violation of RA 9165</option>
                                                <option value="Alleged Violation of RA 10591">Alleged Violation of RA 10591</option>
                                                <option value="Alleged Violation of RA 10586">Alleged Violation of RA 10586</option>
                                                <option value="Alleged Violation of RA 9516">Alleged Violation of RA 9516</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="other_nature_case_input" placeholder="Enter other nature of case">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="evidence" class="strong mb-1" style="font-weight: bold;">Evidence Submitted/Collected</label>
                                            <textarea class="form-control" id="evidence" name="evidence" rows="3"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="result_of_examination" class="strong mb-1" style="font-weight: bold;">Result of Examination</label>
                                            <textarea class="form-control" id="result_of_examination" name="result_of_examination" rows="3"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-group bg-white" style="border-radius: 5px;">
                                            <label for="remarks" class="strong mb-1" style="font-weight: bold;">Remarks</label>
                                            <textarea class="form-control" id="remarks" name="remarks" rows="3"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary" id="update_btn">Save changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </main>


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#chem_table').DataTable({
        dom: 'fQrBtip',
                    responsive: true,
                    buttons: [
                         {
                text: 'Add Case', // Button text
                className: 'add_case', // Optional: Custom class for styling
                attr: {
                    'data-bs-toggle': 'modal', // Custom attribute and its value
                    'data-bs-target': '#add_case_chemistry', // Another example of a custom attribute
                    'title': 'Click to add case' // Tooltip title
                },

            },
                        {
                            extend: 'excel',
                            text: 'Excel',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'pdf',
                            text: 'PDF',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'print',
                            text: 'Print',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'colvis',
                            text: 'Show/Hide Columns',
                        }
                    ],
                    fixedHeader: true,
                    paging: true,
                    searching: true,
                    ordering: true,
                    scrollY: '300px',
                    colReorder: true,
                    scrollCollapse: true,
                    language: {
                        search: "Search:"

                    },
                
    })
</script>

<?php include "globals/dt_style.php"; ?>

<?php
include "globals/modal_scripts.php";
?>




<script>
    $(document).on('click', '#edit_case', function() {
        var case_id = $(this).attr('data-case_id');
        $('#update_btn').attr('data-case_id', case_id)

        // Fetch the data from the server
        fetch(`./edit_handlers/chemistry_division.php?case_id=${case_id}`)
            .then(response => response.json()) // Parse the JSON response
            .then(data => {
                console.log(data);

                $("#edit_form input[name='case_number']").val(data[0].case_number);
                $("#edit_form select[name='type_of_examination']").val(data[0].type_of_examination);
                $("#edit_form input[name='no_of_examination']").val(data[0].no_of_examination);
                $("#edit_form input[name='datetime_received']").val(data[0].datetime_received.replace(' ', 'T')); // Adjust datetime format if needed
                $("#edit_form input[name='datetime_completed']").val(data[0].datetime_completed.replace(' ', 'T')); // Adjust datetime format if needed
                $("#edit_form input[name='suspect']").val(data[0].suspect);
                $("#edit_form input[name='victim']").val(data[0].victim);
                $("#edit_form input[name='requesting_party']").val(data[0].requesting_party);
                $("#edit_form input[name='delivered_by']").val(data[0].delivered_by);
                $("#edit_form input[name='tdpo_no']").val(data[0].tdpo_no);
                $("#edit_form input[name='duty_receiving_officer']").val(data[0].duty_receiving_officer);
                $("#edit_form input[name='subject']").val(data[0].subject);
                $("#edit_form input[name='casts_taken_by']").val(data[0].casts_taken_by);
                $("#edit_form input[name='witnessed_by']").val(data[0].witnessed_by);
                $("#edit_form input[name='examiner']").val(data[0].examiner);

                $("#edit_form textarea[name='evidence']").val(data[0].evidence);
                $("#edit_form textarea[name='result_of_examination']").val(data[0].result_of_examination);
                $("#edit_form textarea[name='remarks']").val(data[0].remarks);
                $("#edit_form select[name='nature_of_case']").append(`<option value='${data[0].nature_of_case}'>${data[0].nature_of_case}</option>`);
                $("#edit_form select[name='nature_of_case']").val(`${data[0].nature_of_case}`);
                $("#edit_form input[name='remarks']").val(data[0].remarks);

            })
            .catch(err => {
                console.error(err);
            });
    });
</script>



<script>
    $(document).on('click', '#update_btn', function(e) {
        e.preventDefault();

        var case_id = $(this).attr('data-case_id'); // Assuming you get the case_id from somewhere
        var formData = $("#edit_form").serialize();

        // Append case_id to formData
        formData += '&case_id=' + encodeURIComponent(case_id);
        console.log(formData)
        fetch(`./update_handlers/chemistry_division.php?${formData}`)
            .then(response => response.json())
            .then(data => {
                if (data.success == true) {
                    alert("Updated successfully");
                    window.location.reload()
                }
                // Handle success: maybe redirect or update UI
            })
            .catch((error) => {
                console.error('Error:', error);
            });


    })
</script>
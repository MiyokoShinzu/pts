<?php
include "../src/connection.php";
include "globals/head.php";

?>

<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $case_number = $_POST['case_number'];
    $examinations = $_POST['examinations'];
    $date_received = $_POST['date_received'];
    $date_completed = $_POST['date_completed'];
    $submission_date = $_POST['submission_date'];
    $meth = $_POST['meth'];
    $meth_specimen = $_POST['meth_specimen'];
    $mj = $_POST['mj'];
    $mj_specimen = $_POST['mj_specimen'];
    $other = $_POST['other'];
    $other_specimen = $_POST['other_specimen'];
    $other_weight = $_POST['other_weight'];
    $paraphernalia = $_POST['paraphernalia'];
    $requesting_party = $_POST['requesting_party'];
    $delivered_by = $_POST['delivered_by'];
    $suspects = $_POST['suspects'];
    $examiner = $_POST['examiner'];
    $date_to_custodian = $_POST['date_to_custodian'];
    $custodian_name = $_POST['custodian_name'];
    $receiving_pnco = $_POST['receiving_pnco'];
    $operation_type = $_POST['operation_type'];
    $investigator = $_POST['investigator'];
    $remarks = $_POST['remarks'];
    $result = $_POST['result'];
    $court_branch = $_POST['court_branch'];
    $status = "Pending";
    $unit = $_SESSION['unit'];

    $sql = "INSERT INTO chemistry_two (case_number, examinations, date_received, date_completed, submission_date, meth, meth_specimen, mj, mj_specimen, other, other_specimen, other_weight, paraphernalia, requesting_party, delivered_by, suspects, examiner, date_to_custodian, custodian_name, receiving_pnco, operation_type, investigator, remarks, result, court_branch, status, unit) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "sssssssssssssssssssssssssss",
        $case_number,
        $examinations,
        $date_received,
        $date_completed,
        $submission_date,
        $meth,
        $meth_specimen,
        $mj,
        $mj_specimen,
        $other,
        $other_specimen,
        $other_weight,
        $paraphernalia,
        $requesting_party,
        $delivered_by,
        $suspects,
        $examiner,
        $date_to_custodian,
        $custodian_name,
        $receiving_pnco,
        $operation_type,
        $investigator,
        $remarks,
        $result,
        $court_branch,
        $status,
        $unit
    );

    if ($stmt->execute()) {
        header("Location: chemistry_drug_division.php");
        exit();
    } else {
        print_r($conn->error);
    }

    $stmt->close();
    $conn->close();
}
?>
<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>
        <?php
        $sql = "SELECT * FROM chemistry_two  where unit = '$unit'";
        $result = $conn->query($sql);
        ?>
        <main class="content bg-white">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3"><strong>Drug Case Chemistry</strong> Division</h1>
                <div class="row bg-white p-2 ">

                    <div class="col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">
                            <div class="table-responsive">
                                <table id="drug_case_table" class="table w-100 table-bordered p-2 bg-white mx-auto">
                                    <thead class="border border-primary bg-info">
                                        <tr>
                                            <th class="text-center text-white">Actions</th>
                                            <th class="text-center text-white">Status</th>
                                            <th class="text-center text-white">Case Number</th>
                                            <th class="text-center text-white">Examinations</th>
                                            <th class="text-center text-white">Date Received</th>
                                            <th class="text-center text-white">Date Completed</th>
                                            <th class="text-center text-white">Submission Date</th>
                                            <th class="text-center text-white">Meth</th>
                                            <th class="text-center text-white">Meth Specimen</th>
                                            <th class="text-center text-white">MJ</th>
                                            <th class="text-center text-white">MJ Specimen</th>
                                            <th class="text-center text-white">Other</th>
                                            <th class="text-center text-white">Other Specimen</th>
                                            <th class="text-center text-white">Other Weight</th>
                                            <th class="text-center text-white">Paraphernalia</th>
                                            <th class="text-center text-white">Requesting Party</th>
                                            <th class="text-center text-white">Delivered By</th>
                                            <th class="text-center text-white">Suspects</th>
                                            <th class="text-center text-white">Examiner</th>
                                            <th class="text-center text-white">Date to Custodian</th>
                                            <th class="text-center text-white">Custodian Name</th>
                                            <th class="text-center text-white">Receiving PNCO</th>
                                            <th class="text-center text-white">Operation Type</th>
                                            <th class="text-center text-white">Investigator</th>
                                            <th class="text-center text-white">Remarks</th>
                                            <th class="text-center text-white">Result</th>
                                            <th class="text-center text-white">Court Branch</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                include 'globals/action_buttons.php';

                                                if ($row["status"] == "Pending") {
                                                    $el = "<span class='badge bg-warning text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Reviewed") {
                                                    $el = "<span class='badge bg-info text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "With Revisions") {
                                                    $el = "<span class='badge bg-danger text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Approved") {
                                                    $el = "<span class='badge bg-success text-center text-white'>" . $row["status"] . "</span>";
                                                } else {
                                                    $el = "<span class='badge bg-secondary text-center text-white'>" . "N/A" . "</span>";
                                                }

                                                echo "<td class='text-center'>" . $el . "</td>";
                                                echo "<td>" . $row["case_number"] . "</td>";
                                                echo "<td>" . $row["examinations"] . "</td>";
                                                echo "<td>" . $row["date_received"] . "</td>";
                                                echo "<td>" . $row["date_completed"] . "</td>";
                                                echo "<td>" . $row["submission_date"] . "</td>";
                                                echo "<td>" . $row["meth"] . "</td>";
                                                echo "<td>" . $row["meth_specimen"] . "</td>";
                                                echo "<td>" . $row["mj"] . "</td>";
                                                echo "<td>" . $row["mj_specimen"] . "</td>";
                                                echo "<td>" . $row["other"] . "</td>";
                                                echo "<td>" . $row["other_specimen"] . "</td>";
                                                echo "<td>" . $row["other_weight"] . "</td>";
                                                echo "<td>" . $row["paraphernalia"] . "</td>";
                                                echo "<td>" . $row["requesting_party"] . "</td>";
                                                echo "<td>" . $row["delivered_by"] . "</td>";
                                                echo "<td>" . $row["suspects"] . "</td>";
                                                echo "<td>" . $row["examiner"] . "</td>";
                                                echo "<td>" . $row["date_to_custodian"] . "</td>";
                                                echo "<td>" . $row["custodian_name"] . "</td>";
                                                echo "<td>" . $row["receiving_pnco"] . "</td>";
                                                echo "<td>" . $row["operation_type"] . "</td>";
                                                echo "<td>" . $row["investigator"] . "</td>";
                                                echo "<td>" . $row["remarks"] . "</td>";
                                                echo "<td>" . $row["result"] . "</td>";
                                                echo "<td>" . $row["court_branch"] . "</td>";
                                                echo "</tr>";
                                            }
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>



                    <div class="col-lg-10 mx-auto bg-white">
                        <div class="table-responsive">

                        </div>
                    </div>

                </div>
            </div>


            <div class="modal" tabindex="-1" id="add_drug_case_chemistry" tabindex="-1" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-info">
                            <h5 class="modal-title text-white">Add New Drug Case</h5>
                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-group mb-3">
                                            <label for="case_number" class="strong">Case Number</label>
                                            <input type="text" name="case_number" class="form-control" placeholder="D-001-24-RFU2">
                                        </div>
                                    </div>

                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="examinations" class="strong">No. of Examination</label>
                                            <input type="number" name="examinations" min=0 max=1000 class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group mb-3">
                                            <label for="date_received" class="strong">Time and Date Received</label>
                                            <input type="datetime-local" name="date_received" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group mb-3">
                                            <label for="date_completed" class="strong">Time and Date Completed</label>
                                            <input type="datetime-local" name="date_completed" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group mb-3">
                                            <label for="submission_date" class="strong">Date of Submission</label>
                                            <input type="datetime-local" name="submission_date" class="form-control">
                                        </div>
                                    </div>
                                    <br>
                                    <hr class="mt-3 mb-3">
                                    <br>
                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="meth" class="strong">No. Specimen of Meth</label>
                                            <input type="number" name="meth_specimen" class="form-control" placeholder="Quantity">
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="meth" class="strong">Meth</label>
                                            <input type="text" name="meth" class="form-control" placeholder="Weight">
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="meth" class="strong">No. Specimen of MJ</label>
                                            <input type="number" name="mj_specimen" class="form-control" placeholder="Quantity">
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="mj" class="strong">MJ</label>
                                            <input type="text" name="mj" class="form-control" placeholder="Weight">
                                        </div>
                                    </div>

                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="other_drug" class="strong" style="font-weight: bolder">Others</label>
                                            <input type="text" name="other" placeholder="Please Specify" id="other_drug" class="form-control">
                                            <small>Leave it blank if there is no other name of drug</small>

                                        </div>
                                    </div>
                                    <div id="other_input" class="col-lg-3 ">
                                        <div class="form-group mb-3">
                                            <label for="other_specify" class="strong" style="font-weight: bolder" id="text_label">Weight of Other</label>
                                            <input type="text" name="other_weight" placeholder="" class="form-control">
                                            <small>Leave it blank if there is no other name of drug</small>

                                        </div>
                                    </div>
                                    <div id="other_input2" class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="other_specify2" class="strong" style="font-weight: bolder" id="text_label2">No. of specimen of others</label>
                                            <input type="text" name="other_specimen" placeholder="" class="form-control">
                                            <small>Leave it blank if there is no other name of drug</small>
                                        </div>
                                    </div>

                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="paraphernalia" class="strong">No. of paraphernalia</label>
                                            <input type="number" name="paraphernalia" min=0 max=1000 class="form-control">
                                        </div>
                                    </div>
                                    <br>
                                    <hr class="mt-3 mb-5"><br>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" placeholder="" name="requesting_party" class="form-control">
                                            <label for="requesting_party" class="strong">Requesting Party</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" placeholder="" name="delivered_by" class="form-control">
                                            <label for="delivered_by" class="strong">Delivered by (station)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" placeholder="" name="suspects" class="form-control">
                                            <label for="suspects" class="strong">Suspect/s</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" placeholder="" name="examiner" class="form-control" required>
                                            <label for="examiner" class="strong">EXAMINER</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-3">
                                            <input type="text" placeholder="" name="date_to_custodian" class="form-control">
                                            <label for="date_to_custodian" class="strong">Time and Date t/o to Evidence Custodian</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-3">
                                            <input type="text" name="custodian_name" placeholder="" class="form-control">
                                            <label for="custodian_name" class="strong">Name of Custodian</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-3">
                                            <input type="text" name="receiving_pnco" placeholder="" class="form-control">
                                            <label for="receiving_pnco" class="strong">Duty Receiving PNCO(If applicable)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-3">
                                            <select name="operation_type" placeholder="" class="form-select" id="operation_type">
                                                <option value="BUY BUST">BUY BUST</option>
                                                <option value="TEST BUY">TEST BUY</option>
                                                <option value="RECOVERED">RECOVERED</option>
                                                <option value="SURRENDERED">SURRENDERED</option>
                                                <option value="Implementation of SW">Implementation of SW</option>
                                                <!-- Add input like nature of case -->
                                            </select>
                                            <label for="operation_type" class="strong">Type of Operation</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-3">
                                            <input type="text" name="investigator" class="form-control" placeholder="">
                                            <label for="investigator" class="strong">Investigator on Case</label>
                                        </div>
                                    </div>

                                    <div class="col-lg-3">
                                        <div class="form-floating mb-3">
                                            <input type="datetime-local" name="date_to_custodian" class="form-control" placeholder="">
                                            <label for="date_to_custodian" class="strong">Time and Date</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control" name="result" placeholder="">
                                            <label for="result" class="strong">Result</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-5">
                                        <div class="form-floating mb-3">
                                            <input type="text" name="court_branch" class="form-control" placeholder="">
                                            <label for="court_branch" class="strong">Branch of Court(Br 33, Ballesteros, etc)</label>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-floating mb-3">
                                            <select name="remarks" id="remarks" placeholder="" class="form-select">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                                <option value="Turnovered To PDEA">Turnovered to PDEA</option>
                                            </select>
                                            <label for="remarks" class="strong">Remarks(In Custody, Court, PDEA)</label>
                                        </div>
                                    </div>

                                    <div class="col-lg-12 text-end">
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-info" value="submit">Submit</button>
                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>




            <div class="modal" tabindex="-1" id="edit_case_modal" tabindex="-1" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Add New Drug Case</h5>
                        </div>
                        <div class="modal-body">
                            <form method="get" id="edit_form">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-group mb-3">
                                            <label for="case_number" class="strong">Case Number</label>
                                            <input type="text" name="case_number" class="form-control" placeholder="D-001-24-RFU2">
                                        </div>
                                    </div>

                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="examinations" class="strong">No. of Examination</label>
                                            <input type="number" name="examinations" min=0 max=1000 class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group mb-3">
                                            <label for="date_received" class="strong">Time and Date Received</label>
                                            <input type="datetime-local" name="date_received" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group mb-3">
                                            <label for="date_completed" class="strong">Time and Date Completed</label>
                                            <input type="datetime-local" name="date_completed" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group mb-3">
                                            <label for="submission_date" class="strong">Date of Submission</label>
                                            <input type="datetime-local" name="submission_date" class="form-control">
                                            <small>For Editing **Remove</small>
                                        </div>
                                    </div>
                                    <br>
                                    <hr class="mt-3 mb-3">
                                    <br>
                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="meth" class="strong">No. Specimen of Meth</label>
                                            <input type="number" name="meth_specimen" class="form-control" placeholder="Quantity">
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="meth" class="strong">Meth</label>
                                            <input type="text" name="meth" class="form-control" placeholder="Weight">
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="meth" class="strong">No. Specimen of MJ</label>
                                            <input type="number" name="mj_specimen" class="form-control" placeholder="Quantity">
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="mj" class="strong">MJ</label>
                                            <input type="text" name="mj" class="form-control" placeholder="Weight">
                                        </div>
                                    </div>

                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="other_drug" class="strong" style="font-weight: bolder">Others</label>
                                            <input type="text" name="other" placeholder="Please Specify" id="other_drug" class="form-control">
                                            <small>Leave it blank if there is no other name of drug</small>

                                        </div>
                                    </div>
                                    <div id="other_input" class="col-lg-3 ">
                                        <div class="form-group mb-3">
                                            <label for="other_specify" class="strong" style="font-weight: bolder" id="text_label">Weight of Other</label>
                                            <input type="text" name="other_weight" placeholder="" class="form-control">
                                            <small>Leave it blank if there is no other name of drug</small>

                                        </div>
                                    </div>
                                    <div id="other_input2" class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="other_specify2" class="strong" style="font-weight: bolder" id="text_label2">No. of specimen of others</label>
                                            <input type="text" name="other_specimen" placeholder="" class="form-control">
                                            <small>Leave it blank if there is no other name of drug</small>
                                        </div>
                                    </div>

                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="paraphernalia" class="strong">No. of paraphernalia</label>
                                            <input type="number" name="paraphernalia" min=0 max=1000 class="form-control">
                                        </div>
                                    </div>
                                    <br>
                                    <hr class="mt-3 mb-5"><br>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" placeholder="" name="requesting_party" class="form-control">
                                            <label for="requesting_party" class="strong">Requesting Party</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" placeholder="" name="delivered_by" class="form-control">
                                            <label for="delivered_by" class="strong">Delivered by (station)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" placeholder="" name="suspects" class="form-control">
                                            <label for="suspects" class="strong">Suspect/s</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" placeholder="" name="examiner" class="form-control" required>
                                            <label for="examiner" class="strong">EXAMINER</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-3">
                                            <input type="text" placeholder="" name="date_to_custodian" class="form-control">
                                            <label for="date_to_custodian" class="strong">Time and Date t/o to Evidence Custodian</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-3">
                                            <input type="text" name="custodian_name" placeholder="" class="form-control">
                                            <label for="custodian_name" class="strong">Name of Custodian</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-3">
                                            <input type="text" name="receiving_pnco" placeholder="" class="form-control">
                                            <label for="receiving_pnco" class="strong">Duty Receiving PNCO(If applicable)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-3">
                                            <select name="operation_type" placeholder="" class="form-select" id="operation_type">
                                                <option value="BUY BUST">BUY BUST</option>
                                                <option value="TEST BUY">TEST BUY</option>
                                                <option value="RECOVERED">RECOVERED</option>
                                                <option value="SURRENDERED">SURRENDERED</option>
                                                <option value="OTHERS">OTHERS</option>
                                                <!--   Make it same as in nature of case field-->
                                                <!-- Add input like nature of case -->
                                            </select>
                                            <label for="operation_type" class="strong">Type of Operation</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-3">
                                            <input type="text" name="investigator" class="form-control" placeholder="">
                                            <label for="investigator" class="strong">Investigator on Case</label>
                                        </div>
                                    </div>

                                    <div class="col-lg-3">
                                        <div class="form-floating mb-3">
                                            <input type="datetime-local" name="date_to_custodian" class="form-control" placeholder="">
                                            <label for="date_to_custodian" class="strong">Time and Date</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control" name="result" placeholder="">
                                            <label for="result" class="strong">Result</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-5">
                                        <div class="form-floating mb-3">
                                            <input type="text" name="court_branch" class="form-control" placeholder="">
                                            <label for="court_branch" class="strong">Branch of Court(Br 33, Ballesteros, etc)</label>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-floating mb-3">
                                            <select name="remarks" id="remarks" placeholder="" class="form-select">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                                <option value="Turnovered To PDEA">Turnovered to PDEA</option>
                                            </select>
                                            <label for="remarks" class="strong">Remarks(In Custody, Court, PDEA)</label>
                                        </div>
                                    </div>

                                    <div class="col-lg-12 text-end">
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary" value="submit" id="update_btn">Submit</button>
                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>




            <?php
            $div = "Drug";
            include "globals/file_modal.php";
            ?>
        </main>


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#drug_case_table').DataTable({
      dom: 'fQrBtip',
                    responsive: true,
                    buttons: [

                         {
                text: 'Add Case', // Button text
                className: 'add_case', // Optional: Custom class for styling
                attr: {
                    'data-bs-toggle': 'modal', // Custom attribute and its value
                    'data-bs-target': '#add_drug_case_chemistry', // Another example of a custom attribute
                    'title': 'Click to add case' // Tooltip title
                },

            },
                        {
                            extend: 'excel',
                            text: 'Excel',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'pdf',
                            text: 'PDF',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'print',
                            text: 'Print',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'colvis',
                            text: 'Show/Hide Columns',
                        }
                    ],
                    fixedHeader: true,
                    paging: true,
                    searching: true,
                    ordering: true,
                    scrollY: '300px',
                    colReorder: true,
                    scrollCollapse: true,
                    language: {
                        search: "Search:"

                    },
                
    })
</script>
<script>
    $(document).on("input", "#other_drug", function() {

        var drug_name = $("#other_drug").val()
        if (1) {
            $('#other_input #text_label').text(`Weight of ${drug_name}`)
            $('#other_input2 #text_label2').text(`Number of specimen of ${drug_name}`)


        }
    })
</script>


<script>
    $(document).on('click', '#edit_case', function() {
        var case_id = $(this).attr('data-case_id');
        $('#update_btn').attr('data-case_id', case_id);


        fetch(`./edit_handlers/chemistry_drug_division.php?case_id=${case_id}`)
            .then(response => response.json())
            .then(data => {
                console.log(data);


                $('#edit_form input[name="case_number"]').val(data[0].case_number);
                $('#edit_form input[name="examinations"]').val(data[0].examinations);
                $('#edit_form input[name="date_received"]').val(data[0].date_received);
                $('#edit_form input[name="date_completed"]').val(data[0].date_completed);
                $('#edit_form input[name="submission_date"]').val(data[0].submission_date);

                $('#edit_form input[name="meth"]').val(data[0].meth);
                $('#edit_form input[name="meth_specimen"]').val(data[0].meth_specimen);
                $('#edit_form input[name="mj"]').val(data[0].mj);
                $('#edit_form input[name="mj_specimen"]').val(data[0].mj_specimen);
                $('#edit_form input[name="other"]').val(data[0].other);
                $('#edit_form input[name="other_weight"]').val(data[0].other_weight);
                $('#edit_form input[name="other_specimen"]').val(data[0].other_specimen);
                $('#edit_form input[name="paraphernalia"]').val(data[0].paraphernalia);
                $('#edit_form input[name="requesting_party"]').val(data[0].requesting_party);
                $('#edit_form input[name="delivered_by"]').val(data[0].delivered_by);
                $('#edit_form input[name="suspects"]').val(data[0].suspects);
                $('#edit_form input[name="examiner"]').val(data[0].examiner);
                $('#edit_form input[name="date_to_custodian"]').val(data[0].date_to_custodian);
                $('#edit_form input[name="custodian_name"]').val(data[0].custodian_name);
                $('#edit_form input[name="receiving_pnco"]').val(data[0].receiving_pnco);
                $('#edit_form select[name="operation_type"]').val(data[0].operation_type);
                $('#edit_form input[name="investigator"]').val(data[0].investigator);
                $('#edit_form input[name="result"]').val(data[0].result);
                $('#edit_form input[name="court_branch"]').val(data[0].court_branch);
                $('#edit_form select[name="remarks"]').val(data[0].remarks);

            })
            .catch(err => {
                console.error(err);
            });
    });
</script>

<script>
    $(document).on('click', '#update_btn', function(e) {
        e.preventDefault();

        var case_id = $(this).attr('data-case_id'); // Assuming you get the case_id from somewhere
        var formData = $("#edit_form").serialize();
        alert(case_id)
        // Append case_id to formData
        formData += '&case_id=' + encodeURIComponent(case_id);
        console.log(formData)
        fetch(`./update_handlers/chemistry_drug_division.php?${formData}`)
            .then(response => response.json())
            .then(data => {
                if (data.success == true) {
                    alert("Updated successfully");
                    window.location.reload()
                }
                // Handle success: maybe redirect or update UI
            })
            .catch((error) => {
                console.error('Error:', error);
            });


    })
</script>



<?php
include "globals/modal_scripts.php";
?>
<?php include "globals/dt_style.php"; ?>
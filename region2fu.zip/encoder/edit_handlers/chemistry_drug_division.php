<?php
include '../../src/connection.php';
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $case_id = $_GET['case_id'];
    $sql = "Select * from chemistry_two where id = '$case_id'";
    $result = $conn->query($sql);
    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);
}

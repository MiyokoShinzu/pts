<?php
include "../src/connection.php";
include "globals/head.php";
?>



<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Prepare an SQL insert statement
    $status = "Pending";
    $unit = $_SESSION['unit'];

    $stmt = $conn->prepare("INSERT INTO ml (case_number, cases_received, examinations, date_received, date_completed, evidence_submitted,  requesting_party, delivered_by, victims, suspects, examiner, occurrence_details, nature_of_case, type_of_examination, remarks, status, unit) 
                            VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    // Bind parameters to the prepared statement
    $stmt->bind_param(
        "sssssssssssssssss",
        $_POST['case_number'],
        $_POST['cases_received'],
        $_POST['examinations'],
        $_POST['date_received'],
        $_POST['date_completed'],
        $_POST['evidence_submitted'],

        $_POST['requesting_party'],
        $_POST['delivered_by'],
        $_POST['victims'],
        $_POST['suspects'],
        $_POST['examiner'],
        $_POST['occurrence_details'],
        $_POST['nature_of_case'],
        $_POST['type_of_examination'],
        $_POST['remarks'],
        $status,
        $unit
    );

    // Execute the statement
    if ($stmt->execute()) {
        echo "New record inserted successfully.";
        header("Location: ml_division.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}
?>
<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>
        <?php
        $sql = "SELECT * FROM ml where unit = '$unit'";
        $result = $conn->query($sql);
        ?>
        <main class="content bg-light">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Medico Legal Division</h1>

                <div class="row bg-white p-2 border">

                    <div class="mb-3 col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">

                            <div class="table-responsive">
                                <table id="ml_table" class="table table-bordered table-hover" style="width:100%">
                                    <thead class="border border-primary bg-info">
                                        <tr>
                                            <th class="text-white text-center">Actions</th>
                                            <th class="text-white text-center">Status</th>
                                            <th class="text-white text-center">Case Number</th>
                                            <th class="text-white text-center">No. of Cases Received</th>
                                            <th class="text-white text-center">No. of Examination</th>
                                            <th class="text-white text-center">Time and Date Received</th>
                                            <th class="text-white text-center">Time and Date Completed</th>
                                            <th class="text-white text-center">Recovered Evidence</th>
                                            <th class="text-white text-center">Evidence File</th>
                                            <th class="text-white text-center">Requesting Party</th>
                                            <th class="text-white text-center">Delivered by (station)</th>
                                            <th class="text-white text-center">Victim/s</th>
                                            <th class="text-white text-center">Suspect/s</th>
                                            <th class="text-white text-center">EXAMINER</th>
                                            <th class="text-white text-center">Time and Date & Place of Occurrence</th>
                                            <th class="text-white text-center">Nature of Case</th>
                                            <th class="text-white text-center">Type of Examination</th>
                                            <th class="text-white text-center">Remarks (In Custody, Court, Requesting Party)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($result->num_rows > 0) {
                                            // Start building the tbody structure


                                            // Loop through each row of the result set
                                            while ($row = $result->fetch_assoc()) {
                                                echo '<tr>';
                                                include 'globals/action_buttons.php';
                                                if ($row["status"] == "Pending") {
                                                    $el = "<span class='badge bg-warning  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Reviewed") {
                                                    $el = "<span class='badge bg-info  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "With Revisions") {
                                                    $el = "<span class='badge bg-danger  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Approved") {
                                                    $el = "<span class='badge bg-success  text-center text-white'>" . $row["status"] . "</span>";
                                                } else {
                                                    $el = "<span class='badge bg-secondary  text-center text-white'>" . "N/A" . "</span>";
                                                }
                                                echo "<td class='text-center'>" . $el . "</td>";
                                                echo '<td>' . $row['case_number'] . '</td>';
                                                echo '<td>' . $row['cases_received'] . '</td>';
                                                echo '<td>' . $row['examinations'] . '</td>';
                                                echo '<td>' . $row['date_received'] . '</td>';
                                                echo '<td>' . $row['date_completed'] . '</td>';
                                                echo '<td>' . $row['evidence_submitted'] . '</td>';
                                                echo '<td>' . $row['evidence_file'] . '</td>';
                                                echo '<td>' . $row['requesting_party'] . '</td>';
                                                echo '<td>' . $row['delivered_by'] . '</td>';
                                                echo '<td>' . $row['victims'] . '</td>';
                                                echo '<td>' . $row['suspects'] . '</td>';
                                                echo '<td>' . $row['examiner'] . '</td>';
                                                echo '<td>' . $row['occurrence_details'] . '</td>';
                                                echo '<td>' . $row['nature_of_case'] . '</td>';
                                                echo '<td>' . $row['type_of_examination'] . '</td>';
                                                echo '<td>' . $row['remarks'] . '</td>';
                                                echo '</tr>';
                                            }
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>





                </div>
            </div>




            <div class=" modal" tabindex="-1" id="add_ml_case" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-primary">
                            <h6 class="text-white">Medico Legal</h6>


                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="case_number" class="strong mb-1">Case Number</label>
                                            <input type="text" class="form-control" id="case_number" name="case_number">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="cases_received" class="strong mb-1">No.of Cases Received</label>
                                            <input type="number" min="0" max="1000" class="form-control" id="cases_received" name="cases_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="examinations" class="strong mb-1">No.of Examination</label>
                                            <input type="number" min="0" max="1000" class="form-control" id="examinations" name="examinations">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="date_received" class="strong mb-1">Time and Date Received</label>
                                            <input type="datetime-local" class="form-control" id="date_received" name="date_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="date_completed" class="strong mb-1">Time and Date Completed</label>
                                            <input type="datetime-local" class="form-control" id="date_completed" name="date_completed">
                                        </div>
                                    </div>

                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="evidence_submitted" class="strong mb-1">Recovered Evidence</label>
                                            <input type="text" class="form-control" id="evidence_submitted" name="evidence_submitted">
                                        </div>
                                    </div>


                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label for="requesting_party" class="strong mb-1">Requesting Party</label>
                                            <input type="text" class="form-control" id="requesting_party" name="requesting_party">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="delivered_by" class="strong mb-1">Delivered by (station)</label>
                                            <input type="text" class="form-control" id="delivered_by" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="victims" class="strong mb-1">Victim/s</label>
                                            <input type="text" class="form-control" id="victims" name="victims">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="suspects" class="strong mb-1">Suspect/s</label>
                                            <input type="text" class="form-control" id="suspects" name="suspects">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="examiner" class="strong mb-1">EXAMINER</label>
                                            <input type="text" class="form-control" id="examiner" name="examiner" required>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="occurrence_details" class="strong mb-1">Time and Date & Place of Occurrence</label>
                                            <input type="text" class="form-control" id="occurrence_details" name="occurrence_details">
                                        </div>
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group  bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" required name="nature_of_case" class="form-select">
                                                <option value="Found Dead Body">Found Dead Body</option>
                                                <option value="Shooting Incident">Shooting Incident</option>
                                                <option value="Robbery">Robbery</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="dissolve" placeholder="Enter other nature of case">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="type_of_examination" class="strong mb-1">Type of Examination</label>
                                            <select name="type_of_examination" class="form-select" id="type_of_examination">
                                                <option value="Autopsy">Autopsy</option>
                                                <option value="Sexual Abuse">Sexual Abuse</option>
                                                <option value="Physical Injury ">Physical Injury </option>
                                                <option value="Physical Examination ">Physical Examination </option>
                                                <option value="Hispathology">Hispathology</option>
                                                <option value="Blood/Semen">Blood/Semen</option>
                                                <option value="Ondotological">Ondotological</option>
                                                <option value="Post Mortem Examination">Post Mortem Examination</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="remarks" class="strong mb-1">Remarks (In Custody, Court, Requesting Party)</label>
                                            <select name="remarks" id="remarks" class="form-select">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                                <option value="Turned over to Requesting Party">Turned over to Requesting Party</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-end">
                                        <button class="btn btn-secondary" data-bs-dismiss='modal'>Close</button>
                                        <button type="submit" value="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>



            <div class=" modal" tabindex="-1" id="edit_case_modal" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-primary">
                            <h6 class="text-white">Medico Legal</h6>


                        </div>
                        <div class="modal-body">
                            <form action=""  id="edit_form">
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="case_number" class="strong mb-1">Case Number</label>
                                            <input type="text" class="form-control" id="case_number" name="case_number">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="cases_received" class="strong mb-1">No.of Cases Received</label>
                                            <input type="number" min="0" max="1000" class="form-control" id="cases_received" name="cases_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="examinations" class="strong mb-1">No.of Examination</label>
                                            <input type="number" min="0" max="1000" class="form-control" id="examinations" name="examinations">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="date_received" class="strong mb-1">Time and Date Received</label>
                                            <input type="datetime-local" class="form-control" id="date_received" name="date_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="date_completed" class="strong mb-1">Time and Date Completed</label>
                                            <input type="datetime-local" class="form-control" id="date_completed" name="date_completed">
                                        </div>
                                    </div>

                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="evidence_submitted" class="strong mb-1">Recovered Evidence</label>
                                            <input type="text" class="form-control" id="evidence_submitted" name="evidence_submitted">
                                        </div>
                                    </div>


                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label for="requesting_party" class="strong mb-1">Requesting Party</label>
                                            <input type="text" class="form-control" id="requesting_party" name="requesting_party">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="delivered_by" class="strong mb-1">Delivered by (station)</label>
                                            <input type="text" class="form-control" id="delivered_by" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="victims" class="strong mb-1">Victim/s</label>
                                            <input type="text" class="form-control" id="victims" name="victims">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="suspects" class="strong mb-1">Suspect/s</label>
                                            <input type="text" class="form-control" id="suspects" name="suspects">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="examiner" class="strong mb-1">EXAMINER</label>
                                            <input type="text" class="form-control" id="examiner" name="examiner" required>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="occurrence_details" class="strong mb-1">Time and Date & Place of Occurrence</label>
                                            <input type="text" class="form-control" id="occurrence_details" name="occurrence_details">
                                        </div>
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group  bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" required name="nature_of_case" class="form-select">
                                                <option value="Found Dead Body">Found Dead Body</option>
                                                <option value="Shooting Incident">Shooting Incident</option>
                                                <option value="Robbery">Robbery</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="dissolve" placeholder="Enter other nature of case">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="type_of_examination" class="strong mb-1">Type of Examination</label>
                                            <select name="type_of_examination" class="form-select" id="type_of_examination">
                                                <option value="Autopsy">Autopsy</option>
                                                <option value="Sexual Abuse">Sexual Abuse</option>
                                                <option value="Physical Injury ">Physical Injury </option>
                                                <option value="Physical Examination ">Physical Examination </option>
                                                <option value="Hispathology">Hispathology</option>
                                                <option value="Blood/Semen">Blood/Semen</option>
                                                <option value="Ondotological">Ondotological</option>
                                                <option value="Post Mortem Examination">Post Mortem Examination</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="remarks" class="strong mb-1">Remarks (In Custody, Court, Requesting Party)</label>
                                            <select name="remarks" id="remarks" class="form-select">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                                <option value="Turned over to Requesting Party">Turned over to Requesting Party</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-end">
                                        <button class="btn btn-secondary" data-bs-dismiss='modal'>Close</button>
                                        <button type="submit" value="submit" class="btn btn-primary" id="update_btn">Submit</button>
                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>

            <?php
            $div = "Medico Legal";
            include "globals/file_modal.php";
            ?>
        </main>


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#ml_table').DataTable({
        dom: 'fQrBtip',
                    responsive: true,
                    buttons: [
                         {
                text: 'Add Case', // Button text
                className: 'add_case', // Optional: Custom class for styling
                attr: {
                    'data-bs-toggle': 'modal', // Custom attribute and its value
                    'data-bs-target': '#add_ml_case', // Another example of a custom attribute
                    'title': 'Click to add case' // Tooltip title
                },

            },

                        {
                            extend: 'excel',
                            text: 'Excel',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'pdf',
                            text: 'PDF',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'print',
                            text: 'Print',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'colvis',
                            text: 'Show/Hide Columns',
                        }
                    ],
                    fixedHeader: true,
                    paging: true,
                    searching: true,
                    ordering: true,
                    scrollY: '300px',
                    colReorder: true,
                    scrollCollapse: true,
                    language: {
                        search: "Search:"

                    },
                });
</script>

<script>
    function updateExamType() {
        const checkboxes = document.querySelectorAll('input[name="exam_type[]"]');
        const checkedValues = [];
        checkboxes.forEach(checkbox => {
            console.log(checkbox.value)
            if (checkbox.checked) {
                checkedValues.push(checkbox.value);

            }
        });
        const valuesString = checkedValues.join(',');
        document.getElementById('evidence_submitted').value = valuesString;
        console.log(valuesString)
        console.log('Updated hidden input:', valuesString);
    }
</script>
<?php include "globals/dt_style.php"; ?>

<?php
include "globals/modal_scripts.php";
?>


<script>
    $(document).on('click', '#edit_case', function() {
        var case_id = $(this).attr('data-case_id');
        $('#update_btn').attr('data-case_id', case_id)

        // Fetch the data from the server
        fetch(`./edit_handlers/ml_division.php?case_id=${case_id}`)
            .then(response => response.json()) // Parse the JSON response
            .then(data => {
                console.log(data);
                $('#edit_form input[name="case_number"]').val(data[0].case_number);
                $('#edit_form input[name="cases_received"]').val(data[0].cases_received);
                $('#edit_form input[name="examinations"]').val(data[0].examinations);
                $('#edit_form input[name="date_received"]').val(data[0].date_received);
                $('#edit_form input[name="date_completed"]').val(data[0].date_completed);
                $('#edit_form input[name="evidence_submitted"]').val(data[0].evidence_submitted);
                $('#edit_form input[name="requesting_party"]').val(data[0].requesting_party);
                $('#edit_form input[name="delivered_by"]').val(data[0].delivered_by);
                $('#edit_form input[name="victims"]').val(data[0].victims);
                $('#edit_form input[name="suspects"]').val(data[0].suspects);
                $('#edit_form input[name="examiner"]').val(data[0].examiner);
                $('#edit_form input[name="occurrence_details"]').val(data[0].occurrence_details);
                $('#edit_form select[name="type_of_examination"]').val(data[0].type_of_examination);



                $("#edit_form select[name='nature_of_case']").append(`<option value='${data[0].nature_of_case}'>${data[0].nature_of_case}</option>`);
                $("#edit_form select[name='nature_of_case']").val(`${data[0].nature_of_case}`);







                // Set remarks select value
                $("#edit_form select[name='remarks']").val(data[0].remarks);

                // Handle remarks select field
                $("select[name='remarks']").val(data[0].remarks);

            })
            .catch(err => {
                console.error(err);
            });
    });
</script>


<script>
    $(document).on('click', '#update_btn', function(e) {
        e.preventDefault();

        var case_id = $(this).attr('data-case_id'); // Assuming you get the case_id from somewhere
        var formData = $("#edit_form").serialize();

        // Append case_id to formData
        formData += '&case_id=' + encodeURIComponent(case_id);
        console.log(formData)
        fetch(`./update_handlers/ml_division.php?${formData}`)
            .then(response => response.json())
            .then(data => {
                if (data.success == true) {
                    alert("Updated successfully");
                    window.location.reload()
                }
                // Handle success: maybe redirect or update UI
            })
            .catch((error) => {
                console.error('Error:', error);
            });


    })
</script>
<?php
include "../src/connection.php";
include "globals/head.php";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $case_number = $_POST['case_number'];
    $exam_count = $_POST['exam_count'];
    $date_received = $_POST['date_received'];
    $date_completed = $_POST['date_completed'];
    $evidence_submitted = $_POST['evidence_submitted'];
    $duty_receiving_officer = $_POST['duty_receiving_officer'];
    $result_of_examination = $_POST['result_of_examination'];
    $requesting_party = $_POST['requesting_party'];
    $delivered_by = $_POST['delivered_by'];
    $examiner = $_POST['examiner'];
    $nature_of_case = $_POST['nature_of_case'];
    $remarks = $_POST['remarks'];
    $exam_type = $_POST['exam_type'];
    $unit = $_SESSION['unit'];
    $status = "Pending";

    $sql = "INSERT INTO chemistry_three (
        case_number, 
        exam_count, 
        date_received, 
        date_completed, 
        evidence_submitted, 
        requesting_party, 
        delivered_by, 
        examiner, 
        nature_of_case, 
        remarks, 
        exam_type,
        duty_receiving_officer,
        result_of_examination,
        unit,
        status
    ) VALUES (
        '$case_number', 
        '$exam_count', 
        '$date_received', 
        '$date_completed', 
        '$evidence_submitted', 
        '$requesting_party', 
        '$delivered_by', 
        '$examiner', 
        '$nature_of_case', 
        '$remarks', 
        '$exam_type',
        '$duty_receiving_officer',
        '$result_of_examination',
        '$unit',
        '$status'
    )";

    if ($conn->query($sql) === TRUE) {
        header("Location: chemistry_drug_test_division.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

?>
<?php
include '../src/connection.php';
$unit = $_SESSION['unit'];
$query = "SELECT * FROM chemistry_three  where unit = '$unit'";
$result = $conn->query($query);
?>

<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>

        <main class="content bg-light">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Drug Test Case Chemistry Division</h1>

                <div class="row bg-white p-2">

                    <div class="mb-3 col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">
                            <div class="table-responsive p-3">
                                <table class="table w-100 table-bordered p-2 bg-white mx-auto" id="drug_test_table">
                                    <thead class="border border-primary bg-info">
                                        <tr>
                                            <th class="text-center text-white">Actions</th>
                                            <th class="text-center text-white">Status</th>
                                            <th class="text-center text-white">Case Number</th>
                                            <th class="text-center text-white">Exam Count</th>
                                            <th class="text-center text-white">Date Received</th>
                                            <th class="text-center text-white">Date Completed</th>
                                            <th class="text-center text-white">Evidence Submitted</th>
                                            <th class="text-center text-white">Requesting Party</th>
                                            <th class="text-center text-white">Delivered By</th>
                                            <th class="text-center text-white">Examiner</th>
                                            <th class="text-center text-white">Nature of Case</th>
                                            <th class="text-center text-white">Duty Receiving Officer</th>
                                            <th class="text-center text-white">Result of Examination</th>
                                            <th class="text-center text-white">Remarks</th>
                                            <th class="text-center text-white">Exam Type</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                include 'globals/action_buttons.php';

                                                //<h5 class="dropdown-item border p-2" data-bs-toggle="modal" data-bs-target="#files_modal" data-case_id="' . $row['id'] . '" id="view_files_btn">View Files</h5>
                                                if ($row["status"] == "Pending") {
                                                    $el = "<span class='badge bg-warning  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Reviewed") {
                                                    $el = "<span class='badge bg-info  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "With Revisions") {
                                                    $el = "<span class='badge bg-danger  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Approved") {
                                                    $el = "<span class='badge bg-success  text-center text-white'>" . $row["status"] . "</span>";
                                                } else {
                                                    $el = "<span class='badge bg-secondary  text-center text-white'>" . "N/A" . "</span>";
                                                }
                                                echo "<td class='text-center'>" . $el . "</td>";
                                                echo "<td>" . $row['case_number'] . "</td>";
                                                echo "<td>" . $row['exam_count'] . "</td>";
                                                echo "<td>" . $row['date_received'] . "</td>";
                                                echo "<td>" . $row['date_completed'] . "</td>";
                                                echo "<td>" . $row['evidence_submitted'] . "</td>";
                                                echo "<td>" . $row['requesting_party'] . "</td>";
                                                echo "<td>" . $row['delivered_by'] . "</td>";
                                                echo "<td>" . $row['examiner'] . "</td>";
                                                echo "<td>" . $row['nature_of_case'] . "</td>";
                                                echo "<td>" . $row['duty_receiving_officer'] . "</td>";
                                                echo "<td>" . $row['result_of_examination'] . "</td>";
                                                echo "<td>" . $row['remarks'] . "</td>";
                                                echo "<td>" . $row['exam_type'] . "</td>";
                                                echo "</tr>";
                                            }
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Modal for adding new case -->
            <div class="modal" tabindex="-1" id="add_chemistry_drug_test_case" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-info">
                            <h6 class="text-white">Chemistry Drug Test</h6>

                        </div>
                        <div class="modal-body">
                            <form method="post">
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="case_number">Case Number:</label>
                                            <input type="text" class="form-control" id="case_number" name="case_number" title="Format: DT-001-24-RFU2">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="exam_type">Type of Drug Test:</label>
                                            <select class="form-select" id="exam_type" name="exam_type">

                                                <option value="CRIMINAL DT">CRIMINAL DT</option>
                                                <option value="RANDOM DT">RANDOM DT</option>
                                                <option value="FADT DT (LTOPF)">FADT DT (LTOPF)</option>
                                                <option value="PNP DT (SCHOOLING, PROMOTION, REASSIGNMENT AND OTHERS)">PNP DT (SCHOOLING, PROMOTION, REASSIGNMENT AND OTHERS)</option>
                                                <option value="CIV DT">CIV DT</option>
                                                <option value="PLEA BARGAIN DT">PLEA BARGAIN DT</option>
                                                <option value="CI Watchlist">CI Watchlist</option>
                                                <option value="CI Watchlist">CI Watchlist</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="exam_count">No. of Examination:</label>
                                            <input type="number" class="form-control" id="exam_count" name="exam_count">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="date_received">Time and Date Received:</label>
                                            <input type="datetime-local" class="form-control" id="date_received" name="date_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="date_completed">Time and Date Completed:</label>
                                            <input type="datetime-local" class="form-control" id="date_completed" name="date_completed">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label for="evidence_submitted">Evidence Submitted/Collected:</label>
                                            <textarea class="form-control" id="evidence_submitted" name="evidence_submitted"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="examiner">Examiner:</label>
                                            <input type="text" class="form-control" id="examiner" name="examiner">
                                        </div>
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group  bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" name="nature_of_case" class="form-select">
                                                <option value="Alleged Violation of RA 9165">Alleged Violation of RA 9165</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="dissolve" placeholder="Enter other nature of case">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="requesting_party">Requesting Party:</label>
                                            <input type="text" class="form-control" id="requesting_party" name="requesting_party">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="delivered_by">Delivered By:</label>
                                            <input type="text" class="form-control" id="delivered_by" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="duty_receiving_officer">Duty Receiving Officer:</label>
                                            <input type="text" class="form-control" id="duty_receiving_officer" name="duty_receiving_officer">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="result_of_examination">Result of Examination:</label>
                                            <input type="text" class="form-control" id="result_of_examination" name="result_of_examination">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label for="remarks">Remarks:</label>
                                            <textarea class="form-control" id="remarks" name="remarks"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-end">
                                        <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


            <div class="modal" tabindex="-1" id="edit_case_modal" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-info">
                            <h6 class="text-white">Chemistry Drug Test</h6>

                        </div>
                        <div class="modal-body">
                            <form method="post" id="edit_form">
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="case_number">Case Number:</label>
                                            <input type="text" class="form-control" id="case_number" name="case_number" title="Format: DT-001-24-RFU2">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="exam_type">Type of Drug Test:</label>
                                            <select class="form-select" id="exam_type" name="exam_type">

                                                <option value="CRIMINAL DT">CRIMINAL DT</option>
                                                <option value="RANDOM DT">RANDOM DT</option>
                                                <option value="FADT DT (LTOPF)">FADT DT (LTOPF)</option>
                                                <option value="PNP DT (SCHOOLING, PROMOTION, REASSIGNMENT AND OTHERS)">PNP DT (SCHOOLING, PROMOTION, REASSIGNMENT AND OTHERS)</option>
                                                <option value="CIV DT">CIV DT</option>
                                                <option value="PLEA BARGAIN DT">PLEA BARGAIN DT</option>
                                                <option value="CI Watchlist">CI Watchlist</option>
                                                <option value="Others">Others</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="exam_count">No. of Examination:</label>
                                            <input type="number" class="form-control" id="exam_count" name="exam_count">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="date_received">Time and Date Received:</label>
                                            <input type="datetime-local" class="form-control" id="date_received" name="date_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="date_completed">Time and Date Completed:</label>
                                            <input type="datetime-local" class="form-control" id="date_completed" name="date_completed">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label for="evidence_submitted">Evidence Submitted/Collected:</label>
                                            <textarea class="form-control" id="evidence_submitted" name="evidence_submitted"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="examiner">Examiner:</label>
                                            <input type="text" class="form-control" id="examiner" name="examiner">
                                        </div>
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group  bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" name="nature_of_case" class="form-select">
                                                <option value="Alleged Violation of RA 9165">Alleged Violation of RA 9165</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="dissolve" placeholder="Enter other nature of case">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="requesting_party">Requesting Party:</label>
                                            <input type="text" class="form-control" id="requesting_party" name="requesting_party">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="delivered_by">Delivered By:</label>
                                            <input type="text" class="form-control" id="delivered_by" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="duty_receiving_officer">Duty Receiving Officer:</label>
                                            <input type="text" class="form-control" id="duty_receiving_officer" name="duty_receiving_officer">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="result_of_examination">Result of Examination:</label>
                                            <input type="text" class="form-control" id="result_of_examination" name="result_of_examination">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label for="remarks">Remarks:</label>
                                            <textarea class="form-control" id="remarks" name="remarks"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-end">
                                        <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary" id="update_btn">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <?php
            $div = "Drug Test";
            include "globals/file_modal.php";
            ?>

        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        $('#drug_test_table').DataTable({
            dom: 'fQrBtip',
                    responsive: true,
                    buttons: [
                         {
                text: 'Add Case', // Button text
                className: 'add_case', // Optional: Custom class for styling
                attr: {
                    'class': 'bg-primary',
                    'style': 'border: none; color: white',
                    'data-bs-toggle': 'modal', // Custom attribute and its value
                    'data-bs-target': '#add_chemistry_drug_test_case', // Another example of a custom attribute
                    'title': 'Click to add case' // Tooltip title
                },

            },

                        {
                            extend: 'excel',
                            text: 'Excel',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'pdf',
                            text: 'PDF',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'print',
                            text: 'Print',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'colvis',
                            text: 'Show/Hide Columns',
                        }
                    ],
                    fixedHeader: true,
                    paging: true,
                    searching: true,
                    ordering: true,
                    scrollY: '300px',
                    colReorder: true,
                    scrollCollapse: true,
                    language: {
                        search: "Search:"

                    },
                });
    });
</script>

<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $(document).on("input", "#other_drug", function() {
        $("#other_input").removeClass('d-none');
        var drug_name = $("#other_drug").val()
        if (drug_name == "") {
            $("#other_input").addClass('d-none')
        } else {
            $('#other_input #text_label').text(`Weight in grams of ${drug_name}`)
        }
    });
</script>
<?php include "globals/dt_style.php"; ?>
<?php
include "globals/modal_scripts.php";
?>



<script>
    $(document).on('click', '#edit_case', function() {
        var case_id = $(this).attr('data-case_id');
        $('#update_btn').attr('data-case_id', case_id)

        // Fetch the data from the server
        fetch(`./edit_handlers/chemistry_drug_test_division.php?case_id=${case_id}`)
            .then(response => response.json()) // Parse the JSON response
            .then(data => {
                console.log(data);


                // Assuming 'data' contains the JSON response from your fetch call
                $('#edit_form input[name="case_number"]').val(data[0].case_number);
                $('#edit_form input[name="exam_count"]').val(data[0].exam_count);
                $('#edit_form input[name="date_received"]').val(data[0].date_received);
                $('#edit_form input[name="date_completed"]').val(data[0].date_completed);
                $('#edit_form textarea[name="evidence_submitted"]').val(data[0].evidence_submitted);

                $('#edit_form input[name="requesting_party"]').val(data[0].requesting_party);
                $('#edit_form input[name="delivered_by"]').val(data[0].delivered_by);
                $('#edit_form input[name="examiner"]').val(data[0].examiner);
                $('#edit_form textarea[name="remarks"]').val(data[0].remarks);
                $('#edit_form input[name="exam_type"]').val(data[0].exam_type);
                $('#edit_form input[name="duty_receiving_officer"]').val(data[0].duty_receiving_officer);
                $('#edit_form input[name="result_of_examination"]').val(data[0].result_of_examination);


                $("#edit_form select[name='nature_of_case']").append(`<option value='${data[0].nature_of_case}'>${data[0].nature_of_case}</option>`);
                $("#edit_form select[name='nature_of_case']").val(`${data[0].nature_of_case}`);








            })
            .catch(err => {
                console.error(err);
            });
    });
</script>




<script>
    $(document).on('click', '#update_btn', function(e) {
        e.preventDefault();

        var case_id = $(this).attr('data-case_id'); // Assuming you get the case_id from somewhere
        var formData = $("#edit_form").serialize();

        // Append case_id to formData
        formData += '&case_id=' + encodeURIComponent(case_id);
        console.log(formData)
        fetch(`./update_handlers/chemistry_drug_test_division.php?${formData}`)
            .then(response => response.json())
            .then(data => {
                if (data.success == true) {
                    alert("Updated successfully");
                    window.location.reload()
                }
                // Handle success: maybe redirect or update UI
            })
            .catch((error) => {
                console.error('Error:', error);
            });


    })
</script>
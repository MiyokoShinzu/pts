<?php
include "../src/connection.php";
include "globals/head.php";
?>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $case_number = $_POST['case_number'];
    $cases_received = $_POST['cases_received'];
    $examinations = $_POST['examinations'];
    $time_date_received = $_POST['time_date_received'];
    $time_date_completed = $_POST['time_date_completed'];
    $specimen_submitted = $_POST['specimen_submitted'];
    $requesting_party = $_POST['requesting_party'];
    $delivered_by = $_POST['delivered_by'];
    $victims = $_POST['victims'];
    $suspects = $_POST['suspects'];
    $examiner = $_POST['examiner'];
    $time_date_place = $_POST['time_date_place'];
    $nature_of_case = $_POST['nature_of_case'];
    $remarks = $_POST['remarks'];
    $unit = $_SESSION['unit'];
    $status = "Pending";
    $file_path = "N/A";
    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO dna (case_number, cases_received, examinations, time_date_received, time_date_completed, specimen_submitted, file_path, requesting_party, delivered_by, victims, suspects, examiner, time_date_place, nature_of_case, remarks, status, unit) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("siissssssssssssss", $case_number, $cases_received, $examinations, $time_date_received, $time_date_completed, $specimen_submitted, $file_path, $requesting_party, $delivered_by, $victims, $suspects, $examiner, $time_date_place, $nature_of_case, $remarks, $status, $unit);

    // Execute the statement
    if ($stmt->execute()) {
        echo "New case added successfully.";
        header("Location: dna_division.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
}
?>
<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>
        <?php
        $sql = "SELECT * FROM dna where unit = '$unit'";
        $result = $conn->query($sql);
        ?>
        <main class="content bg-white">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">DNA Division</h1>

                <div class="row bg-white p-2 border">

                    <div class="col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">

                            <div class="table-responsive p-3">
                                <table id="drug_case_table" class="table w-100 table-bordered p-2 bg-white mx-auto">
                                    <thead class="border border-primary bg-info">
                                        <tr>
                                            <th class="text-white text-center">Actions</th>
                                            <th class="text-white text-center">Status</th>
                                            <th class="text-white text-center">Case Number</th>
                                            <th class="text-white text-center">No. of Cases Received</th>
                                            <th class="text-white text-center">No. of Examinations</th>
                                            <th class="text-white text-center">Time and Date Received</th>
                                            <th class="text-white text-center">Time and Date Completed</th>
                                            <th class="text-white text-center">Specimen Submitted</th>
                                            <th class="text-white text-center">Requesting Party</th>
                                            <th class="text-white text-center">Delivered by (station)</th>
                                            <th class="text-white text-center">Victim/s</th>
                                            <th class="text-white text-center">Suspect/s</th>
                                            <th class="text-white text-center">Examiner</th>
                                            <th class="text-white text-center">Time and Date & Place of Occurrence</th>
                                            <th class="text-white text-center">Nature of Case</th>
                                            <th class="text-white text-center">Remarks</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($result->num_rows > 0) {
                                            // Output data of each row
                                            while ($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                include 'globals/action_buttons.php';

                                                if ($row["status"] == "Pending") {
                                                    $el = "<span class='badge bg-warning  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Reviewed") {
                                                    $el = "<span class='badge bg-info  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "With Revisions") {
                                                    $el = "<span class='badge bg-danger  text-center text-white'>" . $row["status"] . "</span>";
                                                } else if ($row["status"] == "Approved") {
                                                    $el = "<span class='badge bg-success  text-center text-white'>" . $row["status"] . "</span>";
                                                } else {
                                                    $el = "<span class='badge bg-secondary  text-center text-white'>" . "N/A" . "</span>";
                                                }
                                                echo "<td class='text-center'>" . $el . "</td>";
                                                echo "<td>" . htmlspecialchars($row["case_number"]) . "</td>";

                                                echo "<td>" . htmlspecialchars($row["cases_received"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["examinations"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["time_date_received"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["time_date_completed"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["specimen_submitted"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["requesting_party"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["delivered_by"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["victims"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["suspects"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["examiner"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["time_date_place"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["nature_of_case"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["remarks"]) . "</td>";
                                                echo "</tr>";
                                            }
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>




                </div>
            </div>




            <div class="modal" tabindex="-1" id="add_dna_case" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-info">
                            <h6 class="text-white">DNA</h6>

                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="caseNumber" class="mb-1 strong">Case Number</label>
                                            <input type="text" name="case_number" id="caseNumber" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="casesReceived" class="mb-1 strong">No. of Cases Received</label>
                                            <input type="number" name="cases_received" id="casesReceived" min="0" max="1000" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="examinations" class="mb-1 strong">No. of Examinations</label>
                                            <input type="number" name="examinations" id="examinations" min="0" max="1000" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="timeDateReceived" class="mb-1 strong">Time and Date Received</label>
                                            <input type="datetime-local" name="time_date_received" id="timeDateReceived" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="timeDateCompleted" class="mb-1 strong">Time and Date Completed</label>
                                            <input type="datetime-local" name="time_date_completed" id="timeDateCompleted" class="form-control">
                                        </div>
                                    </div>


                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label for="requestingParty" class="mb-1 strong">Requesting Party</label>
                                            <input type="text" name="requesting_party" id="requestingParty" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="deliveredBy" class="mb-1 strong">Delivered by (station)</label>
                                            <input type="text" name="delivered_by" id="deliveredBy" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="victims" class="mb-1 strong">Victim/s</label>
                                            <input type="text" name="victims" id="victims" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group">
                                            <label for="suspects" class="mb-1 strong">Suspect/s</label>
                                            <input type="text" name="suspects" id="suspects" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group">
                                            <label for="examiner" class="mb-1 strong">EXAMINER</label>
                                            <input type="text" name="examiner" id="examiner" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group">
                                            <label for="timeDatePlace" class="mb-1 strong">Time and Date & Place of Occurrence</label>
                                            <input type="text" name="time_date_place" id="timeDatePlace" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group  bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" required name="nature_of_case" class="form-select">
                                                <option value="Found Dead Body">Found Dead Body</option>
                                                <option value="Shooting Incident">Shooting Incident</option>
                                                <option value="Robbery">Robbery</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="dissolve" placeholder="Enter other nature of case">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group">
                                            <label for="remarks" class="mb-1 strong">Remarks</label>
                                            <select name="remarks" id="remarks" class="form-control">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                                <option value="Turned Over To PDEA">Turned over to Requesting Party</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="specimenSubmitted" class="mb-1 strong">Specimen Submitted</label>
                                            <textarea name="specimen_submitted" id="specimenSubmitted" class="form-control w-100" rows="1"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-end">
                                        <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" value="submit" class="btn btn-sm btn-info ">Submit</button>
                                        <!-- PDF file only -->
                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>



            <div class="modal" tabindex="-1" id="edit_case_modal" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-info">
                            <h6 class="text-white">DNA</h6>

                        </div>
                        <div class="modal-body">
                            <form action="" method="post" id="edit_form">
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="caseNumber" class="mb-1 strong">Case Number</label>
                                            <input type="text" name="case_number" id="caseNumber" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="casesReceived" class="mb-1 strong">No. of Cases Received</label>
                                            <input type="number" name="cases_received" id="casesReceived" min="0" max="1000" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="examinations" class="mb-1 strong">No. of Examinations</label>
                                            <input type="number" name="examinations" id="examinations" min="0" max="1000" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="timeDateReceived" class="mb-1 strong">Time and Date Received</label>
                                            <input type="datetime-local" name="time_date_received" id="timeDateReceived" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="timeDateCompleted" class="mb-1 strong">Time and Date Completed</label>
                                            <input type="datetime-local" name="time_date_completed" id="timeDateCompleted" class="form-control">
                                        </div>
                                    </div>


                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label for="requestingParty" class="mb-1 strong">Requesting Party</label>
                                            <input type="text" name="requesting_party" id="requestingParty" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="deliveredBy" class="mb-1 strong">Delivered by (station)</label>
                                            <input type="text" name="delivered_by" id="deliveredBy" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="victims" class="mb-1 strong">Victim/s</label>
                                            <input type="text" name="victims" id="victims" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group">
                                            <label for="suspects" class="mb-1 strong">Suspect/s</label>
                                            <input type="text" name="suspects" id="suspects" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group">
                                            <label for="examiner" class="mb-1 strong">EXAMINER</label>
                                            <input type="text" name="examiner" id="examiner" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group">
                                            <label for="timeDatePlace" class="mb-1 strong">Time and Date & Place of Occurrence</label>
                                            <input type="text" name="time_date_place" id="timeDatePlace" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group  bg-white" style="border-radius: 5px;">
                                            <label for="text-black nature_of_case" class="strong mb-1" style="font-weight: bold;">Nature of Case</label>
                                            <select id="nature_of_case" required name="nature_of_case" class="form-select">
                                                <option value="Found Dead Body">Found Dead Body</option>
                                                <option value="Shooting Incident">Shooting Incident</option>
                                                <option value="Robbery">Robbery</option>
                                                <option value="Others" id="other_option">Others, please specify:</option>
                                            </select>
                                            <div id="other_nature_case" class="mt-2" style="display: none;">
                                                <input type="text" class="form-control form-control-sm" id="other_nature_case_input" name="dissolve" placeholder="Enter other nature of case">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group">
                                            <label for="remarks" class="mb-1 strong">Remarks</label>
                                            <select name="remarks" id="remarks" class="form-control">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                                <option value="Turned Over To PDEA">Turned over to Requesting Party</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="specimenSubmitted" class="mb-1 strong">Specimen Submitted</label>
                                            <textarea name="specimen_submitted" id="specimenSubmitted" class="form-control w-100" rows="1"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-end">
                                        <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" value="submit" class="btn btn-sm btn-info " id="update_btn">Submit</button>
                                        <!-- PDF file only -->
                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>



            <?php
            $div = "DNA";
            include "globals/file_modal.php";
            ?>

        </main>


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#drug_case_table').DataTable({
       dom: 'fQrBtip',
                    responsive: true,
                    buttons: [
                         {
                text: 'Add Case', // Button text
                className: 'add_case', // Optional: Custom class for styling
                attr: {
                    'data-bs-toggle': 'modal', // Custom attribute and its value
                    'data-bs-target': '#add_dna_case', // Another example of a custom attribute
                    'title': 'Click to add case' // Tooltip title
                },

            },

                        {
                            extend: 'excel',
                            text: 'Excel',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'pdf',
                            text: 'PDF',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'print',
                            text: 'Print',
                            exportOptions: {
                                columns: ':visible'
                            }
                        },
                        {
                            extend: 'colvis',
                            text: 'Show/Hide Columns',
                        }
                    ],
                    fixedHeader: true,
                    paging: true,
                    searching: true,
                    ordering: true,
                    scrollY: '300px',
                    colReorder: true,
                    scrollCollapse: true,
                    language: {
                        search: "Search:"

                    },

    })
</script>
<script>
    $(document).on("input", "#other_drug", function() {
        $("#other_input").removeClass('d-none');
        var drug_name = $("#other_drug").val()
        if (drug_name == "") {
            $("#other_input").addClass('d-none')
        } else {
            $('#other_input #text_label').text(`Weight in grams of ${drug_name}`)
        }
    })
</script>
<?php include "globals/dt_style.php"; ?>






<?php
include "globals/modal_scripts.php";
?>

<script>
    $(document).on('click', '#edit_case', function() {
        var case_id = $(this).attr('data-case_id');
        $('#update_btn').attr('data-case_id', case_id)

        // Fetch the data from the server
        fetch(`./edit_handlers/dna_division.php?case_id=${case_id}`)
            .then(response => response.json()) // Parse the JSON response
            .then(data => {
                console.log(data);


                $('#edit_form input[name="case_number"]').val(data[0].case_number);
                $('#edit_form input[name="cases_received"]').val(data[0].cases_received);
                $('#edit_form input[name="delivered_by"]').val(data[0].delivered_by);
                $('#edit_form input[name="examinations"]').val(data[0].examinations);
                $('#edit_form input[name="examiner"]').val(data[0].examiner);



                $('#edit_form input[name="requesting_party"]').val(data[0].requesting_party);
                $('#edit_form textarea[name="specimen_submitted"]').val(data[0].specimen_submitted);
                $('#edit_form input[name="suspects"]').val(data[0].suspects);
                $('#edit_form input[name="time_date_completed"]').val(data[0].time_date_completed);
                $('#edit_form input[name="time_date_place"]').val(data[0].time_date_place);
                $('#edit_form input[name="time_date_received"]').val(data[0].time_date_received);
                $('#edit_form input[name="victims"]').val(data[0].victims);


                $("#edit_form select[name='nature_of_case']").append(`<option value='${data[0].nature_of_case}'>${data[0].nature_of_case}</option>`);
                $("#edit_form select[name='nature_of_case']").val(`${data[0].nature_of_case}`);







                // Set remarks select value
                $("#edit_form select[name='remarks']").val(data[0].remarks);

                // Handle remarks select field
                $("select[name='remarks']").val(data[0].remarks);

            })
            .catch(err => {
                console.error(err);
            });
    });
</script>


<script>
    $(document).on('click', '#update_btn', function(e) {
        e.preventDefault();

        var case_id = $(this).attr('data-case_id'); // Assuming you get the case_id from somewhere
        var formData = $("#edit_form").serialize();

        // Append case_id to formData
        formData += '&case_id=' + encodeURIComponent(case_id);
        console.log(formData)
        fetch(`./update_handlers/dna_division.php?${formData}`)
            .then(response => response.json())
            .then(data => {
                if (data.success == true) {
                    alert("Updated successfully");
                    window.location.reload()
                }
                // Handle success: maybe redirect or update UI
            })
            .catch((error) => {
                console.error('Error:', error);
            });


    })
</script>
<?php
include "../src/connection.php";
include "globals/head.php";

?>

<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $case_number = $_POST['case_number'];
    $cases_received = $_POST['cases_received'];
    $examinations = $_POST['examinations'];
    $date_received = $_POST['date_received'];
    $date_completed = $_POST['date_completed'];
    $submission_date = $_POST['submission_date'];
    $meth = $_POST['meth'];
    $mj = $_POST['mj'];
    $other_drug = $_POST['other_drug'];
    $other_specify = $_POST['other_specify'];
    $paraphernalia = $_POST['paraphernalia'];
    $requesting_party = $_POST['requesting_party'];
    $delivered_by = $_POST['delivered_by'];
    $suspects = $_POST['suspects'];
    $examiner = $_POST['examiner'];
    $date_to_custodian = $_POST['date_to_custodian'];
    $custodian_name = $_POST['custodian_name'];
    $receiving_pnco = $_POST['receiving_pnco'];
    $operation_type = $_POST['operation_type'];
    $investigator = $_POST['investigator'];
    $remarks = $_POST['remarks'];
    $result = $_POST['result'];
    $court_branch = $_POST['court_branch'];
    $status = "Pending";
    $unit = $_SESSION['unit'];
    $sql = "INSERT INTO chemistry_two (case_number, cases_received, examinations, date_received, date_completed, submission_date, meth, mj, other_drug, other_specify, paraphernalia, requesting_party, delivered_by, suspects, examiner, date_to_custodian, custodian_name, receiving_pnco, operation_type, investigator, remarks, result, court_branch, status, unit) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("siissssssssssssssssssssss", $case_number, $cases_received, $examinations, $date_received, $date_completed, $submission_date, $meth, $mj, $other_drug, $other_specify, $paraphernalia, $requesting_party, $delivered_by, $suspects, $examiner, $date_to_custodian, $custodian_name, $receiving_pnco, $operation_type, $investigator, $remarks, $result, $court_branch, $status, $unit);

    if ($stmt->execute()) {
        header("Location: chemistry_drug_division.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $stmt->close();
    $conn->close();

}
?>
<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>
        <?php
        $sql = "SELECT * FROM chemistry_two  where status='Approved'";
        $result = $conn->query($sql);
        ?>
        <main class="content bg-white">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3"><strong>Drug Case Chemistry</strong> Division</h1>

                <div class="row bg-white p-2 border">
                    <div class="col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">
                            <div class="table-responsive">
                                <table id="drug_case_table" class="table table-bordered table-hover" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>Case Number</th>
                                            <th>Unit</th>
                                            <th>No. of Cases Received</th>
                                            <th>No. of Examination</th>
                                            <th>Date Received</th>
                                            <th>Date Completed</th>
                                            <th>Submission Date</th>
                                            <th>Meth</th>
                                            <th>MJ</th>
                                            <th>Other Drug</th>
                                            <th>Other Specify</th>
                                            <th>Paraphernalia</th>
                                            <th>Requesting Party</th>
                                            <th>Delivered By</th>
                                            <th>Suspects</th>
                                            <th>Examiner</th>
                                            <th>Date to Custodian</th>
                                            <th>Custodian Name</th>
                                            <th>Receiving PNCO</th>
                                            <th>Operation Type</th>
                                            <th>Investigator</th>
                                            <th>Remarks</th>
                                            <th>Result</th>
                                            <th>Court Branch</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["case_number"] . "</td>";
                                                echo "<td>" . $row["unit"] . "</td>";
                                                
                                                echo "<td>" . $row["cases_received"] . "</td>";
                                                echo "<td>" . $row["examinations"] . "</td>";
                                                echo "<td>" . $row["date_received"] . "</td>";
                                                echo "<td>" . $row["date_completed"] . "</td>";
                                               
                                                echo "<td>" . $row["submission_date"] . "</td>";
                                                echo "<td>" . $row["meth"] . "</td>";
                                                echo "<td>" . $row["mj"] . "</td>";
                                                echo "<td>" . $row["other_drug"] . "</td>";
                                                echo "<td>" . $row["other_specify"] . "</td>";
                                                echo "<td>" . $row["paraphernalia"] . "</td>";
                                                echo "<td>" . $row["requesting_party"] . "</td>";
                                                echo "<td>" . $row["delivered_by"] . "</td>";
                                                echo "<td>" . $row["suspects"] . "</td>";
                                                echo "<td>" . $row["examiner"] . "</td>";
                                                echo "<td>" . $row["date_to_custodian"] . "</td>";
                                                echo "<td>" . $row["custodian_name"] . "</td>";
                                                echo "<td>" . $row["receiving_pnco"] . "</td>";
                                                echo "<td>" . $row["operation_type"] . "</td>";
                                                echo "<td>" . $row["investigator"] . "</td>";
                                                echo "<td>" . $row["remarks"] . "</td>";
                                                echo "<td>" . $row["result"] . "</td>";
                                                echo "<td>" . $row["court_branch"] . "</td>";
                                                echo "</tr>";
                                            }
                                        } 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>



                    <div class="col-lg-10 mx-auto bg-white">
                        <div class="table-responsive">

                        </div>
                    </div>

                </div>
            </div>


            <div class="modal" tabindex="-1" id="add_drug_case_chemistry" tabindex="-1" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-xl" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Add New Drug Case</h5>
                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-group mb-3">
                                            <label for="case_number" class="strong">Case Number</label>
                                            <input type="text" name="case_number" class="form-control" placeholder="D-001-24-RFU2">
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group mb-3">
                                            <label for="cases_received" class="strong">No. of Cases Received</label>
                                            <input type="number" name="cases_received" min=0 max=1000 class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group mb-3">
                                            <label for="examinations" class="strong">No. of Examination</label>
                                            <input type="number" name="examinations" min=0 max=1000 class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group mb-3">
                                            <label for="date_received" class="strong">Time and Date Received</label>
                                            <input type="datetime-local" name="date_received" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group mb-3">
                                            <label for="date_completed" class="strong">Time and Date Completed</label>
                                            <input type="datetime-local" name="date_completed" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="submission_date" class="strong">Date of Submission</label>
                                            <input type="datetime-local" name="submission_date" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group mb-3">
                                            <label for="meth" class="strong">Meth</label>
                                            <input type="text" name="meth" class="form-control" placeholder="Weight in grams">
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group mb-3">
                                            <label for="mj" class="strong">MJ</label>
                                            <input type="text" name="mj" class="form-control" placeholder="Weight in grams">
                                        </div>
                                    </div>

                                    <div class="col-lg-4">
                                        <div class="form-group mb-3">
                                            <label for="other_drug" class="strong">Others</label>
                                            <input type="text" name="other_drug" placeholder="Please Specify" id="other_drug" class="form-control">
                                        </div>
                                    </div>
                                    <div id="other_input" class="col-lg-2 d-none">
                                        <div class="form-group mb-3">
                                            <label for="other_specify" class="strong" style="font-weight: bolder" id="text_label"></label>
                                            <input type="text" name="other_specify" placeholder="" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-lg-2">
                                        <div class="form-group mb-3">
                                            <label for="paraphernalia" class="strong">No. of paraphernalia</label>
                                            <input type="number" name="paraphernalia" min=0 max=1000 class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group mb-3">
                                            <label for="requesting_party" class="strong">Requesting Party</label>
                                            <input type="text" name="requesting_party" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group mb-3">
                                            <label for="delivered_by" class="strong">Delivered by (station)</label>
                                            <input type="text" name="delivered_by" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group mb-3">
                                            <label for="suspects" class="strong">Suspect/s</label>
                                            <input type="text" name="suspects" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group mb-3">
                                            <label for="examiner" class="strong">EXAMINER</label>
                                            <input type="text" name="examiner" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group mb-3">
                                            <label for="date_to_custodian" class="strong">Time and Date t/o to Evidence Custodian</label>
                                            <input type="datetime-local" name="date_to_custodian" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group mb-3">
                                            <label for="custodian_name" class="strong">Name of Custodian</label>
                                            <input type="text" name="custodian_name" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group mb-3">
                                            <label for="receiving_pnco" class="strong">Duty Receiving PNCO(If applicable)</label>
                                            <input type="text" name="receiving_pnco" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group mb-3">
                                            <label for="operation_type" class="strong">Type of Operation</label>
                                            <select name="operation_type" class="form-select" id="operation_type">
                                                <option value="BUY BUST">BUY BUST</option>
                                                <option value="TEST BUY">TEST BUY</option>
                                                <option value="RECOVERED">RECOVERED</option>
                                                <option value="SURRENDERED">SURRENDERED</option>
                                                <option value="OTHERS">OTHERS</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="investigator" class="strong">Investigator on Case</label>
                                            <input type="text" name="investigator" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="remarks" class="strong">Remarks(In Custody, Court, PDEA)</label>
                                            <select name="remarks" id="remarks" class="form-select">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                                <option value="Turnovered To PDEA">Turnovered to PDEA</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="result" class="strong">Result</label>
                                            <select name="result" id="result" class="form-select">
                                                <option value="Meth Positive">Meth Positive</option>
                                                <option value="MJ Positive">MJ Positive</option>
                                                <option value="Negative">Negative</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group mb-3">
                                            <label for="court_branch" class="strong">Branch of Court(Br 33, Ballesteros, etc)</label>
                                            <input type="text" name="court_branch" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-lg-12 text-end">
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary" value="submit">Submit</button>
                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>
        </main>


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#drug_case_table').DataTable({
        responsive: true,
        dom: "BfrQltip"
    })
</script>
<script>
    $(document).on("input", "#other_drug", function() {
        $("#other_input").removeClass('d-none');
        var drug_name = $("#other_drug").val()
        if (drug_name == "") {
            $("#other_input").addClass('d-none')
        } else {
            $('#other_input #text_label').text(`Weight in grams of ${drug_name}`)
        }
    })
</script>
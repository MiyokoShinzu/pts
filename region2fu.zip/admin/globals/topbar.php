<nav class="navbar navbar-expand navbar-light navbar-bg ">
    <a class="sidebar-toggle js-sidebar-toggle  text-center">
        <i class="hamburger hamburger-black align-self-center" ></i>

    </a>
    <div class="container h-100 d-flex align-items-center justify-content-center flex-column">

        <h1 class="mt-2 " style="font-weight: bolder">Philippine National Police Regional Forensic Unit 2</h1>
    </div>

</nav>
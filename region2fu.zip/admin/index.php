  <?php
    include "../src/connection.php";
    $query = "SELECT COUNT(id) as total_users FROM users";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $totalUsers = $row['total_users'];
    $query = "SELECT COUNT(id) as total_users FROM users where level = 1";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $totalUsers_admin = $row['total_users'];
    $query = "SELECT COUNT(id) as total_users FROM users where level = 3";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $totalUsers_encoder = $row['total_users'];
    $query = "SELECT COUNT(id) as total_users FROM users where level = 2";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $totalUsers_validator = $row['total_users'];
    include "globals/head.php";
    ?>

  <body>
      <div class="wrapper">
          <?php
            include "globals/sidebar.php";
            ?>

          <div class="main">
              <?php include "globals/topbar.php"; ?>

              <main class="content">
                  <div class="container-fluid p-0">

                      <h1 class="h3 mb-3"><strong>Dashboard</strong> </h1>

                      <div class="row">
                          <div class="col-xl-6 col-xxl-5 d-flex">
                              <div class="w-100">
                                  <div class="row">
                                      <div class="col-sm-6">
                                          <div class="card">
                                              <div class="card-body">
                                                  <div class="row">
                                                      <div class="col mt-0" id="accounts">
                                                          <h5 class="card-title">Total Accounts</h5>
                                                      </div>

                                                      <div class="col-auto">
                                                          <div class="stat text-primary">
                                                              <i class="align-middle" data-feather="users"></i>
                                                          </div>
                                                      </div>
                                                  </div>
                                                  <h1 class="mt-1 mb-3"><?php echo $totalUsers; ?></h1>

                                              </div>
                                          </div>
                                          <div class="card">
                                              <div class="card-body">
                                                  <div class="row">
                                                      <div class="col mt-0">
                                                          <h5 class="card-title">Encoder Accounts</h5>
                                                      </div>

                                                      <div class="col-auto">
                                                          <div class="stat text-primary">
                                                              <i class="align-middle" data-feather="user-plus"></i>
                                                          </div>
                                                      </div>
                                                  </div>
                                                  <h1 class="mt-1 mb-3"><?php echo $totalUsers_encoder; ?></h1>

                                              </div>
                                          </div>
                                      </div>
                                      <div class="col-sm-6">
                                          <div class="card">
                                              <div class="card-body">
                                                  <div class="row">
                                                      <div class="col mt-0">
                                                          <h5 class="card-title">Admin Accounts</h5>
                                                      </div>

                                                      <div class="col-auto">
                                                          <div class="stat text-primary">
                                                              <i class="align-middle" data-feather="command"></i>
                                                          </div>
                                                      </div>
                                                  </div>
                                                  <h1 class="mt-1 mb-3"><?php echo $totalUsers_admin; ?></h1>

                                              </div>
                                          </div>
                                          <div class="card">
                                              <div class="card-body">
                                                  <div class="row">
                                                      <div class="col mt-0">
                                                          <h5 class="card-title">Validator Accounts</h5>
                                                      </div>

                                                      <div class="col-auto">
                                                          <div class="stat text-primary">
                                                              <i class="align-middle" data-feather="user-check"></i>
                                                          </div>
                                                      </div>
                                                  </div>
                                                  <h1 class="mt-1 mb-3"><?php echo $totalUsers_validator; ?></h1>

                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>

                          
                      </div>

                      

                  </div>
              </main>

              
          </div>
      </div>
      <?php
        include "globals/footer.php";
        ?>
<?php
include "../src/connection.php";
include "globals/head.php";
?>



<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Prepare an SQL insert statement
    $status = "Pending";
    $unit = $_SESSION['unit'];
    $file = "N/A";
    $stmt = $conn->prepare("INSERT INTO ml (case_number, cases_received, examinations, date_received, date_completed, evidence_submitted, evidence_file, requesting_party, delivered_by, victims, suspects, examiner, occurrence_details, nature_of_case, type_of_examination, remarks, status, unit) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    // Bind parameters to the prepared statement
    $stmt->bind_param(
        "ssssssssssssssssss",
        $_POST['case_number'],
        $_POST['cases_received'],
        $_POST['examinations'],
        $_POST['date_received'],
        $_POST['date_completed'],
        $_POST['evidence_submitted'],
        $file,
        $_POST['requesting_party'],
        $_POST['delivered_by'],
        $_POST['victims'],
        $_POST['suspects'],
        $_POST['examiner'],
        $_POST['occurrence_details'],
        $_POST['nature_of_case'],
        $_POST['type_of_examination'],
        $_POST['remarks'],
        $status,
        $unit
    );

    // Execute the statement
    if ($stmt->execute()) {
        echo "New record inserted successfully.";
        header("Location: ml_division.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}
?>
<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>
        <?php
        $sql = "SELECT * FROM ml where status ='Approved'";
        $result = $conn->query($sql);
        ?>
        <main class="content bg-white">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3"><strong>Medico Legal</strong> Division</h1>

                <div class="row bg-white p-2 border">
                    <div class="mb-3 col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">
                            
                            <div class="table-responsive">
                                <table id="ml_table" class="table table-bordered table-hover" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>Case Number</th>
                                            <th>Unit</th>
                                            <th>No. of Cases Received</th>
                                            <th>No. of Examination</th>
                                            <th>Time and Date Received</th>
                                            <th>Time and Date Completed</th>
                                            <th>Recovered Evidence</th>
                                            <th>Evidence File</th>
                                            <th>Requesting Party</th>
                                            <th>Delivered by (station)</th>
                                            <th>Victim/s</th>
                                            <th>Suspect/s</th>
                                            <th>EXAMINER</th>
                                            <th>Time and Date & Place of Occurrence</th>
                                            <th>Nature of Case</th>
                                            <th>Type of Examination</th>
                                            <th>Remarks (In Custody, Court, Requesting Party)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($result->num_rows > 0) {
                                            // Start building the tbody structure


                                            // Loop through each row of the result set
                                            while ($row = $result->fetch_assoc()) {
                                                echo '<tr>';
                                                echo '<td>' . $row['case_number'] . '</td>';
                                                echo '<td>' . $row['unit'] . '</td>';
                                                echo '<td>' . $row['cases_received'] . '</td>';
                                                echo '<td>' . $row['examinations'] . '</td>';
                                                echo '<td>' . $row['date_received'] . '</td>';
                                                echo '<td>' . $row['date_completed'] . '</td>';
                                                echo '<td>' . $row['evidence_submitted'] . '</td>';
                                                echo '<td>' . $row['evidence_file'] . '</td>';
                                                echo '<td>' . $row['requesting_party'] . '</td>';
                                                echo '<td>' . $row['delivered_by'] . '</td>';
                                                echo '<td>' . $row['victims'] . '</td>';
                                                echo '<td>' . $row['suspects'] . '</td>';
                                                echo '<td>' . $row['examiner'] . '</td>';
                                                echo '<td>' . $row['occurrence_details'] . '</td>';
                                                echo '<td>' . $row['nature_of_case'] . '</td>';
                                                echo '<td>' . $row['type_of_examination'] . '</td>';
                                                echo '<td>' . $row['remarks'] . '</td>';
                                                echo '</tr>';
                                            }
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>



                    

                </div>
            </div>




            <div class="modal" tabindex="-1" id="add_dna_case" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6>Medico Legal</h6>
                            <h5 class="modal-title">Add New Case</h5>

                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="case_number" class="strong mb-1">Case Number</label>
                                            <input type="text" class="form-control" id="case_number" name="case_number">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="cases_received" class="strong mb-1">No.of Cases Received</label>
                                            <input type="number" min="0" max="1000" class="form-control" id="cases_received" name="cases_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="examinations" class="strong mb-1">No.of Examination</label>
                                            <input type="number" min="0" max="1000" class="form-control" id="examinations" name="examinations">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="date_received" class="strong mb-1">Time and Date Received</label>
                                            <input type="datetime-local" class="form-control" id="date_received" name="date_received">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="date_completed" class="strong mb-1">Time and Date Completed</label>
                                            <input type="datetime-local" class="form-control" id="date_completed" name="date_completed">
                                        </div>
                                    </div>

                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="evidence_submitted" class="strong mb-1">Recovered Evidence</label>
                                            <input type="text" class="form-control" id="evidence_submitted" name="evidence_submitted">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="evidence_file" class="strong mb-1">Evidence File</label>
                                            <input type="file" class="form-control" id="evidence_file" name="evidence_file">
                                        </div>
                                    </div>

                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label for="requesting_party" class="strong mb-1">Requesting Party</label>
                                            <input type="text" class="form-control" id="requesting_party" name="requesting_party">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="delivered_by" class="strong mb-1">Delivered by (station)</label>
                                            <input type="text" class="form-control" id="delivered_by" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="victims" class="strong mb-1">Victim/s</label>
                                            <input type="text" class="form-control" id="victims" name="victims">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="suspects" class="strong mb-1">Suspect/s</label>
                                            <input type="text" class="form-control" id="suspects" name="suspects">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="examiner" class="strong mb-1">EXAMINER</label>
                                            <input type="text" class="form-control" id="examiner" name="examiner" required>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="occurrence_details" class="strong mb-1">Time and Date & Place of Occurrence</label>
                                            <input type="text" class="form-control" id="occurrence_details" name="occurrence_details">
                                        </div>
                                    </div>

                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="nature_of_case" class="strong mb-1">Nature of Case</label>
                                            <select name="nature_of_case" class="form-select" id="nature_of_case">
                                                <option value="Found Dead Body">Found Dead Body</option>
                                                <option value="Shooting Incident">Shooting Incident</option>
                                                <option value="Robbery">Robbery</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="type_of_examination" class="strong mb-1">Type of Examination</label>
                                            <select name="type_of_examination" class="form-select" id="type_of_examination">
                                                <option value="Exam 1">Exam 1</option>
                                                <option value="Exam 2">Exam 2</option>
                                                <option value="Exam 3">Exam 3</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="mb-3 col-lg-6">
                                        <div class="form-group">
                                            <label for="remarks" class="strong mb-1">Remarks (In Custody, Court, Requesting Party)</label>
                                            <select name="remarks" id="remarks" class="form-select">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                                <option value="Turned over to Requesting Party">Turned over to Requesting Party</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-end">
                                        <button class="btn btn-secondary" data-bs-dismiss='modal'>Close</button>
                                        <button type="submit" value="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>
        </main>


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#ml_table').DataTable({
        responsive: true,
        dom: "BfrQltip"
    })
</script>
<script>
    $(document).on("input", "#other_drug", function() {
        $("#other_input").removeClass('d-none');
        var drug_name = $("#other_drug").val()
        if (drug_name == "") {
            $("#other_input").addClass('d-none')
        } else {
            $('#other_input #text_label').text(`Weight in grams of ${drug_name}`)
        }
    })
</script>
<script>
    function updateExamType() {
        const checkboxes = document.querySelectorAll('input[name="exam_type[]"]');
        const checkedValues = [];
        checkboxes.forEach(checkbox => {
            console.log(checkbox.value)
            if (checkbox.checked) {
                checkedValues.push(checkbox.value);

            }
        });
        const valuesString = checkedValues.join(',');
        document.getElementById('evidence_submitted').value = valuesString;
        console.log(valuesString)
        console.log('Updated hidden input:', valuesString);
    }
</script>
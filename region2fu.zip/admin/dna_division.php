<?php
include "../src/connection.php";
include "globals/head.php";
?>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $case_number = $_POST['case_number'];
    $cases_received = $_POST['cases_received'];
    $examinations = $_POST['examinations'];
    $time_date_received = $_POST['time_date_received'];
    $time_date_completed = $_POST['time_date_completed'];
    $specimen_submitted = $_POST['specimen_submitted'];
    $requesting_party = $_POST['requesting_party'];
    $delivered_by = $_POST['delivered_by'];
    $victims = $_POST['victims'];
    $suspects = $_POST['suspects'];
    $examiner = $_POST['examiner'];
    $time_date_place = $_POST['time_date_place'];
    $nature_of_case = $_POST['nature_of_case'];
    $remarks = $_POST['remarks'];
    $unit = $_SESSION['unit'];
    $status = "Pending";
    $file_path = "N/A";
    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO dna (case_number, cases_received, examinations, time_date_received, time_date_completed, specimen_submitted, file_path, requesting_party, delivered_by, victims, suspects, examiner, time_date_place, nature_of_case, remarks, status, unit) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("siissssssssssssss", $case_number, $cases_received, $examinations, $time_date_received, $time_date_completed, $specimen_submitted, $file_path, $requesting_party, $delivered_by, $victims, $suspects, $examiner, $time_date_place, $nature_of_case, $remarks, $status, $unit);

    // Execute the statement
    if ($stmt->execute()) {
        echo "New case added successfully.";
        header("Location: dna_division.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
}
?>
<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>
        <?php
        $sql = "SELECT * FROM dna where status='Approved'";
        $result = $conn->query($sql);
        ?>
        <main class="content bg-white">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3"><strong>DNA</strong> Division</h1>

                <div class="row bg-white p-2 border">
                    <div class="col-12 col-lg-12 col-xxl-12 d-flex">
                        <div class="card flex-fill">
                            
                            <div class="table-responsive">
                                <table id="drug_case_table" class="table table-bordered table-hover" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>Case Number</th>
                                            <th>Unit</th>
                                            <th>No. of Cases Received</th>
                                            <th>No. of Examinations</th>
                                            <th>Time and Date Received</th>
                                            <th>Time and Date Completed</th>
                                            <th>Specimen Submitted</th>
                                            <th>File</th>
                                            <th>Requesting Party</th>
                                            <th>Delivered by (station)</th>
                                            <th>Victim/s</th>
                                            <th>Suspect/s</th>
                                            <th>Examiner</th>
                                            <th>Time and Date & Place of Occurrence</th>
                                            <th>Nature of Case</th>
                                            <th>Remarks</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($result->num_rows > 0) {
                                            // Output data of each row
                                            while ($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . htmlspecialchars($row["case_number"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["unit"]) . "</td>";


                                                
                                                echo "<td>" . htmlspecialchars($row["cases_received"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["examinations"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["time_date_received"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["time_date_completed"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["specimen_submitted"]) . "</td>";
                                                echo "<td><a href='" . htmlspecialchars($row["file_path"]) . "'>Download</a></td>";
                                                echo "<td>" . htmlspecialchars($row["requesting_party"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["delivered_by"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["victims"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["suspects"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["examiner"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["time_date_place"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["nature_of_case"]) . "</td>";
                                                echo "<td>" . htmlspecialchars($row["remarks"]) . "</td>";
                                                echo "</tr>";
                                            }
                                        } 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>




                </div>
            </div>




            <div class="modal" tabindex="-1" id="add_dna_case" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6>DNA</h6>
                            <h5 class="modal-title">Add New Case</h5>
                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="caseNumber" class="mb-1 strong">Case Number</label>
                                            <input type="text" name="case_number" id="caseNumber" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="casesReceived" class="mb-1 strong">No. of Cases Received</label>
                                            <input type="number" name="cases_received" id="casesReceived" min="0" max="1000" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <div class="form-group">
                                            <label for="examinations" class="mb-1 strong">No. of Examinations</label>
                                            <input type="number" name="examinations" id="examinations" min="0" max="1000" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="timeDateReceived" class="mb-1 strong">Time and Date Received</label>
                                            <input type="datetime-local" name="time_date_received" id="timeDateReceived" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="timeDateCompleted" class="mb-1 strong">Time and Date Completed</label>
                                            <input type="datetime-local" name="time_date_completed" id="timeDateCompleted" class="form-control">
                                        </div>
                                    </div>

                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="file" class="mb-1 strong">File</label>
                                            <input type="file" name="file" id="file" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-12">
                                        <div class="form-group">
                                            <label for="requestingParty" class="mb-1 strong">Requesting Party</label>
                                            <input type="text" name="requesting_party" id="requestingParty" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="deliveredBy" class="mb-1 strong">Delivered by (station)</label>
                                            <input type="text" name="delivered_by" id="deliveredBy" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="victims" class="mb-1 strong">Victim/s</label>
                                            <input type="text" name="victims" id="victims" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group">
                                            <label for="suspects" class="mb-1 strong">Suspect/s</label>
                                            <input type="text" name="suspects" id="suspects" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group">
                                            <label for="examiner" class="mb-1 strong">EXAMINER</label>
                                            <input type="text" name="examiner" id="examiner" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group">
                                            <label for="timeDatePlace" class="mb-1 strong">Time and Date & Place of Occurrence</label>
                                            <input type="text" name="time_date_place" id="timeDatePlace" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group">
                                            <label for="natureOfCase" class="mb-1 strong">Nature of Case</label>
                                            <select name="nature_of_case" id="natureOfCase" class="form-control">
                                                <option value="Found Dead Body">Found Dead Body</option>
                                                <option value="Shooting Incident">Shooting Incident</option>
                                                <option value="Robbery">Robbery</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="form-group">
                                            <label for="remarks" class="mb-1 strong">Remarks</label>
                                            <select name="remarks" id="remarks" class="form-control">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                                <option value="Turned Over To PDEA">Turned over to Requesting Party</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <div class="form-group">
                                            <label for="specimenSubmitted" class="mb-1 strong">Specimen Submitted</label>
                                            <textarea name="specimen_submitted" id="specimenSubmitted" class="form-control w-100" rows="1"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-end">
                                        <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" value="submit" class="btn btn-sm btn-primary ">Submit</button>
                                        <!-- PDF file only -->
                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>
        </main>


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#drug_case_table').DataTable({
        responsive: true,
        dom: "BfrQltip"
    })
</script>
<script>
    $(document).on("input", "#other_drug", function() {
        $("#other_input").removeClass('d-none');
        var drug_name = $("#other_drug").val()
        if (drug_name == "") {
            $("#other_input").addClass('d-none')
        } else {
            $('#other_input #text_label').text(`Weight in grams of ${drug_name}`)
        }
    })
</script>
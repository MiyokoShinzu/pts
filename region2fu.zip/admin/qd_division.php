<?php
include "../src/connection.php";
include "globals/head.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $case_number = $_POST['case_number'];
    $case_count = $_POST['case_count'];
    $exam_count = $_POST['exam_count'];
    $exam_type = $_POST['exam_type'];
    $datetime_received = $_POST['datetime_received'];
    $datetime_completed = $_POST['datetime_completed'];
    $requesting_party = $_POST['requesting_party'];
    $delivered_by = $_POST['delivered_by'];
    $victim = $_POST['victim'];
    $suspect = $_POST['suspect'];
    $examiner = $_POST['examiner'];
    $tdpo = $_POST['tdpo'];
    $case_nature = $_POST['case_nature'];
    $remarks = $_POST['remarks'];
    $status = "Pending";
    $unit = $_SESSION['unit'];
    // Insert into the database
    $sql = "INSERT INTO qd (case_number, case_count, exam_count, exam_type, datetime_received, datetime_completed, requesting_party, delivered_by, victim, suspect, examiner, tdpo, case_nature, remarks, status, unit) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssssssssss", $case_number, $case_count, $exam_count, $exam_type, $datetime_received, $datetime_completed, $requesting_party, $delivered_by, $victim, $suspect, $examiner, $tdpo, $case_nature, $remarks, $status, $unit);

    if ($stmt->execute()) {
        echo "Data inserted into the database successfully.";
        // Redirect to a success page or reload the current page
        header("Location: qd_division.php");
        exit();
    } else {
        echo "Error inserting data into the database: " . $stmt->error;
    }
    $stmt->close();
}
?>



<div class="wrapper">
    <?php include "globals/sidebar.php"; ?>

    <div class="main">
        <?php include "globals/topbar.php"; ?>

        <main class="content bg-white">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3"><strong>Question Document</strong> Division</h1>

                <div class="row bg-white p-2 border">

                    <div class="col-lg-12 mx-auto bg-white">
                        <div class="table-responsive">
                            <table class="table table-bordered   table-hover" id="qd_table">
                                <thead class="">
                                    <tr>
                                        <th>Case Number</th>
                                        <th>Unit</th>
                                        <th>No. of Cases Received</th>
                                        <th>No. of Examination</th>
                                        <th>Type of Examination</th>
                                        <th>Time and Date Received</th>
                                        <th>Time and Date Completed</th>
                                        <th>Requesting Party</th>
                                        <th>Delivered by</th>
                                        <th>Victim/s</th>
                                        <th>Suspect/s</th>
                                        <th>Examiner</th>
                                        <th>TDPO</th>
                                        <th>Nature of Case</th>
                                        <th>Remarks</th>

                                    </tr>
                                </thead>
                              
                                <tbody>
                                    <?php

                                    $sql = "SELECT * FROM qd where status ='Approved'";
                                    $result = mysqli_query($conn, $sql);

                                    while ($row = $result->fetch_assoc()) {
                                        echo '<tr>';
                                        echo '<td>' . $row["case_number"] . '</td>';
                                        echo '<td>' . $row["unit"] . '</td>';
                                        
                                     
                                        echo '<td>' . $row["case_count"] . '</td>';
                                        echo '<td>' . $row["exam_count"] . '</td>';
                                        echo '<td>' . $row["exam_type"] . '</td>';
                                        echo '<td>' . $row["datetime_received"] . '</td>';
                                        echo '<td>' . $row["datetime_completed"] . '</td>';
                                        echo '<td>' . $row["requesting_party"] . '</td>';
                                        echo '<td>' . $row["delivered_by"] . '</td>';
                                        echo '<td>' . $row["victim"] . '</td>';
                                        echo '<td>' . $row["suspect"] . '</td>';
                                        echo '<td>' . $row["examiner"] . '</td>';
                                        echo '<td>' . $row["tdpo"] . '</td>';
                                        echo '<td>' . $row["case_nature"] . '</td>';
                                        echo '<td>' . $row["remarks"] . '</td>';
                                        echo '</tr>';
                                    }


                                    ?>
                                </tbody>

                            </table>
                        </div>
                    </div>

                </div>
            </div>



            <div class="modal" tabindex="-1" aria-hidden="true" style="display: none;" id="add_case_qd">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6>Question Document</h6>
                            <h5 class="modal-title">Add New Case</h5>
                        </div>
                        <div class="modal-body">
                            <form method="post">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="" class="strong">Case Number</label>
                                            <input type="text" class="form-control" name="case_number">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="" class="strong">No. of Cases Received</label>
                                            <input type="number" min="0" max="1000" class="form-control" name="case_count">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="" class="strong">No. of Examination</label>
                                            <input type="number" min="0" max="1000" class="form-control" name="exam_count">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="" class="strong">Type of Examination</label>
                                            <input type="text" class="form-control" name="exam_type">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong">Time and Date Received</label>
                                            <input type="datetime-local" class="form-control" name="datetime_received">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong">Time and Date Completed</label>
                                            <input type="datetime-local" class="form-control" name="datetime_completed">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong">Evidence Submitted</label>
                                            <input type="file" class="form-control" accept="application/pdf" required name="evidence">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong">Requesting Party</label>
                                            <input type="text" class="form-control" name="requesting_party">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong">Delivered by (station)</label>
                                            <input type="text" class="form-control" name="delivered_by">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong">Victim/s</label>
                                            <input type="text" class="form-control" name="victim">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong">Suspect/s</label>
                                            <input type="text" class="form-control" name="suspect">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong">EXAMINER</label>
                                            <input type="text" class="form-control" name="examiner" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong">TDPO</label>
                                            <input type="text" class="form-control" name="tdpo">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong">Nature of Case</label>
                                            <select name="case_nature" class="form-control">
                                                <option value="Found Dead Body">Found Dead Body</option>
                                                <option value="Shooting Incident">Shooting Incident</option>
                                                <option value="Robbery">Robbery</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="strong">Remarks</label>
                                            <select name="remarks" class="form-control">
                                                <option value="In Custody">In custody</option>
                                                <option value="Submitted to Court">Submitted to court</option>
                                                <option value="Turnovered To PDEA">Turnovered to PDEA</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                        </div>
                        <div class="modal-footer text-end">
                            <button type="button" class="btn btn-sm btn-danger" data-bs-dismiss="modal">Close</button>
                            <button class="btn btn-sm btn-primary" id="submit_btn" type="submit" value="submit">Submit</button>
                        </div>
                        </form>

                    </div>
                </div>
            </div>
        </main>


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<?php include "globals/footer.php"; ?>
<?php include "globals/specify.php"; ?>

<script>
    $('#qd_table').DataTable({
        responsive: true,
        dom: "BfrQltip"
    })
</script>
<script>
    $(document).on("input", "#other_drug", function() {
        $("#other_input").removeClass('d-none');
        var drug_name = $("#other_drug").val()
        if (drug_name == "") {
            $("#other_input").addClass('d-none')
        } else {
            $('#other_input #text_label').text(`Weight in grams of ${drug_name}`)
        }
    })
</script>